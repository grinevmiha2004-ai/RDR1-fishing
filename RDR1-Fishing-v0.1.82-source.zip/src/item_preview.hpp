#pragma once
#include <cstring>
namespace fishing {
struct ItemPreviewClip {const char* set;const char* clip;const char* label;};
// Every runtime hash is mapped to its standing authored source in verify_item_preview.py.
inline constexpr ItemPreviewClip itemPreviewClips[]={
 {"lso_base","nor_lso_stn_drw","Lasso: draw"},
 {"lso_base","nor_lso_stn_drw_pst","Lasso: draw finish"},
 {"lso_base","nor_lso_stn_hls_pre","Lasso: stow preparation"},
 {"lso_base","nor_lso_stn_hls","Lasso: stow"},
 {"dyn_base","nor_dyn_stn_drw","Bottle/dynamite: draw"},
 {"dyn_base","nor_dyn_stn_hls","Bottle/dynamite: stow"},
 {"tkn_base","nor_tkn_stn_drw","Throwing knife: draw"},
 {"tkn_base","nor_tkn_stn_hls","Throwing knife: stow"},
 {"item_binoculars","gent_useinventory_binocs_pre","Binoculars: take out"},
 {"item_binoculars","gent_useinventory_binocs_pst","Binoculars: put away"},
 {"ptl_base","nor_ptl_stn_drw","Pistol: draw"},
 {"ptl_base","nor_ptl_stn_drw_pst","Pistol: draw finish"},
 {"ptl_base","nor_ptl_stn_hls_pre","Pistol: holster preparation"},
 {"ptl_base","nor_ptl_stn_hls","Pistol: holster"},
 {"rfl_base","nor_rfl_stn_drw","Rifle: draw"},
 {"rfl_base","nor_rfl_stn_drw_pst","Rifle: draw finish"},
 {"rfl_base","nor_rfl_stn_hls_pre","Rifle: stow preparation"},
 {"item_bottle","gent_useinventory_drinkbottle","Bottle: full use action"},
 {"item_tobacco","gent_useinventory_takemeds","Medicine/tobacco: full use action"},
 {"item_bait","gent_useinventory_bait","Bait: full use action"}
};
inline constexpr int itemPreviewCount=sizeof(itemPreviewClips)/sizeof(*itemPreviewClips);
inline constexpr int itemPreviewBanks=itemPreviewCount/10;
inline int itemPreviewResourceIndex(int index){
 if(index<0||index>=itemPreviewCount)return -1;
 for(int i=0;i<index;++i)if(std::strcmp(itemPreviewClips[i].set,itemPreviewClips[index].set)==0)return i;
 return index;
}
inline int itemPreviewIndex(int bank,int key){return bank>=0&&bank<itemPreviewBanks&&key>=0&&key<10?bank*10+key:-1;}
}
