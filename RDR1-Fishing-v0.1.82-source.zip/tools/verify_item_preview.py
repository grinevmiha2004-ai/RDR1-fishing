"""Map every test runtime key to its standing source in supplied extracted WAS sets."""
from pathlib import Path
import re,struct,sys,hashlib
r=Path(__file__).resolve().parent.parent
header=(r/'src/item_preview.hpp').read_text()
items=re.findall(r'\{"([a-z0-9_]+)","([a-z0-9_]+)","([^"]+)"\}',header)
assert len(items)==20

def h(s):
 v=0
 for c in s.encode():v=(v+c)&0xffffffff;v=(v+(v<<10))&0xffffffff;v^=v>>6
 v=(v+(v<<3))&0xffffffff;v^=v>>11
 return (v+(v<<15))&0xffffffff
for name,clip,label in items:
 b=(Path(sys.argv[1])/(name+'.was')).read_bytes()
 assert b[0x38:0x38+len(name)+5]==(name+'.ast\0').encode()
 start=0;matched=None
 while True:
  at=b.find(struct.pack('<I',h(clip)),start)
  if at<0:break
  start=at+4
  p=struct.unpack_from('<I',b,at+4)[0]&0xfffffff
  if p+12>=len(b):continue
  n=struct.unpack_from('<I',b,p+8)[0]&0xfffffff
  if n>=len(b):continue
  source=b[n:b.find(b'\0',n)].decode(errors='replace')
  if source.lower().startswith(('human\\gent\\','human/gent/')) and source.lower().endswith(clip.lower()):
   matched=source;break
 assert matched,(name,clip)
 assert '_run_' not in matched and '_hrs_' not in matched
 print(name,clip,'->',matched)
print('PASS: all20 runtime keys resolve to non-running/non-mounted source clips')
