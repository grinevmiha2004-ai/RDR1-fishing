#include "redhook.hpp"
#include "fishing.hpp"
#include <cstdio>
#include <cmath>
#include <string>
#include <cstdarg>

static HMODULE module;
static std::string iniPath,logPath;
static fishing::Game game;
static unsigned savedCatches;
static int toggleKey=VK_F6,actionKey='E',reelKey='R',easeKey='Q';
static fishing::Button toggleButton,actionButton;
static std::string toggleName="F6",actionName="E",reelName="R",easeName="Q";
static const char* stateName(fishing::Phase p){
 static const char* names[]={"Off","Ready","Cast","Wait","Bite","Fight","Caught","Lost"};return names[int(p)];
}
static std::string keyName(int key){
 char name[80]{};LONG scan=LONG(MapVirtualKeyA(key,MAPVK_VK_TO_VSC)<<16);
 if(GetKeyNameTextA(scan,name,sizeof(name)))return name;
 return "key "+std::to_string(key);
}
static int readKey(const char* name,int fallback){
 int key=int(GetPrivateProfileIntA("Keys",name,fallback,iniPath.c_str()));
 // F8 and F9 are reserved by the user's installed mods.
 return key>0&&key<256&&key!=VK_F8&&key!=VK_F9?key:fallback;
}
static bool visuals=true;
static bool hudEnabled=true;
static float hudTextHeight=.018f;
static float waterOffset=-.65f,castDistance=9;
static rh::Vec origin,forward;
struct Prop {const char* name;int asset=-1,object=0;bool done=false;};
static Prop props[]={{"p_gen_fishingpole01x"},{"p_gen_fishingbobber01x"},{"p_gen_fishinghook01x"}};
static int layout=0;static float loadTime=0;
static void log(const char* format,...) {
 char buf[1024];va_list a;va_start(a,format);vsnprintf(buf,sizeof(buf),format,a);va_end(a);
 rh::print(1,"[Fishing] %s",buf);
 if(FILE* f=fopen(logPath.c_str(),"a")){fprintf(f,"[%llu ms] %s\n",static_cast<unsigned long long>(GetTickCount64()),buf);fclose(f);}
}
static void save(){char b[32];snprintf(b,sizeof(b),"%u",game.catches);if(!WritePrivateProfileStringA("Progress","Catches",b,iniPath.c_str()))log("Cannot save catches (Win32 %lu)",GetLastError());savedCatches=game.catches;}
static void cleanup(){
 for(auto& p:props){if(rh::validObject(p.object))rh::invoke<0x21144994>(p.object);p.object=0;if(fishing::validAsset(p.asset))rh::invoke<0xA8D12960>(p.asset);p.asset=-1;p.done=false;}
 if(layout&&rh::validObject(layout))rh::invoke<0x21144994>(layout);
 layout=0;
}
static void requestProps(){
 if(!visuals)return;
 layout=rh::invoke<0x6CA53214,int>("RDR1Fishing");loadTime=0;
 for(auto& p:props){std::string path="$/fragments/";path+=p.name;rh::invoke<0x9AA02DA7,int>(path.c_str(),0);p.asset=rh::invoke<0x6005B514,int>(path.c_str(),0);log("Request %s: asset=%d",path.c_str(),p.asset);if(fishing::validAsset(p.asset))rh::invoke<0x38DC1F50,bool>(p.asset,true);else p.done=true;}
}
static rh::Vec point(float distance,float height,float side=0){return {origin.x+forward.x*distance+forward.z*side,origin.y+height,origin.z+forward.z*distance-forward.x*side};}
static void updateProps(float dt){
 if(!visuals||!layout)return;
 loadTime+=dt;
 for(auto& p:props){if(p.done)continue;
  if(fishing::validAsset(p.asset)&&rh::invoke<0xD7F80035,bool>(p.asset)){
   auto at=point(.4f,1);std::string path="$/fragments/";path+=p.name;
   p.object=rh::invoke<0xE351587D,int>(layout,p.name,path.c_str(),rh::XY{at.x,at.y},at.z,rh::XY{0,0},0.f,true);p.done=true;log("Created %s: object=%d valid=%d",p.name,p.object,int(rh::validObject(p.object)));
  }else if(loadTime>5){p.done=true;log("Model unavailable: %s; continuing gameplay without it",p.name);}
 }
 // Temporary body-relative placement. Bone attachment and rod clips await verified native signatures.
 rh::move(props[0].object,point(.35f,1.0f,.3f));
 bool cast=game.phase==fishing::Phase::Cast;
 bool out=cast||game.phase==fishing::Phase::Wait||game.phase==fishing::Phase::Bite||game.phase==fishing::Phase::Fight;
 float distance=cast?castDistance*std::clamp(game.elapsed/1.1f,0.f,1.f):castDistance;
 if(game.phase==fishing::Phase::Fight)distance*=1-game.progress*.85f;
 auto bobber=out?point(distance,waterOffset):point(.5f,.8f);
 if(cast)bobber.y+=std::sin(std::clamp(game.elapsed/1.1f,0.f,1.f)*3.14159265f)*2.5f;
 if(game.phase==fishing::Phase::Bite)bobber.y-=.13f*(.5f+.5f*std::sin(game.elapsed*18));
 rh::move(props[1].object,bobber);bobber.y-=out?.3f:.1f;rh::move(props[2].object,bobber);
}
static void hud(){
 if(!hudEnabled)return;
 using fishing::Phase;
 // RedHook queues draw calls; storage must remain valid after this function returns.
 static char buf[1024];char detail[512]{};
 switch(game.phase){
 case Phase::Ready:snprintf(detail,sizeof(detail),"%s: CAST | %s: stop\nStand on shore facing water",actionName.c_str(),toggleName.c_str());break;
 case Phase::Cast:snprintf(detail,sizeof(detail),"Casting...");break;
 case Phase::Wait:snprintf(detail,sizeof(detail),"Waiting for a bite: %.0f s\nWait for BITE, then press %s",std::ceil(std::max(0.f,game.wait-game.elapsed)),actionName.c_str());break;
 case Phase::Bite:snprintf(detail,sizeof(detail),"BITE! Press %s NOW! %.1f s",actionName.c_str(),std::max(0.f,game.biteWindow-game.elapsed));break;
 case Phase::Fight:snprintf(detail,sizeof(detail),"Hold %s: reel | Hold %s: ease\nTension: %d%% | Reeled: %d%%\nFish pulls: %s",reelName.c_str(),easeName.c_str(),int(game.tension*100),int(game.progress*100),(int(game.elapsed/1.6f)%3)!=2?"YES":"NO");break;
 case Phase::Caught:snprintf(detail,sizeof(detail),"CAUGHT! %.2f kg | %s: next cast",game.weight,actionName.c_str());break;
 case Phase::Lost:snprintf(detail,sizeof(detail),"Fish escaped / line lost. %s: try again",actionName.c_str());break;
 default:return;
 }
 snprintf(buf,sizeof(buf),"FISHING v0.1.2 | Total catches: %u\n%s",game.catches,detail);
 // Rectangles use center coordinates. Text scale is a fraction of screen height.
 rh::drawRect(.24f,.25f,.44f,.22f,0,0,0,170);
 rh::drawText(buf,.035f,.25f,0,hudTextHeight,255,game.phase==Phase::Bite?210:255,game.phase==Phase::Bite?60:255,255,0);
 if(game.phase==Phase::Fight){
  rh::drawRect(.24f,.345f,.41f,.008f,60,60,60,255);
  float width=.41f*std::clamp(game.tension,0.f,1.f);
  rh::drawRect(.035f+width*.5f,.345f,width,.008f,game.tension>.8f?255:80,game.tension>.8f?60:220,60,255);
 }
}
static void script(){
 char path[MAX_PATH];GetModuleFileNameA(module,path,MAX_PATH);std::string root=path;root=root.substr(0,root.find_last_of("\\/")+1);iniPath=root+"Fishing.ini";logPath=root+"Fishing.log";
 hudEnabled=GetPrivateProfileIntA("HUD","Enabled",1,iniPath.c_str())!=0;
 hudTextHeight=std::clamp(GetPrivateProfileIntA("HUD","TextHeightPermille",18,iniPath.c_str()),12u,24u)/1000.f;
 visuals=GetPrivateProfileIntA("Fishing","Visuals",1,iniPath.c_str())!=0;
 waterOffset=std::clamp(GetPrivateProfileIntA("Fishing","WaterOffsetCm",-65,iniPath.c_str())/100.f,-5.f,2.f);
 castDistance=std::clamp(GetPrivateProfileIntA("Fishing","CastDistance",9,iniPath.c_str())*1.f,3.f,20.f);
 toggleKey=readKey("Toggle",VK_F6);actionKey=readKey("Action",'E');reelKey=readKey("Reel",'R');easeKey=readKey("Ease",'Q');
 if(toggleKey==actionKey||toggleKey==reelKey||toggleKey==easeKey||actionKey==reelKey||actionKey==easeKey||reelKey==easeKey){toggleKey=VK_F6;actionKey='E';reelKey='R';easeKey='Q';log("Duplicate bindings: restored F6/E/R/Q");}
 toggleName=keyName(toggleKey);actionName=keyName(actionKey);reelName=keyName(reelKey);easeName=keyName(easeKey);
 game.biteWindow=std::clamp(GetPrivateProfileIntA("Fishing","BiteWindowSeconds",6,iniPath.c_str())*1.f,3.f,20.f);
 game.catches=GetPrivateProfileIntA("Progress","Catches",0,iniPath.c_str());savedCatches=game.catches;game.seed=GetTickCount();
 log("v0.1.2 loaded. Toggle=%s action=%s reel=%s ease=%s visuals=%d biteWindow=%.1f",toggleName.c_str(),actionName.c_str(),reelName.c_str(),easeName.c_str(),int(visuals),game.biteWindow);
 log("HUD enabled=%d textHeight=%.3f (fraction of screen height)",int(hudEnabled),hudTextHeight);
 float previous=rh::invoke<0x5842B9D1,float>();
 rh::help("Fishing v0.1.2 loaded. Stand on shore. Default toggle: F6.");
 while(true){
  rh::wait(0);
  float now=rh::invoke<0x5842B9D1,float>();float dt=std::clamp(now-previous,0.f,.1f);previous=now;
  DWORD foregroundPid=0;
  GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);
  bool toggleEdge=toggleButton.sample((GetAsyncKeyState(toggleKey)&0x8000)!=0);
  bool actionEdge=actionButton.sample((GetAsyncKeyState(actionKey)&0x8000)!=0);
  if(foregroundPid!=GetCurrentProcessId()||rh::invoke<0x57246C02,bool>())continue;
  int a=rh::player();bool alive=rh::validActor(a)&&!rh::invoke<0x0D798FFE,bool>(a);
  if(game.phase!=fishing::Phase::Off&&(!alive||!rh::invoke<0x63D6551C,bool>(a))){cleanup();game.enter(fishing::Phase::Off);log("Stopped: player unavailable or not on foot");}
  if(toggleEdge){
   if(game.phase!=fishing::Phase::Off){cleanup();game.enter(fishing::Phase::Off);rh::help("Fishing stopped. Safe to unload Fishing.red.");log("Stopped by player");}
   else if(alive&&rh::invoke<0x63D6551C,bool>(a)){
    origin=rh::position(a);float h=rh::invoke<0x42DE39F0,float>(a)*.01745329252f;forward={-std::sin(h),0,std::cos(h)};game.enter(fishing::Phase::Ready);requestProps();log("Enabled at %.3f %.3f %.3f heading %.3f",origin.x,origin.y,origin.z,h);
   }
  }
  if(game.phase==fishing::Phase::Off)continue;
  auto pos=rh::position(a);float dx=pos.x-origin.x,dz=pos.z-origin.z;
  if(dx*dx+dz*dz>4){cleanup();game.enter(fishing::Phase::Off);rh::help("Fishing stopped: moved away from casting spot.");log("Stopped: player moved");continue;}
  auto old=game.phase;
  if(actionEdge)log("Action pressed in %s at %.2f s%s",stateName(old),game.elapsed,old==fishing::Phase::Wait?" (waiting for bite; ignored)":"");
  game.update(dt,{actionEdge,(GetAsyncKeyState(reelKey)&0x8000)!=0,(GetAsyncKeyState(easeKey)&0x8000)!=0});
  if(old!=game.phase){
   log("State %s -> %s (wait=%.2f tension=%.2f progress=%.2f)",stateName(old),stateName(game.phase),game.wait,game.tension,game.progress);
   if(game.phase==fishing::Phase::Bite)log("BITE: press %s within %.1f seconds",actionName.c_str(),game.biteWindow);
   if(old==fishing::Phase::Bite&&game.phase==fishing::Phase::Lost)log("Missed bite: no new Action press during bite window");
  }
  if(game.catches!=savedCatches)save();
  updateProps(dt);hud();
 }
}
BOOL WINAPI DllMain(HMODULE m,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH){module=m;DisableThreadLibraryCalls(m);if(!rh::bind())return FALSE;rh::reg(m,script);}
 else if(reason==DLL_PROCESS_DETACH&&rh::unreg)rh::unreg(m);
 return TRUE;
}
