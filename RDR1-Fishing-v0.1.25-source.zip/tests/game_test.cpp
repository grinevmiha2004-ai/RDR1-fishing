#include "../src/fishing.hpp"
#include "../src/visuals.hpp"
#include "../src/line_raster.hpp"
#include "../src/hand_bone.hpp"
#include "../src/cast_animation.hpp"
#include "../src/cast_controls.hpp"
#include "../src/cast_preparation.hpp"
#include "../src/cast_playback.hpp"
#include <type_traits>
#include <set>
#include <utility>
#include <cassert>
#include <cstdio>
#include <limits>
using namespace fishing;
void advance(Game& g,Phase target){for(int i=0;i<1000&&g.phase!=target;i++)g.update(.05f,{});assert(g.phase==target);}
void hook(Game& g){g.toggle();g.update(.01f,{true});advance(g,Phase::Bite);g.update(.01f,{true});assert(g.phase==Phase::Fight);}
int main(){
 {
  CastControls controls;bool enabled=true;int disables=0,restores=0;
  auto read=[&](){return enabled;};
  auto write=[&](bool value){enabled=value;if(value)++restores;else ++disables;};
  assert(controls.acquire(read,write)&&controls.owned&&!enabled);
  controls.acquire(read,write);assert(disables==1); // no repeated toggles
  assert(controls.restore(write)&&enabled&&restores==1);
  assert(!controls.restore(write)&&restores==1); // cleanup idempotent
  enabled=false;assert(!controls.acquire(read,write)&&!controls.owned);
  assert(!controls.restore(write)&&!enabled); // preserve pre-existing disabled control
  enabled=true;controls.acquire(read,write);
  assert(controls.restore(write)&&enabled); // early cancellation, independent of actor validity
 }
 puts("PASS: scoped player-control restoration, cancellation, idempotence and pre-existing disabled state");
 {
  // Streaming may finish after Cast->Wait. No bind or clip request before readiness.
  CastPreparation prep;using Result=CastPreparation::Result;
  int bindings=0;auto bind=[&](){++bindings;return true;};
  Game loading;loading.toggle();loading.update(.01f,{true});
  for(int i=0;i<13;i++){
   assert(prep.update(loading.phase==Phase::Cast,true,false,.1f,bind)==Result::None);
   loading.update(.1f,{});
  }
  assert(loading.phase==Phase::Wait&&bindings==0);
  assert(prep.update(false,true,true,.01f,bind)==Result::None&&bindings==1);
  assert(prep.stage==CastPreparation::Stage::Binding);
  assert(prep.update(false,true,true,.016f,bind)==Result::Start&&bindings==1);
  for(int i=0;i<10;i++)assert(prep.update(false,true,true,.1f,bind)==Result::None);
  assert(bindings==1);
  prep.complete();prep.update(false,true,true,.1f,bind);
  assert(prep.stage==CastPreparation::Stage::Idle);
  // Cancellation while loading must not attach anything, including on late completion.
  prep.update(true,true,false,.1f,bind);
  prep.update(false,false,true,.1f,bind);
  assert(prep.update(false,true,true,.1f,bind)==Result::None&&bindings==1);
  // An existing override rejects binding once; held casting cannot retry every frame.
  assert(prep.update(true,true,true,0,[](){return false;})==Result::Rejected);
  for(int i=0;i<30;i++)assert(prep.update(true,true,true,.1f,bind)==Result::None);
  assert(bindings==1);
  prep.reset();int timeouts=0;
  for(int i=0;i<50;i++)if(prep.update(true,true,false,.1f,bind)==Result::Timeout)++timeouts;
  assert(timeouts==1&&bindings==1);
  prep.reset();prep.update(true,true,false,.1f,bind);
  for(int i=0;i<100;i++)assert(prep.update(true,true,false,0,bind)==Result::None);
  assert(prep.elapsed<.11f); // paused game time must not consume the streaming deadline
 }
 puts("PASS: animation-set streaming, Cast->Wait readiness, cancellation, binding rejection and bounded timeout");
 {
  // Exercise the same native submission used in plugin.cpp. Speed must reach slot 4
  // as a float; the layer is int, both flags bool, and the timer is float.
  float rate=0,timer=0;int calls=0;
  requestCastClip([&](int actor,const char* clip,float,float,auto speed,auto layer,auto loop,auto flag,auto seconds){
   static_assert(std::is_same_v<decltype(speed),float>);
   static_assert(std::is_same_v<decltype(layer),int>);
   static_assert(std::is_same_v<decltype(loop),bool>);
   static_assert(std::is_same_v<decltype(flag),bool>);
   static_assert(std::is_same_v<decltype(seconds),float>);
   assert(actor==42&&clip==castWindupClip&&layer==0&&!loop&&!flag);
   rate=speed;timer=seconds;++calls;
  },42,castWindupClip);
  assert(calls==1&&rate>0&&timer<0);
  // Verified engine relation: clip-time increments are multiplied by this rate.
  // Reproduce the user's 0.1.23 samples, then feed progression at the submitted rate.
  CastClipProgress progress;
  for(int i=0;i<111;i++)assert(!progress.observe(true,0.f));
  assert(!progress.advanced);
  float clock=0;
  for(int i=0;i<30;i++){clock+=(1.f/60.f)*rate;progress.observe(true,clock);}
  assert(clock>.49f&&progress.advanced);
  progress.reset();assert(!progress.observe(false,-1));
  assert(!progress.observe(true,std::numeric_limits<float>::quiet_NaN()));
  assert(!progress.observe(true,0));assert(progress.observe(true,.016f));
  assert(!progress.observe(true,.032f)); // advancing logged once per request
 }
 puts("PASS: typed native playback request, positive clock rate, natural completion timer and frozen-log regression");
 // Animation spans Cast->Wait; only actual clip completion advances it.
 CastAnimation animation;using Cmd=CastAnimCommand;
 assert(animation.update(false,true,0,false)==Cmd::None);
 assert(animation.update(true,true,0,false)==Cmd::Windup);
 for(int i=0;i<11;i++)assert(animation.update(true,true,.1f,true)==Cmd::None);
 assert(animation.update(false,true,.1f,true)==Cmd::None); // no 1.1s cutoff
 assert(animation.update(false,true,.01f,false)==Cmd::Release);
 for(int i=0;i<8;i++)assert(animation.update(false,true,.1f,true)==Cmd::None);
 assert(animation.update(false,true,.01f,false)==Cmd::None);
 assert(animation.stage==CastAnimation::Stage::BlendOut);
 for(int i=0;i<2;i++)assert(animation.update(false,true,.1f,false)==Cmd::None);
 assert(animation.update(false,true,.05f,false)==Cmd::Stop);
 assert(animation.update(false,true,.01f,false)==Cmd::None);
 assert(animation.update(true,true,0,false)==Cmd::Windup);
 assert(animation.update(true,false,.01f,true)==Cmd::Stop); // F6/cancel
 animation.reset();assert(animation.update(true,true,0,false)==Cmd::Windup);
 int releases=0,stops=0;
 for(int i=0;i<50;i++){
  Cmd c=animation.update(true,true,.1f,false);
  if(c==Cmd::Release)++releases;
  if(c==Cmd::Stop)++stops;
 }
 assert(releases==1&&stops==1); // missing clips bounded, no restart during Cast
 animation.reset();assert(animation.update(true,true,0,false)==Cmd::Windup);
 releases=stops=0;
 for(int i=0;i<50;i++){
  Cmd c=animation.update(true,true,.1f,true);
  if(c==Cmd::Release)++releases;
  if(c==Cmd::Stop)++stops;
 }
 assert(releases==1&&stops==1); // looping clips also bounded
 puts("PASS: animation completion, Cast->Wait continuity, cancellation, missing/looping clip bounds and no repeated restart");
 {
  // Replay both observed paths: preparation missing or completing after ~0.83s.
  // The fishing timer and projectile must stay held until the release command.
  for(bool preAvailable:{false,true}){
   Game synced;synced.toggle();synced.update(.01f,{true});
   CastAnimation plan;bool released=false;float now=0,launched=-1,landed=-1,finished=-1;
   for(int frame=0;frame<400;frame++){
    constexpr float step=.016f;now+=step;
    synced.update(castGameStep(synced.phase==Phase::Cast,released,step),{});
    if(!released)assert(synced.phase==Phase::Cast&&synced.elapsed==0);
    bool matched=(plan.stage==CastAnimation::Stage::Windup&&preAvailable&&plan.elapsed<.83f)||
                 (plan.stage==CastAnimation::Stage::Release&&plan.elapsed<1.066f);
    auto command=plan.update(synced.phase==Phase::Cast,true,step,matched);
    if(command==Cmd::Release){assert(!released);released=true;launched=now;}
    if(synced.phase==Phase::Wait&&landed<0)landed=now;
    if(command==Cmd::Stop){finished=now;break;}
   }
   assert(launched>=.79f&&launched<.9f);
   assert(landed-launched>=1.09f&&landed-launched<1.14f);
   assert(finished>landed&&finished-launched<1.5f);
  }
  // F6/death must still interrupt a pending native fade immediately.
  CastAnimation fade;fade.stage=CastAnimation::Stage::BlendOut;
  assert(fade.update(false,false,.01f,false)==Cmd::Stop);
 }
 puts("PASS: observed windup timing synchronized with projectile flight, landing and cancellable blend-out");
 for(const char* name:{"wrist_r","WRIST_R","Hand_Right","SKEL_R_Hand","skel_r_hand","R_Hand","hand_r","Bip01 R Hand"})assert(rightHandBoneName(name));
 for(const char* name:{"wrist_l","wristroll_r","wrist_r_Attachment","Hand_Left","SKEL_L_Hand","R_Hand_Index1","R_Hand_Thumb","Lower_Arm_Right",""})assert(!rightHandBoneName(name));
 puts("PASS: right-hand bone matching; left hand, fingers and forearm rejected");
 // View rays keep their horizontal bearing at every pitch and in every quadrant.
 for(Point view:{Point{0,-.8f,1},Point{1,.4f,0},Point{0,1,-1},Point{-1,-1,0},Point{3,-9,4},Point{-3,9,-4}}){
  Point direction{};assert(horizontalDirection(view,direction));
  assert(direction.y==0&&std::abs(std::hypot(direction.x,direction.z)-1)<.00001f);
  assert(direction.x*view.x+direction.z*view.z>0);
  assert(std::abs(direction.x*view.z-direction.z*view.x)<.00001f);
  Point target{10+direction.x*9,3,20+direction.z*9};
  assert(std::abs(std::hypot(target.x-10,target.z-20)-9)<.00001f);
 }
 Point invalidOut{7,8,9};
 assert(!horizontalDirection(Point{0,1,0},invalidOut));
 assert(!horizontalDirection(Point{0,0,0},invalidOut));
 assert(!horizontalDirection(Point{std::numeric_limits<float>::quiet_NaN(),0,1},invalidOut));
 assert(!horizontalDirection(Point{1,std::numeric_limits<float>::infinity(),0},invalidOut));
 assert(invalidOut.x==7&&invalidOut.y==8&&invalidOut.z==9);
 puts("PASS: camera bearing in six directions and pitches; cast distance; invalid/vertical view rejection");
 Game g;hook(g);
 for(int i=0;i<2000&&g.phase==Phase::Fight;i++)g.update(.02f,{false,g.tension<.6f,g.tension>=.6f});
 assert(g.phase==Phase::Caught&&g.catches==1);
 Game missed;missed.toggle();missed.update(.01f,{true});advance(missed,Phase::Bite);advance(missed,Phase::Lost);assert(!missed.catches);
 Game broken;hook(broken);for(int i=0;i<1000&&broken.phase==Phase::Fight;i++)broken.update(.02f,{false,true,false});assert(broken.phase==Phase::Lost&&!broken.catches);
 Game slack;hook(slack);for(int i=0;i<1000&&slack.phase==Phase::Fight;i++)slack.update(.02f,{false,false,true});assert(slack.phase==Phase::Lost);
 Game cancel;hook(cancel);cancel.toggle();assert(cancel.phase==Phase::Off);
 Game paused;hook(paused);float t=paused.tension;paused.update(0,{false,true});assert(paused.tension==t);assert(paused.progress==0);
 for(unsigned seed=1;seed<=500;seed++){
  Game run;run.seed=seed;hook(run);
  for(int i=0;i<3000&&run.phase==Phase::Fight;i++)run.update(.016f,{false,run.tension<.6f,run.tension>=.6f});
  assert(run.phase==Phase::Caught&&run.catches==1);
  run.update(.1f,{true});assert(run.phase==Phase::Ready&&run.catches==1);
 }
 // Reproduce IDs reported by the user's game: both must reach streaming.
 assert(validAsset(872270493));assert(validAsset(-2085051245));assert(validAsset(-925462083));
 assert(!validAsset(0)&&!validAsset(-1));
 Button b;assert(!b.sample(false));assert(b.sample(true));assert(!b.sample(true));assert(!b.sample(false));assert(b.sample(true));
 Game early;early.toggle();early.update(.01f,{true});advance(early,Phase::Wait);
 early.update(.01f,{true});assert(early.phase==Phase::Wait);
 advance(early,Phase::Bite);
 // A reaction slower than the old 2.2-second window must now hook successfully.
 for(int i=0;i<35;i++)early.update(.1f,{});
 assert(early.phase==Phase::Bite);early.update(.01f,{true});assert(early.phase==Phase::Fight);
 Point hand{822,77,1380},surface{831,75,1380};
 auto first=castPath(hand,surface,0),last=castPath(hand,surface,1),mid=castPath(hand,surface,.5f);
 assert(std::abs(first.y-hand.y)<.0001f&&std::abs(last.y-surface.y)<.0001f);
 assert(last.x==surface.x&&last.z==surface.z&&mid.y>76);
 for(int i=0;i<=100;i++){
  auto p=castPath(hand,surface,i/100.f);assert(finite(p));assert(p.x>=hand.x&&p.x<=surface.x);
 }
 assert(waterHitValid(surface,surface,80,30));
 assert(!waterHitValid(surface,Point{0,0,0},80,30));
 assert(!waterHitValid(surface,Point{surface.x,90,surface.z},80,30));
 assert(!waterHitValid(surface,Point{surface.x+1,75,surface.z},80,30));
 // All slopes: exact one-pixel coverage, endpoints and no gaps between adjacent pixels.
 for(int endX=-10;endX<=10;endX++)for(int endY=-10;endY<=10;endY++){
  std::set<std::pair<int,int>> pixels;
  solidLine(0,0,endX,endY,false,[&](int x,int y,int w,int h){
   assert(w==1||h==1);
   for(int ix=x;ix<x+w;ix++)for(int iy=y;iy<y+h;iy++)assert(pixels.insert({ix,iy}).second);
  });
  int length=std::max(std::abs(endX),std::abs(endY));
  assert(int(pixels.size())==length+1&&pixels.count({0,0})&&pixels.count({endX,endY}));
  for(auto pixel:pixels){
   assert(std::abs(endX*pixel.second-endY*pixel.first)<=length*.5f+.01f);
   if(length){int neighbors=0;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)if((x||y)&&pixels.count({pixel.first+x,pixel.second+y}))++neighbors;assert(neighbors>0);}
  }
 }
 puts("PASS: solid one-pixel line at 441 slopes; cast endpoints, arc, invalid water hits; negative resource hashes, key edges, early action, 3.5-second hook; 500 seeded catches; catch, missed bite, broken line, slack line, cancel, zero-delta pause");
}
