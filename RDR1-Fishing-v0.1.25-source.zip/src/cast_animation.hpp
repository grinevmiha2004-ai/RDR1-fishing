#pragma once
#include <algorithm>
#include "cast_playback.hpp"
namespace fishing {
inline constexpr const char* castWindupClip="nor_lso_stn_mid_trw_pre";
inline constexpr const char* castReleaseClip="nor_lso_stn_mid_trw_mid";
// Relative to Global: the native adds that prefix internally.
inline constexpr const char* castWindupNode="default_character_Main\\Gunplay\\THROWING\\Lasso\\LassoNor\\ThrowStand";
inline constexpr const char* castReleaseNode="default_character_Main\\Gunplay\\THROWING\\Lasso\\LassoNor\\ThrowStand\\ThrowMid";
inline float castGameStep(bool casting,bool flightReleased,float dt){
 return casting&&!flightReleased?0.f:dt;
}
enum class CastAnimCommand {None,Windup,Release,Stop};
struct CastAnimation {
 enum class Stage {Idle,Windup,Release,BlendOut,Finished};
 Stage stage=Stage::Idle;
 float elapsed=0;
 bool seenPlaying=false;
 CastAnimCommand update(bool casting,bool allowed,float dt,bool playing){
  if(!allowed){
   bool active=stage==Stage::Windup||stage==Stage::Release||stage==Stage::BlendOut;
   reset();return active?CastAnimCommand::Stop:CastAnimCommand::None;
  }
  if(stage==Stage::Finished){if(!casting)reset();return CastAnimCommand::None;}
  if(stage==Stage::Idle){
   if(!casting)return CastAnimCommand::None;
   stage=Stage::Windup;elapsed=0;seenPlaying=false;return CastAnimCommand::Windup;
  }
  elapsed+=std::clamp(dt,0.f,.1f);
  if(stage==Stage::BlendOut){
   if(elapsed<castBlendOut)return CastAnimCommand::None;
   stage=Stage::Finished;return CastAnimCommand::Stop;
  }
  seenPlaying=seenPlaying||playing;
  bool completed=seenPlaying&&!playing&&elapsed>=.05f;
  // Give an unconfirmed clip time to start; bound loops/missing clips as well.
  float limit=stage==Stage::Windup?(seenPlaying?1.4f:.8f):(seenPlaying?1.8f:1.f);
  if(!completed&&elapsed<limit)return CastAnimCommand::None;
  if(stage==Stage::Windup){stage=Stage::Release;elapsed=0;seenPlaying=false;return CastAnimCommand::Release;}
  stage=Stage::BlendOut;elapsed=0;return CastAnimCommand::None;
 }
 void reset(){stage=Stage::Idle;elapsed=0;seenPlaying=false;}
};
}
