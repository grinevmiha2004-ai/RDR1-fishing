#pragma once
#include <algorithm>
#include <cmath>
namespace fishing {
struct FishStruggle {
 bool pulling=true;float age=0,restSeconds=3;
 void reset(){*this={};}
 template<class Random> void update(float dt,Random random){
  if(!std::isfinite(dt)||dt<=0)return;
  age+=std::min(dt,.1f);
  float duration=pulling?3.2f:restSeconds;
  if(age+1.e-5f<duration)return;
  age=std::max(0.f,age-duration);
  pulling=!pulling;
  if(!pulling){float roll=random();restSeconds=3.f+(std::isfinite(roll)?std::clamp(roll,0.f,1.f):0.f);}
 }
};
}
