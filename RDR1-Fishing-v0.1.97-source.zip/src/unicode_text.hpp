#pragma once
#include "redhook.hpp"
#include "text_bitmap.hpp"
#include <map>
#include <string>
namespace textui {
struct Glyph {uint64_t texture=UINT64_MAX;int width=0,height=0,advance=0;};
class UnicodeText {
 HDC dc=nullptr;HFONT font=nullptr;HGDIOBJ originalFont=nullptr;
 int lineHeight=0;bool attempted=false;
 std::map<wchar_t,Glyph> glyphs;
 bool initialize(){
  if(attempted)return dc&&font&&lineHeight;
  attempted=true;dc=CreateCompatibleDC(nullptr);if(!dc){reason="CreateCompatibleDC failed";return false;}
  for(const wchar_t* family:{L"Georgia",L"Segoe UI"}){
   font=CreateFontW(-48,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,FF_DONTCARE,family);
   if(!font)continue;
   originalFont=SelectObject(dc,font);
   const wchar_t required[]=L"ПродатьВыпуститьРазмерВесМелкаяОбычнаяКрупнаяРыбасорвалась";
   WORD indices[sizeof(required)/sizeof(wchar_t)]{};
   bool supported=GetGlyphIndicesW(dc,required,int(sizeof(required)/sizeof(wchar_t))-1,indices,GGI_MARK_NONEXISTING_GLYPHS)!=GDI_ERROR;
   for(size_t i=0;i+1<sizeof(required)/sizeof(wchar_t);++i)if(indices[i]==0xffff)supported=false;
   TEXTMETRICW metrics{};
   if(supported&&GetTextMetricsW(dc,&metrics)&&metrics.tmHeight>0){lineHeight=metrics.tmHeight;SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(255,255,255));reason="Unicode system font ready";return true;}
   SelectObject(dc,originalFont);DeleteObject(font);font=nullptr;
  }
  reason="No system font with required Cyrillic glyphs";return false;
 }
 Glyph& glyph(wchar_t character){
  auto found=glyphs.find(character);if(found!=glyphs.end())return found->second;
  auto& item=glyphs[character];SIZE extent{};
  if(!GetTextExtentPoint32W(dc,&character,1,&extent)){reason="Glyph measurement failed";return item;}
  item.advance=extent.cx;
  if(character==L' ')return item;
  item.width=std::max(1,int(extent.cx))+6;item.height=lineHeight+6;
  BITMAPINFO info{};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
  info.bmiHeader.biWidth=item.width;info.bmiHeader.biHeight=-item.height;
  info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;info.bmiHeader.biCompression=BI_RGB;
  void* pixels=nullptr;HBITMAP bitmap=CreateDIBSection(dc,&info,DIB_RGB_COLORS,&pixels,nullptr,0);
  if(!bitmap||!pixels){if(bitmap)DeleteObject(bitmap);reason="Glyph bitmap allocation failed";return item;}
  auto previous=SelectObject(dc,bitmap);
  std::memset(pixels,0,size_t(item.width*item.height)*4);
  bool painted=TextOutW(dc,3,3,&character,1)!=0;GdiFlush();
  std::vector<uint8_t> mask(size_t(item.width*item.height));
  auto data=static_cast<uint8_t*>(pixels);
  for(size_t i=0;i<mask.size();++i)mask[i]=std::max({data[i*4],data[i*4+1],data[i*4+2]});
  SelectObject(dc,previous);DeleteObject(bitmap);
  auto file=fishing::textBitmap(mask,item.width,item.height);
  if(!painted||file.empty()){reason="Glyph rasterization failed";return item;}
  char directory[MAX_PATH]{},path[MAX_PATH]{};
  DWORD length=GetTempPathA(MAX_PATH,directory);
  if(!length||length>=MAX_PATH||!GetTempFileNameA(directory,"RHF",0,path)){reason="Temporary glyph file unavailable";return item;}
  HANDLE handle=CreateFileA(path,GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_TEMPORARY,nullptr);
  bool written=false;
  if(handle!=INVALID_HANDLE_VALUE){DWORD bytes=0;written=WriteFile(handle,file.data(),DWORD(file.size()),&bytes,nullptr)&&bytes==file.size();CloseHandle(handle);}
  if(written)item.texture=rh::loadImage(path);
  DeleteFileA(path);
  if(item.texture==UINT64_MAX)reason="Glyph texture loading failed";
  return item;
 }
public:
 const char* reason="not initialized";
 ~UnicodeText(){if(dc&&font){SelectObject(dc,originalFont);DeleteObject(font);}if(dc)DeleteDC(dc);}
 bool draw(const char* text,float x,float y,float height,int alignment){
  if(!initialize())return false;
  int count=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,text,int(std::strlen(text)),nullptr,0);
  if(count<=0){reason="Invalid UTF-8";return false;}
  std::wstring wide(size_t(count),L'\0');
  MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,text,int(std::strlen(text)),wide.data(),count);
  float pixels=0;
  for(wchar_t c:wide){auto& g=glyph(c);if(c!=L' '&&g.texture==UINT64_MAX)return false;pixels+=g.advance;}
  RECT viewport{};float aspect=1080.f/1920.f;
  if(GetClientRect(GetForegroundWindow(),&viewport)&&viewport.right>0&&viewport.bottom>0)aspect=float(viewport.bottom)/float(viewport.right);
  float unitY=height/lineHeight,unitX=unitY*aspect;
  x-=pixels*unitX*(alignment==2?1.f:alignment==1?.5f:0.f);
  for(wchar_t c:wide){
   auto& g=glyphs[c];
   if(c!=L' ')rh::drawImage(g.texture,x+(g.width*.5f-3)*unitX,y+(g.height*.5f-3)*unitY,g.width*unitX,g.height*unitY,255,255,255,255);
   x+=g.advance*unitX;
  }
  return true;
 }
};
}
