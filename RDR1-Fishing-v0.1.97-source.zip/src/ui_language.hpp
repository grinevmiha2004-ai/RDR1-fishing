#pragma once
#include <cstring>
namespace fishing {
enum class Language {English,Russian};
enum class UiText {Sell,Release,Size,Weight,Small,Normal,Large,Lost};
inline Language uiLanguage(const char* value){return value&&(std::strcmp(value,"ru")==0||std::strcmp(value,"RU")==0)?Language::Russian:Language::English;}
inline const char* uiText(UiText label,Language language){
 static const char* en[]={"Sell fish","Release fish","Size","Weight","Small","Medium","Large","Fish got away"};
 static const char* ru[]={"Продать рыбу","Выпустить рыбу","Размер","Вес","Мелкая","Обычная","Крупная","Рыба сорвалась"};
 return language==Language::Russian?ru[int(label)]:en[int(label)];
}
inline UiText sizeLabel(float weight){return weight<1?UiText::Small:weight<=5?UiText::Normal:UiText::Large;}
inline bool asciiText(const char* value){for(;*value;++value)if(static_cast<unsigned char>(*value)>=128)return false;return true;}
}
