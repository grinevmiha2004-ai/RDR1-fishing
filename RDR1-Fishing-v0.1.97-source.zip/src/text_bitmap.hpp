#pragma once
#include <algorithm>
#include <cstdint>
#include <vector>
namespace fishing {
// BMP V4: explicit straight-alpha masks, bottom-up rows; accepted by WIC/STB.
inline std::vector<uint8_t> textBitmap(const std::vector<uint8_t>& mask,int width,int height){
 if(width<=0||height<=0||width>512||height>512||mask.size()!=size_t(width*height))return {};
 std::vector<uint8_t> out(122+size_t(width*height)*4,0);
 auto put=[&](size_t at,uint32_t value){for(int i=0;i<4;++i)out[at+i]=uint8_t(value>>(8*i));};
 out[0]='B';out[1]='M';put(2,uint32_t(out.size()));put(10,122);put(14,108);
 put(18,uint32_t(width));put(22,uint32_t(height));out[26]=1;out[28]=32;
 put(30,3);put(34,uint32_t(width*height*4));
 put(54,0x00ff0000);put(58,0x0000ff00);put(62,0x000000ff);put(66,0xff000000);put(70,0x73524742);
 for(int y=0;y<height;++y)for(int x=0;x<width;++x){
  unsigned fill=mask[size_t(y*width+x)],edge=fill;
  for(int dy=-2;dy<=2;++dy)for(int dx=-2;dx<=2;++dx){
   int xx=x+dx,yy=y+dy;if(xx>=0&&yy>=0&&xx<width&&yy<height)edge=std::max(edge,unsigned(mask[size_t(yy*width+xx)]));
  }
  unsigned alpha=fill+edge*(255-fill)/255,white=alpha?fill*255/alpha:0;
  size_t at=122+size_t((height-1-y)*width+x)*4;
  out[at]=out[at+1]=out[at+2]=uint8_t(white);out[at+3]=uint8_t(alpha);
 }
 return out;
}
}
