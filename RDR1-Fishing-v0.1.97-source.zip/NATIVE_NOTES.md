# Native-call evidence (RDR.exe supplied by user)

Executable SHA256: 22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e.
Static analysis only; no claim of runtime validation for the new calls.

- `SET_OBJECT_POSITION`, hash C5D796F8: handler VA 0x14022F920 reads the object
  handle at argument slot 0, packed XY at slot 1, and Z at slot 2. The SDK signature
  and our existing packing agree; motion failure must be diagnosed through the
  boolean return and `GET_OBJECT_POSITION`, rather than assuming a packing defect.
- `SET_OBJECT_ORIENTATION`, hash C8A4EE74: handler VA 0x1402308D0 reads the same
  packed vector pattern and applies a degrees-to-radians conversion before dispatch.
- `FIND_WATER_INTERSECTION`, hash 4F193BE4: registration points to VA 0x1402965D0.
  It reads two packed vectors from argument slots 0/1 and 2/3, then vector output
  pointers from slots 4 and 5. It invokes the intersection routine at 0x140295DC0
  with the water collision mask 0x400000 and writes a boolean result. The adapter
  supplies two initialized, aligned vector outputs and two trailing zero arguments
  for the SDK's placeholder arity. Output position is validated before use.
- `WORLD_TO_SCREEN`, hash BAA72911: supplied by RedHook v0.8, not base game.
  Handler VA 0x180024780 in supplied RedHook.dll reads a position pointer and two
  float output pointers. It returns false for points outside the view; successful
  outputs are normalized screen coordinates. Used only for visual markers.
- `GET_OBJECT_NAMED_BONE_POSITION`, hash 30516389, and `GET_OBJECT_FROM_ACTOR`,
  hash 4A2063EC: typed signatures from the supplied SDK. Bone names are probed
  and validated by proximity; a body-relative fallback is used when unavailable.

No unknown animator or lasso task parameters were guessed in this release.
Player animation and WAS/WAT playback remain unfinished.

## v0.1.13 attachment and cast direction

- GET_CAMERA_CHANNEL_DIRECTION (6ED00237), handler 0x1403AAEF0:
  output vector pointer at slot 0, channel at slot 1; channel zero supported.
  Returns negated camera backward basis, the actual forward view direction.
- GET_HEADING uses atan2(actor +Z basis X, actor +Z basis Z) at 0x140AD4AB0.
  Old -sin(heading) reflected X incorrectly. The cast now uses the view vector
  directly, and yaw reconstruction uses atan2(X,Z).
- ATTACH_OBJECTS (E1421B42), handler 0x140230E80 and helper 0x1402DA4D0:
  child object, parent object, parent bone name, offset XY, offset Z,
  rotation XY (degrees), rotation Z, integer flags. 8 slots, not SDK's 10 ints.
  Parent bone resolved by helper 0x1402F2400. Child is object whose attachment
  field gets assigned at 0x1402DA8AA.
- SET_ATTACHMENT_IGNORE_ROTATION (A870B28E) writes attachment byte +0x62.
  Update 0x1402DAA5C copies existing child basis and applies only translation
  when this flag is set. This retains procedural rod rotation while binding
  the pivot to the animated hand. No finger/arm animation is claimed.
- Cleanup removes only this plugin's saved attachment before deleting the rod.

Static disassembly evidence only; in-game validation remains necessary.

## v0.1.14 live actor bone discovery

The user's 0.1.13 log contains repeated Hand bone not found and no created rod
attachment. Do not interpret that run as successful attachment validation.

GET_OBJECT_FROM_ACTOR at 0x14022BA90 is identity, returning the actor handle.
GET_OBJECT_NAMED_BONE_POSITION at 0x140230A90 resolves the handle through
RVA 0x2C36778 (16-byte records with generation at +8) and calls the object's
vtable +0x100 getter with true. Returned pose +8 is the skeleton descriptor.
Helper 0x1402D9D10 obtains the bone count at descriptor +0x30 (uint16),
and compares C-string names at the first pointer in each 0x110-byte descriptor
record through descriptor +0. This exact read-only path is used to enumerate
actual actor bone names instead of assuming animation semantic labels match.

Private offsets are gated by the supplied executable's PE timestamp 6711591D,
SizeOfImage 5A5DD600, AMD64 PE32+, and two handler fingerprints. Pointer reads
use ReadProcessMemory; counts and string lengths are bounded. The one pose
getter call has the same ABI and argument as the existing native. There are no
writes or patches to game memory. This is static ABI evidence, not a game run.

## v0.1.15 wrist_r and camera independence

The user's v0.1.14 log confirms successful live skeleton enumeration, including
wrist_r, wristroll_r and wrist_r_Attachment. Our name filter rejected wrist_r.
Use wrist_r first via the existing named-bone native and native attachment.
The classifier accepts wrist_r but rejects wristroll_r and wrist_r_Attachment.
Rod yaw now uses actor heading, not saved camera/cast direction; idle props and
fallback hand/tip positions use actor coordinates. Camera direction is sampled
only for enabling/actual cast targeting and never drives held rod yaw.
The native attachment retains procedural world rotation while following wrist
translation. Finger grip and bone-relative rod rotation are not implemented.

## v0.1.16 non-colliding held rod

User log: wrist_r resolves, attachment valid=1, Rod hand check coordinates match.
Fishing then ends with Stopped: player moved. User observes rod pushes John.

SET_OBJECT_COLLIDE_WITH_WORLD (601FC9F4), handler 0x1402331F0, reads object
slot 0 and boolean slot 1. False sets bit 0x2 in prop flags +0x1C.
SET_OBJECT_COLLIDE_WITH_MOVABLES (05D69EA6), handler 0x140233230, same ABI;
false sets bit 0x4. Both resolve the prop through helper 0x1402201D0.
Set both false immediately after spawning the rod, before any ScriptWait,
and reapply after attachment initialization. Scope is the rod object only.
Do not disable actor collision or remove the existing movement cancellation.
No in-game collision-free result is claimed until user validation.

## v0.1.17 fish orientation regression

User confirms v0.1.16 rod is attached to hand without collision, but fish is
again tail-first. Reverse only fish yaw by 180 degrees: cast bearing -90
instead of +90. Keep wrist_r, rod collision flags and camera casting untouched.
Do not treat Linux tests as in-game validation of this direction.

## v0.1.18 cast animation evidence and limits

User confirmed v0.1.17 fish retrieval/orientation works; preserve that baseline.
Supplied act.rpf SHA256:
e4e9f8f7cf4f4eafa79271476d47572c2fa9e30bcf566f4846b23d713670c955.
RPF6: 1035 entries, encrypted TOC; parsed per Magic-RDR commit
bc2b939b5f53de81450391fe834d2e35f97a982a. default_character.wat is resource
entry 13 at archive offset 0x22A000, compressed entry size 567576 bytes.
The resource's Zstandard payload decodes to 3186688 bytes, SHA256:
1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1.
ASCII clips nor_lso_stn_mid_trw_pre occur at 0x23F690, 0x23FB58;
nor_lso_stn_mid_trw_mid at 0x23DEE8, 0x23DF78 and other references.
Normal standing clips selected; horse and crouch variants deliberately omitted.
No game archive, animation binary or encryption material is shipped in the mod.

TASK_PLAY_ANIM (5AB552C6), handler 0x140C1AB30:
slot0 actor, slot1 const char* clip (<64 bytes); slots2/3/4 float;
slot5 int (MOV, not MOVSS, at 0x140C1ABEA); slots6/7 boolean;
slot8 float (MOVSS 0x140C1ABDD). SDK misdeclares slots5/8.
Task fields +4C/+50/+54/+58/+5C/+5D/+48 flow through 0x140B3B450
to 0x140CDE6F0. The clip lookup at 0x140CE7AF0 uses the actor's animation
component and actual clip name. Use existing loaded player animation data;
do not replace the player's default action tree or grant/equip a real lasso.
IS_ACTOR_ANIM_PLAYING (1ADE21EB) queries the selected clip by actor/name.
TASK_CLEAR (16876A25) releases the short requested task at Cast exit or cleanup,
including when a missing clip leaves the request pending.

Initial scalar values are .1, .1, 0, integer layer 0, false, false, float 1.
Scalar types/data flow are verified; visual meanings/tuning and playback are
not established by static inspection alone. Stage at 0 and .35s, cleanup on
Cast exit (1.1s) / F6 / player unavailable. Do not claim animation works from
request logs; look for Cast animation PLAYING. Tests cover one-shot staging,
cancellation, reset and real Game transitions; they do not execute RDR natives.

## v0.1.19 native action-tree cast route

User's v0.1.18 log: two cast attempts, TASK_PLAY_ANIM requests issued,
no PLAYING confirmation for either clip. This proves non-playback, not why the
queue/clip path failed. Replace that route with explicit existing action nodes.

Recovered root from WAT +8 -> 0xA7070; node parent +4, children pointer +8,
child count uint16 +0xC, local name JOAAT hash +0x20. Traverse actual links:
default_character_Main BD701184 (root 0xA7070)
Gunplay 18E67533 (0xB4340)
THROWING 38D89C16 (0x11AEC0)
Lasso 2A083060 (0xA91C0)
LassoNor 29483E1E (0xA92C0)
ThrowStand 46160C03 (0xA9340)
ThrowMid 044EFD54 (0xA9540).
LassoNor selects normal standing, rather than LassoCrouch (6D8A9E41),
LassoAim (7A7EA5CC), Gunplay_AI (F6AD55F0), horse or cover branches.
Animation expression 0x19E5A0 references nor_lso_stn_mid_trw_pre and attaches
to ThrowStand; expression 0x92B48 references nor_lso_stn_mid_trw_mid and
attaches to ThrowMid. Parent-child hierarchy is verified from the shipped
source header constants by tools/verify_cast_action_tree.py on decompressed WAT.

SET_ACTION_NODE_FOR_ACTOR 5A795F3A -> handler 0x140CE0CE0 -> helper
0x140CDFA20. Actor and string, returns boolean. Helper prepends Global\%s,
so pass default_character_Main\Gunplay\THROWING\Lasso\LassoNor\ThrowStand
WITHOUT an additional Global prefix. Parser 0x14058FA70 accepts both slash
and backslash (delimiter bytes at VA 0x141CBF0E0 are "\\/\0").
IS_ACTOR_PLAYING_NODE_IN_TREE 4E0300E2 -> helper 0x140CDF940 looks up same
path and walks active node's parent links. This confirms activation separately
from IS_ACTOR_ANIM_PLAYING clip playback. RESET_ACTIONTREE_FOR_ACTOR
07EC142B -> 0x140CE0D70 restores actor default processing. Call only if our
node override was accepted, on Cast exit or cleanup. No TASK_CLEAR is used.

Timing remains initial integration tuning. Direct action nodes have not been
run in the game here; neither accepted nor Linux tests establish visible motion.

## v0.1.22 return to observed v0.1.19 node route

0.1.21 log: loaded=0 for both names, never bound/activated a node. Do not treat
that as evidence against the action-node route: it did not execute at all.
User reports a brief visible twitch in 0.1.19. Return to that exact verified
WAT path without separate animset requests or private direct-play calls.

Hypothesis tested: ordinary player control interrupts the scripted node.
IS_PLAYER_CONTROLLABLE 9613C2D0 -> 0x140AD7100 inspects the player's control
mask and state. SET_PLAYER_CONTROL D17AFCD8 -> 0x140AD6F60 reads enable at
slot1 and integer flags at slots2/3. With 0,0 it sets/clears only the script bit
(bit0 of controller +0x104), preserving other disable mask bits. Use
(0,false,0,0) only if initially controllable; matching true restores that bit.
Restoration is outside actor-valid checks, so death/cancellation cannot skip it.
F6 uses GetAsyncKeyState independently. Player controls remain disabled only
for this bounded sequence; closing the game before replacing/unloading the
plugin remains required. Other mods/scripts changing control concurrently
cannot be distinguished by this native bit alone.

Retain completion-feedback state machine from 0.1.20, not the early hard
.35/1.1 cutoffs of 0.1.19. At most 3.2s total with confirmed looping clips;
1.8s total for entirely unconfirmed clips. F6/death/movement cancel immediately.
Log live node activity/time every .1s and on changes, not just first ACTIVE.
Do not force-restart a node every frame, which would itself prevent progress.
Portable tests verify control ownership/restoration and bounded animation flow.
Visible playback still requires game validation; ordinary-control interruption
remains a hypothesis until new runtime samples confirm it.

## v0.1.23 verified lso set and standalone scripted playback

User-supplied animationres.rpf SHA256:
b4baf2dc9f28efa31f293983d1101fa00d33e29690b7f2b3c7a5dacb681e9dd7.
RPF6 has 1345 WAS resources. Entry 452 lso.was contains both standing cast clips.
Its decompressed payload is 598016 bytes, SHA256
7975b6f7294d192f2ecdea03b78d5293ac25566717b06fd762cbdb57da84075f.
Header name lso.ast at +0x38; clip strings at 0x6EB90 (pre), 0x6E9D8 (mid);
JOAAT hashes F6A844F3 and CC863451 are present in the resource.
Entry 1117 lso_base.was does not contain either literal cast clip.
No WAS/WAT, game EXE, archive key, or other game asset is redistributed.

ThrowMid WAT 0xA9540 has transition track 0x1C3420 to root 0xA7070.
Condition array 0x2ED420: NOT operand 1 at 0x1B1FFC, then WeaponAnimSet
type 224, enum 8 LASSO, flags 0 at 0x305FC0. Other exits use LassoState
(type 137): ATTACHED/TUG_WAR and FAIL_ATTACH/UNATTACHED.
Registry 0x140592B00 installs 12 base conditions; 0x140CA2D90 adds game conditions.
Game index 212 + 12 = WeaponAnimSet 224; index 125 + 12 = LassoState 137.
Weapon enum strings at VA 0x142293360, LASSO at index 8.
Evaluator 0x140D98420 checks actual current weapon type, not requested clip name.
This is a static immediate-exit mechanism; no claim of observing the exact taken
branch in the user's live run is made. Do not force-restart these nodes.

REQUEST_ANIM_SET (2988B3FC): const char* name, integer flag; handler 0x140CE0600.
HAS_ANIM_SET_LOADED (4FFF397D): name; handler 0x140CE0640 checks loaded resource.
SET_ANIM_SET_FOR_ACTOR (39C1E1C0): actor handle, const char* name, integer flag.
Handler 0x140CE06C0 resolves the actor, resource, then calls 0x140CE8D30.
Flag 0 respects an existing script lock at animation component +0xC6A.
The public API stores the override at +0x9A8 and sets the lock.
ACTOR_HAS_ANIM_SET (31F5F57D), handler 0x140CE0160, compares the current
override resource's name against the argument.
RESET_ANIM_SET_FOR_ACTOR (7A6C5C2F), handler 0x140CE0800, clears +0x9A8
and +0xC6A and refreshes the normal action tree. Flag 1 avoids the full
animator-reset branch selected by flag 0; it still restores normal tree processing.
REMOVE_ANIM_SET (D04A817A): name, balances the plugin streaming request on F6/cleanup.

Ownership reads only: wrapper table at module+0x2C36778 -> wrapper+b0 internal
actor handle -> table module+0x2C36768 -> actor+0x38 animation component.
Read +0x9A8 and +0xC6A only, through ReadProcessMemory, with handle generations,
PE profile and ACTOR_HAS_ANIM_SET instruction fingerprint checks.
Do not overwrite any pre-existing override. Remember our resource identity;
cleanup only clears our task/override if identity still matches and native
ACTOR_HAS_ANIM_SET confirms lso. No engine-memory patches or private engine calls.

TASK_PLAY_ANIM parameters keep the already verified ABI from 0.1.18:
(actor, clip, float .1, float .1, float 0, int 0, bool false, bool false, float 1).
This time clip resolution can search the attached, verified lso set through
0x140CE7AF0, instead of relying on the actor having it from a weapon.
The native's queued task is cleared with TASK_CLEAR (16876A25) during owned
cleanup. Actor controls are scoped as before.
Tests cover delayed streaming across Cast->Wait, cancellation before binding,
binding rejection without repeated retry, bounded timeouts and paused time,
in addition to previous animation and gameplay tests.
Static validation and compilation do not establish visible animation success.

## v0.1.24 zero-rate regression in TASK_PLAY_ANIM

User's v0.1.23 Fishing.log: 139 samples, 111 with playing=1 and clipTime=0.0000;
28 with playing=0 and clipTime=-1. No sample has positive clip time.
setAttached=1 and successful bind prove lso was attached; these observations
do not prove visible animation.

The v0.1.23 scalar values were wrong, despite their ABI types being correct.
Zero-based native slot 4 is a playback-rate multiplier, not an unused scalar:
0x140C1ABF5 loads [native args+0x20] into xmm7; 0x140C1AC58 stores xmm7 to
queued task+0x54. Task update 0x140B3B493 loads task+0x54; 0x140B3B4AE
passes it in stack slot +0x28 to 0x140CDE6F0. That function's prologue
relocates it to rsp+0x108. 0x140CDEAA9 loads it, then 0x140CDEAB2
multiplies by actor animation component+0xA10. 0x140CDEBB3 stores the
result in the scripted clip playback state+0x48. Therefore the supplied zero
zeroes the playback-rate field. Native clip-time query uses state+0x38 divided
by duration at 0x140CEFD9A..0x140CEFDA2. Zero playback rate explains the log's
stationary time even when the selected clip matches.

Native slot 8 is separate: task+0x48 -> caller stack+0x48 -> callee rsp+0x128
-> actor animation component+0xA94 at 0x140CDED3D..0x140CDED56.
The update at 0x140CEFB95 tests this timer against zero; when positive it
subtracts actor frame time at 0x140CEFBB1 and triggers completion once elapsed.
Negative disables this optional timer, as in the engine's own -1 initialization.
Use slot4=float 1, slot8=float -1. Integer layer and boolean arguments retain
the already verified types. No repeated native requests or forced clock writes.

Named, typed requestCastClip helper is shared by plugin and portable tests.
Tests capture the actual submitted arguments and reject a zero rate/wrong ABI;
progress detection is checked against the user's repeated-zero sample pattern.
Diagnostics now say MATCHED for pointer/name selection; ADVANCING requires
an increase between two valid native time readings. This is stronger evidence
than playing=1, but still does not prove the visible pose without a game run.
No changes to rig, collisions, camera direction, fish yaw, input bindings or INI.

## v0.1.25 synchronization and native exit blending

User's v0.1.24 log includes 14 casts. Main standing throw advances in 13,
with most complete attempts ending at sampled normalized time 0.975–0.988
then normal cleanup around 1.86–1.92 seconds after E. Windup is absent in
6 attempts, falling back after 0.8 seconds; successful windup lasts about
0.83 seconds. Main clip lasts about 1.07 seconds. One movement cancellation
interrupts an early attempt; another F6 stop interrupts release at ~0.69.
These intentional cancellations must not be counted as successful completions.

Old projectile flight starts at E and game Cast ends at 1.1 seconds.
Animation release instead starts at 0.8–0.84 seconds. This is a verified
synchronization defect, not evidence of a universally interrupted clip.
Now game Cast time and projectile remain held until the Release command.
The existing 1.1-second trajectory runs from that command; forward remains
the camera snapshot from E. Failure/rejection releases the fallback flight.

Separate the public actor-set bind and first TASK_PLAY_ANIM submission by
one engine frame. This removes same-frame ordering, a candidate cause of
missing first clip. No live evidence yet proves this eliminates that failure.
No repeated per-frame clip requests and no forced clock writes.

The native request's exit blend argument is now 0.25 instead of 0.1.
After Release completes, the portable plan waits for that blend period before
resetting its owned actor-set override. A naturally ended clip with observed
progress >=0.95 does not get a second TASK_CLEAR during cleanup.
Watchdog or cancellation still clears our task immediately when required.
Rod pitch interpolates over that same exit period; no attachment/collision,
fish yaw, camera, control binding or INI changes.

Regression tests exercise observed windup-present and windup-missing paths
against the actual Game and animation plan: no game Cast elapsed time before
Release, then 1.1 seconds to landing, then completed native fade before cleanup.
Binding readiness is one frame after successful actor-set binding.
New in-game visual validation remains necessary.

## v0.1.26 single-clip selection and explicit end reasons

Re-audited all throw-name strings in lso.was and their task references in
default_character.wat. tools/audit_lasso_clips.py records exact node/track
assignments; LASSO_CLIPS.md documents the selection and visual limits.
Only nor_lso_stn_mid_trw_mid is requested. The user explicitly rejected the
preparation motion; remove Windup state/command rather than shortening or
speeding it. No alternative walking/running or success/failure pose is guessed.
The historical pre constant is only input to static hierarchy verification and
is not emitted into the optimized DLL.

The uploaded log contains sessions from 0.1.24 and 0.1.25. In latest-version
runs, main normally reaches ~0.988 and then becomes unmatched; it is not
universally cut off early. One main request is missing entirely.
New controller tracks max native normalized time and distinguishes completed
(>=0.95 then unmatched), interrupted, missing, watchdog, and cancellation.
Only natural completion skips TASK_CLEAR; non-natural termination still cleans
our task. No new native hashes, private engine calls or memory writes added.
Rate, disabled seconds timer, owned-set checks and cancellable fade remain.
Portable tests replay natural ~1.07s progress plus missing, early-loss and
looping sequences. They verify one Release command with no former windup
delay, flight/landing synchronization and cancellable exit blending.

## v0.1.27 loop override and flight-owned hold

The user clarified that the desired second phase holds arms forward until
projectile landing. One-shot playback returning after ~1.07s is the wrong
lifecycle even when the clip reaches its authored end.

Native zero-based slot 6 is the loop override. TASK_PLAY_ANIM captures it as
byte task+0x5C; task update passes it at caller stack+0x38. Callee
0x140CDE6F0 prologue maps this to rsp+0x118. At 0x140CDEC8A the byte is
loaded and stored to playback state+0x59, with +0x58 forced to 1.
Completion logic 0x140CEF6B2 checks +0x58; if set, uses +0x59 instead of
the clip default at resource+0x30, and a true value bypasses natural-end
completion. The real native request now passes boolean true in slot 6.
No phase locking, forced time writes, private engine calls or frame-by-frame
TASK_PLAY_ANIM resubmission are introduced.

Lifecycle: Request -> AwaitStart -> native time >0.001 -> Launch -> Holding
while Game remains in Cast -> EndHold on landing -> cancellable native fade
-> release owned actor override. Loop wrap is valid progress, not completion.
TASK_CLEAR is issued once at EndHold, then the set remains during fade.
A six-second hold watchdog exceeds the maximum four-second flight.

Startup reliability: one retry after 0.25s only when native matching is false,
before flight launch. It clears only the pending owned task and resubmits once.
A matched zero-time clip is never restarted. One-second startup deadline
fails into ordinary projectile flight and cleans the owned animation state.
This is bounded recovery, not proof of the original intermittent failure's cause.

Game.castSeconds defaults to the old 1.1 seconds. For animated casting,
prepareCast sets it to clamp(actual XZ distance / 5, 1.1, 4). Both visual arc
and procedural rod pitch use this same duration, and Wait begins at its end.
All catch/bite/reeling mechanics and INI schema remain unchanged.
Tests cover absent/matched-zero startup, one retry only, active-loop wrap,
3/9/20m landing synchronization, cancellation at every stage and watchdog.
No current in-game evidence is claimed for this release.

## v0.1.28 face fixed camera cast direction before animation

User confirms v0.1.27 is the desired animation/hold behavior. Preserve that
controller, playback flags, retry policy and flight timing unchanged.
Remaining defect: animation follows actor yaw, projectile follows the saved
camera forward, so a side-looking camera produces a sideways cast.

SET_ACTOR_HEADING ECE8520B handler VA 0x140AD6950 reads actor, float degrees
from slot 1 at 0x140AD69B4, and boolean/int flag slot 2 at 0x140AD69BA.
It converts degrees to radians at 0x140AD69BE, then calls 0x140AD4B10.
The helper builds a yaw matrix and copies the actor's existing XYZ from its
current transform at 0x140AD4BC3..0x140AD4BE1 before applying the transform.
GET_HEADING uses atan2(actor +Z basis X, actor +Z basis Z), as verified earlier.
Target = atan2(savedForward.x, savedForward.z)*57.295779513; no reflected X.
Native is invoked with flag false; no unverified flag semantics are assumed.

CastTurn starts only after a valid camera/water target was accepted. The
owned set is bound and scoped player controls acquired as in v0.1.27.
Before any clip request, approach target through shortest signed remainder
at <=360 degrees per game second. Read back heading on a later frame and
start animation only within 0.5 degrees. Pause consumes no turn time.
A 1.25-second convergence guard exits to ordinary flight rather than hanging.
No camera resampling during this operation. No continued heading writes once
aligned. Actor facing is intentionally not restored to the pre-cast heading.
F6/death/transport cleanup resets pending turn and existing scoped resources.

Tests cover cardinal/pitched/diagonal views and starting headings including
179/-179/359 degrees, shortest seam crossing, fixed-target capture, bounded
turn steps, clip-start gating, paused time, blocked turn timeout and cancel.
No new private offsets or direct engine calls are introduced.
This validates logic/ABI, not a live visual turn in RDR.


## v0.1.29 correct visible front offset

The user's live v0.1.28 test reports John facing the camera, opposite the
saved camera cast ray. The previous assumption that native transform +Z
was John's visible front was wrong. Native get/set consistency alone did
not establish visible facing. Apply +180 degrees only to CastTurn's target;
leave camera direction, actorForward, rod geometry and fish yaw unchanged.
Tests now compare visible front (-sin heading, 0, -cos heading) with the
saved ray in all quadrants, based on that runtime observation. This is a
regression check of the corrected model, not a new visual game test.


## v0.1.30 Fight-only lasso capture stance candidate

Baseline v0.1.29 is user-confirmed; retain its archives and immutable tag.
Choose nor_lso_stn_mid_trw_suc from the same lso set. Real WAT node 0xAD380
has animation track 0x9904C naming this clip, and child 0xAD440 owns separate
pull-in/yank/tug actions. Thus this is the capture-success parent animation,
not a hogtie/victim clip. That assignment is static evidence, not proof of
the desired visible two-hand fishing pose. verify_fight_resources.py checks
exact asset hashes, clip key/hash and these authored relationships.

FightPose runs only after the Bite->Fight transition, throughout R/Q/release.
It borrows the existing lso binding/ownership and scoped controls only after
releasing the cast session. The cast controller is not updated during Fight;
its headers and camera/fish math remain byte-identical to v0.1.29.
TASK_PLAY_ANIM uses the verified existing ABI, speed 1, loop true, timer -1.
There is one task request, one missing-only startup retry at 0.25s, a 1s
startup deadline, and no restarts after any observed clip match. Two different
native clip-time observations establish the ADVANCING log. Loop wraps do
not restart the task. A missing running clip for 0.25s ends the pose session.
No real target, lasso weapon, tying task, transition nodes or bone writes
are invoked. End Fight/F6/death/transport/move-away all release our task/set
and restore only our owned player control bit. Existing actor overrides
are rejected rather than replaced; ownership changes stop our session.
Animation.Fight defaults to 1 when absent; Fight=0 disables this experiment
without changing the working cast. Portable tests cover long looped fights,
startup failures, frozen clock, interruption, cancellation and idempotent release.
The pose's visual fit is unverified until a real RDR run by the user.


## v0.1.31 stationary hold instead of capture pull-back

User rejects v0.1.30 as a backward pulling movement. Uploaded Fishing.log
SHA256: 2693bc4939ecc165cc2d04dc7af7d05440ff06687aaa699a5d620b57b5f280dd. It records successful matching/time advancement
and repeated normalized-time wraps through Fight, ending cleanly on Lost.
This rules out a missing/aborted clip for that test; it does not establish
pose geometry independently of the user's observation.

Inspecting only animation tracks 28/35 missed locomotion task type 77.
WAT hold-state node 0xAD440 (child of success node 0xAD380) has eight task-77
tracks at 0x4C24C, 0x4C188, 0x4C0C4, 0x4BE8C, 0x4BB7C, 0x4B9F4,
0x4B930 and 0x45E8C. Each has nor_lso_pul_stn at +0xA4, then distinct
nor_lso_pul_wlk_XXX and nor_lso_pul_run_XXX pointers at +0xA8/+0xAC.
Thus the stationary base is nor_lso_pul_stn, not the parent success clip.
A read-only scan/decompression of all WAS entries in animationres.rpf found
this clip's name in gent.was only (not lso, lso_base or pull_leash).
Exact gent.was SHA256 93df0fc0d395980051606b5e496abd0ddae1ae97c300e2910d3d156123b772b7,
size 7258112, set header gent.ast. Short name key 0xF12ADCB8 also present.
verify_fight_resources.py verifies hashes and all eight stationary slots.

Preload gent independently at F6, stream-check and bind it only for Fight.
Generalize the existing binding helper to accept a set name (default lso
for the unchanged cast path). Track ownedAnimSet alongside the resource
pointer so stop/reset checks and logs use the actual current set; release
both streaming requests only on fishing cleanup. Existing script overrides
are still rejected, and ownership loss never resets the other owner's set.
Fight startup/loop/retry/cancel policy is unchanged from v0.1.30. The rejected
clip is absent from runtime code. Cast controller/turn/math remain unchanged.
Do not infer the exact two-hand visible pose from these static assignments;
user game testing is still needed. Baseline tag/archives 0.1.29 stay intact.


## v0.1.32 native base-set shortcut blocked by plugin check

User's 0.1.31 log shows two Fight attempts, both accepted=1 attached=0,
then plugin failure before TASK_PLAY_ANIM. This is not clip rejection.
In SET_ANIM_SET_FOR_ACTOR helper 0x140CE8D30, compare with override at
+0x9A8 happens at 0x140CE8D53. If different, 0x140CE8D70 compares requested
resource with base set +0xB18 and jumps directly to true return 0x140CE8D63
when equal. That branch neither writes override nor sets lock +0xC6A.
Override store only happens later at 0x140CE8DC5. ACTOR_HAS_ANIM_SET reads
override +0x9A8 exclusively. Thus requesting an already-base gent returns
true while ACTOR_HAS_ANIM_SET remains false. v0.1.31 wrongly rejected this.

Extend the existing profile-checked read-only snapshot by base resource
+0xB18. Base-mode acceptance requires native success, attached=false, no
override or lock before/after, and the same nonzero base identity before
and after. Only Fight opts into this path. Cast still requires an owned
locked override. No memory writes, lock forcing or private calls added.
During a base-mode Fight, monitor base identity and reject new overrides
or script locks. On exit clear our issued animation task only; do not call
RESET_ANIM_SET_FOR_ACTOR on the native base. Restore only owned controls.
Override sessions keep the previous cleanup. The clip and playback policy
are unchanged. Tests reproduce accepted=1/attached=0 and reject failed calls,
changed/missing base, competing overrides/locks, and base-mode for Cast.
EXE verification checks the base-compare/true-return/store instruction bytes.
No claim of live playback or visible two-hand fit is made by these tests.


## v0.1.33 stationary frame from backward-left lasso locomotion

User confirms v0.1.32 playback works; the previous pose holds loop and coil
in separate hands. User identifies backward-left dragging as the desired
closely spaced hands, and asks to keep John stationary.

WAT task-77 track 0x4C188 has standing nor_lso_pul_stn at +0xA4,
walking nor_lso_pul_wlk_225 at +0xA8 and running counterpart at +0xAC.
Unlike the stationary clip, directional aliases are in lso_base, not gent.
All-WAS text searches miss this because the alias ordering differs from the
source name. Search runtime key 0xE8323B4F; lso_base.was hash
8421b46d94cb22cfca7e3bac3fd0737dbd4a68551029881fa73399de53d48185,
size 1064960. Entry at 0x100E58 points to resource 0xBDFC0, whose name
pointer at +8 resolves to Human\Gent\gent_nor_lso_225_pul_wlk.
The resource verifier checks both the key-to-source mapping and WAT track.

Use the confirmed TASK_PLAY_ANIM ABI with task-local rate 0 deliberately,
loop true and timer -1. The previous zero-rate cast failure established that
this holds the initial frame rather than advancing. Here a static frame is
intentional to avoid walking feet/root progression. No global animator
speed or coordinate natives are modified; cast stays rate 1. The exact
zero frame's hand/rod and foot alignment is a visual experiment, not proven
by the clip label or a successful native call. No attempt to restart tasks
per frame or manipulate the root is introduced.

FightPose opts into staticPose=true: two valid playing/time observations
establish Holding even with unchanged time. Existing moving-mode advancement
checks are retained and tested. Log MATCHED instead of ADVANCING for this
experiment. Existing bounded loading/startup, missing-only retry, ownership
checks, base/override handling and cancellation remain. Tests exercise the
actual typed task request, zero float rate, clip key, frozen-time hold for
100 seconds with no replay, and release. Baseline 0.1.29 retained.


## v0.1.34 normal evaluation before frame seeking

User reports invisible pose in 0.1.33; log matches the clip continuously
with clipTime=0.0000. That establishes an active frozen task, not visible
pose evaluation. Start with verified rate 1 and require time advancement.
Only in Holding, with matching clip, verified ownership and positive dt,
invoke SET_ACTOR_ANIM_CURRENT_TIME(actor, .25f). Handler 0x140CE0130 wraps
0x140CDF150 through 0x1402846A0. The wrapper loads float slot 1 at
0x14028470C; the implementation seeks the current custom task, and helper
0x140CD8D47 multiplies requested phase by clip duration (normalized time).
Never pass a string or integer in slot 1 despite SDK guessed signature.
Do not call the seek on cast tasks or after ownership loss. Failure ends
our pose session. No task replay/global speed/actor coordinates added.
Game visual verification remains necessary.


## v0.1.35 Wait/Bite stance, Fight crossfade, free camera controls

Wait/Bite use confirmed v0.1.32 gent / nor_lso_pul_stn after existing cast
hold/blend-out finishes. Ready stays unposed. At Fight reset only the pose
controller; when gent is the native base, retain its running task and bind
lso_base without TASK_CLEAR, then request target clip with 0.65s blend-in.
The target frame remains 0.25 as in v0.1.34. Initial Wait uses 0.45s blend.
If gent was an override, release our override before changing sets; visual
continuity of that fallback is unverified. Preload both sets at enable and
balance both requests at cleanup. Failure/cancellation during handoff also
cleans any retained base task. Never modify a competing override.

Binding now takes ownControls=true by default (unchanged cast). Post-cast
poses explicitly pass false: no SET_PLAYER_CONTROL disable for Wait/Bite/
Fight. This removes the plugin's camera-blocking cause, but live interaction
of player input and the animation remains untested. Do not reissue interrupted
poses every frame to fight ordinary controls. Main-loop scheduling prevents
cast cleanup from clearing an owned post-cast pose. All portable existing
lifecycle tests pass, plus actual target request checks 0.65 blend and rate1.
Game verification is still needed for crossfade appearance and camera.


## v0.1.36 straight-back clip and continuous seek phase

User clarifies straight backward dragging of a tied actor, not diagonal.
Use nor_lso_pul_wlk_180, runtime key 0x00E30FE3 at WAS 0x101240,
resource 0xBD200 whose +8 points to Human\Gent\gent_nor_lso_180_pul_wlk.
WAT hold task77 track 0x4C24C +0xA8 selects this key. Fingerprinted lso_base
asset is unchanged. This is authored directional evidence; visible fit still
needs user verification, including whether it matches the tied-target case.

0.1.35 log shows startup at normalized .0236 followed by steady .2617,
consistent with our immediate seek to .25 plus one engine frame. This is a
potential source of a visual snap, not proof of a particular blend bug.
Replace immediate seek with FightFrameTransition: capture observed phase,
then smoothstep from it to .25 over .8 game seconds. First seek equals
observed time; subsequent target increments are continuous and bounded.
Native task blend .65, Wait/Bite clip and free controls remain unchanged.
This is native blending plus gradual seek, not a newly recovered dedicated
transition clip. Do not claim reproduction of the full gameplay transition
without game testing. Tests cover initial continuity, monotonic smooth phase,
final hold, session reset and paused time. Baseline retained.


## v0.1.41 integrate user-selected diagnostic clip

User explicitly confirms key3 of v0.1.40 as the desired clip. Immutable
picker mapping: nor_lso_pul_wlk_000 from lso_base. Log SHA256
034a1a4f67ddcd9be908552517f86f801eb8de6448bf6f9b21b59728f41cfda6
records key3 selection and P freeze phase .2366, followed by continuous
matched samples around .2469 (one frame after seek). Clip identity is user-
confirmed; that freeze phase is recorded evidence, not a separate explicit
user endorsement of a final automatic transition.

Start from the normal v0.1.36 controller, not from diagnostic game-pause
logic. Change clip to selected 000 and target phase to recorded .2366.
Retain existing .65 blend and .8 smooth phase easing. Restore ordinary
Fight dt, tension, R/Q, catch/loss and HUD; no picker bindings or pause.
Wait/Bite stance and free post-cast controls preserved. Cast untouched.
Key 2BE2A272 at WAS101060 maps to actual gent_nor_lso_000_pul_wlk;
WAT direction track 4BB7C. Static mapping verified. Do not infer screen-
space direction from 000/180 suffix: the user's visual choice is decisive.
Baseline0.1.29 remains the primary rollback point; integrated release needs
its own user game validation. Preserve diagnostic0.1.40 for comparisons.


## v0.1.42 modest later stop on confirmed clip

User clarifies .2366 was an incidental diagnostic stop, not an endorsed
final pose, and explicitly asks to move the stop slightly later without
further calibration. Keep confirmed key3 clip nor_lso_pul_wlk_000; change
held normalized phase from .2366 to .35. Preserve .8s ease/.65s blend and
all ordinary fishing logic. Target .35 is a requested empirical adjustment,
not visually verified. Tests retain phase continuity and bounded steps.
Baseline unchanged.


## v0.1.43 one more second of real motion before capture

User explicitly asks another whole second before stopping. Do not merely
slow easing to the same .35 phase. Replace fixed-phase easing with normal
native playback for1.8 seconds after verified advancement (prior .8+1.0).
No seek during that window; after it capture observed normalized phase and
hold it with existing matched/owned task guards. The cyclic clip may wrap;
this is a real time delay, not an assertion of a particular final hand pose.
Keep positive playback rate, clip3, .65 blend and free post-cast controls.
Tests cover exact delay, pause, phase capture across wraps and reset.
Live pose still needs verification. Baseline unchanged.


## v0.1.45 explicitly confirmed final diagnostic stop

User calls the newest uploaded log's last stop correct. Last frozen=1
entry at 8704250ms is clip nor_lso_pul_wlk_000, phase .5238, followed by
F6 at8724390ms. Earlier stops .1285/.2155/.6569/.1904 are superseded.
Normal build uses the exact .5238 phase. Let rate1 task play naturally;
track successive observed normalized phases and seek only on target crossing.
Then hold .5238. No arbitrary elapsed timer or forced phase easing. Handle
loop wrap if the first observed time is already past target. Keep startup
advancement/ownership guards, normal game dt and cancellation. Log first hold.
Tests cover crossing, no early seek, exact hold, pause, invalid time and wrap.
User confirmed diagnostic pose; integrated transition still needs game test.
Baseline0.1.29 remains primary rollback point.


## v0.1.46 hold-to-spin release-to-cast experiment

User promotes v0.1.45 to primary baseline. Immutable baseline-v0.1.45 tag
points to6ce9e22; hashes stored in WORKING_BASELINE.md. Preserve .5238 Fight
pose, free post-cast controls and Wait stance. Never overwrite baseline ZIPs.

Spin candidate nor_lso_stn_aup_swing, alias in lso_base at0x102204, resolves
to Human\Gent\gent_nor_lso_stn_aup_swing__SUBTRACT. Real WAT standing
swing nodes AAC00/AB000/AB300 use tracks9404C/94428 naming it. AUP swing
is distinct from throw-pre. Its subtractive nature is a real limitation:
a direct task's visible correctness is not established by compilation or
name/hash verification. No invented layer values/private writes introduced.

CastCharge begins only after successful camera/water validation on Ready E.
Game stays Cast but flight dt is gated to0 while held. Direction is immutable
from first press. Existing turn and scoped controls run before spin startup.
Preload lso_base separately, bind it during charge; use bounded FightPose
startup/missing-only retry but unlimited matched loop duration. Streaming,
turn or ownership failure does not release flight while key remains held.
Release is latched across loading/turn. At release clear our spin task/set,
restore owned controls, reinitialize the confirmed lso cast path with saved
forward and re-read actor heading. If still holding after a failed spin,
wait for release, do not retry every frame. Animation disabled uses release
gate directly. F6/death/move/transport cleanup resets charge and spin request.

During charge only, set existing attachment preserve-rotation flag false so
rod follows wrist rotation; omit procedural world rotation then. Restore
true and existing rod rotation after release. No offsets/collisions/fish math
changed. Hand-axis visual alignment still needs a user test. Tests cover
long hold/no flight, latched release, early release, cancellation and actual
typed positive-rate loop request. Post-cast header/controllers unchanged.


## v0.1.48 proper additive engine route experiment

Static proof: serialized AnimationTrack +1C is BlendMode, mapped to runtime
+28 by D3C370/serializerD57D40. Spin has1; normal cast has0. Dispatcher
D42330 reads +28 and calls CEDF50 for mode1, rather than normal CEF240 or
public TASK_PLAY_ANIM's CDE6F0. Base nor_lso_stn_aup is an absolute clip;
only that base is submitted through the existing positive-rate task helper.

Recover signatures from actual caller and callees, x64:
CE7AF0(component, ClipRef* out, uint32 key, const char* name, bool false,
 uintptr zero) returns an owning clip ref, as witnessed by callers' release.
CEDF50(component, ClipRef*, bool persistent=false, bool loop=true,
 float phaseIn=.1, float phaseOut=.15, float rate=1, int focus=0).
Five exact code fingerprints include D4275C callsite that sets this ABI.
26EF30(ClipRef* dst, const ClipRef* src) owns ref assignment/release; use it
with a local null ref to release our reference, never manually edit refcounts.

Start only after base clip advancement and our owned animset validation.
Read-only component resolution reuses existing profile/generation guard.
Reject pre-existing additive resources at +B40..+B68, missing context/primary
animator or zero capacity. Call lookup once, start once, verify our ref appears
in the six additive slots. Failed start does not silently retry as full-body.
Track our component/ref identity; per-frame logs read layer phase +B70+i*4.
This phase read is diagnostic; visible correctness is not inferred from it.

Cleanup mirrors AnimationTrack leave D42020, using minimal local state/data/
context buffers with verified offsets: blend mode1, loop1, interruptible1,
empty-handed-preserve1, gesture flags0, context+30=component, state+28=clip,
state+40=data,state+48=context. Branches that mutate ordinary task/mover
tracking are bypassed. That engine method marks only the matching layer's
stop bit +C36, as in D42236..D42250; it does not clear other layers. Engine
fade retains its own clip ref while our lookup ref is released via26EF30.
No WriteProcessMemory, code patches, global animator speed or coordinate
compensation. Guard same actor/component before leave; release own resource
independently if actor is gone. All private calls are gated by exact EXE
profile plus fingerprints. Unsupported/profile-modified code skips playback.

Portable tests validate typed additive ABI, occupied-layer rejection and
local leave buffer layout. verify_additive_abi.py checks exact executable
hash, runtime fingerprints, authored modes and dispatch call target. These
are static/logic checks, not live RDR verification. Normal rod rotation is
kept for this body-pose experiment; v0.1.46 rotation inheritance is excluded.
Baseline v0.1.45 remains primary, user visual test still necessary.


## v0.1.49 existing additive layers are normal

User log of0.1.48 shows attached=0 reason=existing additive layers in four
attempts, base plays continuously and no layer is attached. That guard
prevented the engine call, so no new conclusion about the clip or CEDF50
playback can be drawn. The all-empty prerequisite was overly restrictive.

Require at least one empty slot rather than all6. Preserve existing refs;
let CEDF50 enforce its native slot ranges/capacity and expire its own old
entries. Do not modify capacity or clear existing layers. After lookup,
reject the same clip if it already belongs to another layer, releasing only
our lookup ref without calling leave on that other layer. Report actual
occupied/capacity on startup. Add portable tests for empty, partially occupied,
full and last-free-slot cases. Other ABI/ownership guards remain unchanged.
User game validation is still needed. Baseline0.1.45 unchanged.


## v0.1.50 coherent tackle visual rig

User confirms spin now moves but requests initial tackle at tip/visible line,
airborne tackle orbit and wrist-following pole tilt. Add portable TackleMotion.
Ready/stowed positions are actual joint5 minus .35Y for float/.55Y for hook;
retain existing checked fallback tip if bone unavailable. All prop transforms
are set in the same script tick as creation, before first queued draw. Disable
world/movable collisions for these visual-only float/hook props using the same
already verified natives as the rod. No actor collision or height changes.

Whirl starts only when the owned additive is actually matched. Switch the
existing attachment preserve-world-rotation flag to false; do not apply the
procedural C8A4 pole world rotation until flight starts. Wrist attachment
and collisions remain. Thus the real joint5 geometry follows hand rotation.
Orbit ramps over .55s from prior endpoints, radii1.1/1.3m, around tip in a
plane normal to actual tip-hand vector. Native additive phase deltas drive
angle when advancing; fallback9.1rad/s if unavailable/stale. Clock pauses
atdt0. On release keep orbit until native throw advancement launches flight.
If animation fails while still held, stow instead of continuing ghost spin.

Capture both endpoints and capped world velocities (12m/s) at launch. Cubic
Hermite path starts at those exact positions/velocities, ends at water target
and hook .3 below; squared-sine arc has zero endpoint derivative. No moving
hand start point. Rendering draws tip->float->hook with explicit float vertex
and small taut-line sag during spin; Ready is now included. Water Fight/Bite/
Wait endpoint calculations and fish yaw are unchanged. F6 resets rig state.

Tests cover initial hanging offsets, all line endpoints, sustained airborne
orbit, native phase loops/fallback, tilted orbit plane and degenerate axes,
pause, exact flight start/landing, velocity continuity and fresh second cast.
No RDR visual execution claimed. Fingerprinted additive path from49 unchanged;
standby/fight/cast body controllers unchanged. Baseline45 preserved. Pole axis
alignment and orbital appearance remain practical user game checks.


## v0.1.51 constrain pole to upright cone; per-prop camera exclusions

User rejects full wrist rotation (pole points down) and reports camera jitter
specifically at the grip during walking/backward hand motion. Do not assume
hook/float alone caused it. All three props already have world/movable
collisions disabled. Restore attachment preserve-world-rotation=true for
all modes; no false call remains. Wrist translation stays. RodCone drives
pitch=7.5cos(angle), roll=7.5sin(angle), existing heading; .35s blend from/to
baseline procedural pitch. Tested steady up-axis component >.98 throughout
all phases, rather than unlimited wrist orientation.

GET_GAME_CAMERA 6B7677BF -> handler355F00 returns object's handle.
ADD_CAMERA_COLLISION_EXCLUSION 5BBFA4D7 ->3ABBC0 resolves camera handle,
loads flags slot2 (3ABBEE), object slot1 (3ABBF9), passes camera+130 to3A25A0.
Helper stores unique object/flags pairs, max10; prop collection path ignores
actor-specific flags, so use0. REMOVE 781D5599 ->3ABC10 uses camera/object.
Use these public APIs for our unique rod (whole mesh including grip), float,
hook only. Track camera/prop handles, avoid per-frame duplicate adds, update
on camera generation change, remove only ours before prop cleanup. Do not
disable camera collision globally or modify terrain/John collision state.
Camera list capacity is engine-managed; no memory patch is used.

Portable tests cover cone bound, pause and baseline angle restore; exclusion
idempotence, prop/camera changes, missing camera and repeated cleanup. Exact
EXE verification checks public ABI. Root cause/camera outcome remains a live
game check, not proven by screenshot. Tackle geometry/flight and additive
spin unchanged; normal movement and confirmed v45 stance preserved.

## 0.1.52: wrist grip calibration

SET_ATTACHMENT_LOCAL_OFFSET D4A54348 at 0x140231660 takes three native slots: attachment, packed float XY, float Z. Stores offset at +70/+74/+78 on parent attachment data. Existing attachment and preserve-world-rotation flag remain intact. Wrist world basis uses the same guarded pose getter as rig enumeration and matrix array pose+28, stride40, as native30516389. Local displacement is the transpose-basis projection of world displacement; nonfinite/nonorthonormal bases are rejected. Shift is -12cm along actual rod joint5 axis, plus 2.5cm toward visible actor front. Ready pitch -20 vs previous -12; spin cone center -8, radius7.5 degrees. No camera, collision, fight phase, inventory or actor-position changes. Tests and static ABI verification do not establish visual fit in RDR.

## 0.1.53

Adds 2cm actor-relative leftward shift (screen right in front view), world (-facing.z,0,facing.x). RodCone applies uniform -8-degree pitch correction after phase-specific input; spin center remains -8 with 7.5 radius. Axial lowering remains -12cm for every phase. Tests cover rotating grip shift and phase-independent pitch correction.

## 0.1.54

Spin cone center corrected from -8 to -20 degrees, matching calibrated Ready pitch. Radius7.5 retained; exhaustive cycle test requires forward pitch12.5..27.5 degrees. Earlier center8 allowed near-upright0.5deg at cone front. All non-spin pitch, grip, attachment, camera and animation code retained.

## 0.1.55

User requests a visibly stronger spin-only forward lean. Spin center changed -20 -> -40deg, cone radius7.5; pitch -47.5..-32.5 over full cycle. Other phase inputs and grip remain unchanged. No in-game verification.

## 0.1.58 — per-pose grip from baseline0.1.55

Only grip translation changes. Actor-right/vertical additive photo estimates: Ready(-.01,-.005)m, Wait/Bite(.05,-.01)m, Fight(-.02,-.015)m; Cast/other neutral. Smoothstep over.65s restarts from current value on interruption, zero-dt pause preserved, character heading applied every frame. Added on top of existing12cm axial lowering and palm calibration, before wrist inverse basis transform. No animation, rod pitch, spin, camera, collision or fish changes. Exact depth cannot be recovered from single screenshots; no in-game validation.

## 0.1.59

Photo-feedback correction relative to0.1.58: Ready additional world-down2.5cm; Waiting/Bite and Fighting additional actor-left3cm (screen-right in user front views). Total right/up additive calibration: Ready(-.01,-.03), Wait(.02,-.01), Fight(-.05,-.015)m. Angles, clips, blend lifecycle and all other code unchanged. No in-game confirmation.

## 0.1.60 — experimental per-instance fish matrix scaling

CREATE_PROP_IN_LAYOUT fish resolves to wrapper vtable module+1C738E0. Slot+C0 ->21A6B0 reads twelve XYZ floats from wrapper+D0 -> physical+20,30,40,50. Slot+B8 ->21A6A0 forwards wrapper+90 and an aligned64-byte matrix to234BB0. That helper invokes89D6B0, whose89D6F2..89D715 copies all four matrix rows unchanged into physical+20..50 and notifies transform systems. This supports an experiment, not proof that scaled transforms survive every rendering/physics stage.

Runtime validates PE timestamp/image size, exact code fingerprints, exact class vtable/slots and object handle generation. Calls only engine getter/setter; no arbitrary memory writes or executable patches. After baseline move/rotation, normalizes each local basis axis and multiplies by selected.5/1/2 scale; adjusts existing world-space mouth offset consistently, does not multiply an already scaled matrix cumulatively. Reads axes back and logs2sec cadence. Any failure restores native unscaled move/rotation. Scale1 uses original code without private setter. Visual-only fish collisions are disabled before experimental scaled transform. The shared WFT/vertex data is never changed.

Upper-row1/2/3 select.5/1/2 while fishing enabled. No automatic weight mapping until visual test. Same baseline0.1.59 rod/camera/animations and exact fish yaw retained.

## 0.1.61 — vertical Caught pose

User confirms runtime scale0.1.60 works visually. Preserve it. Caught only: smoothstep.35s to native Euler(0,0,-90). RDR16FE80 first matrix axis is(cosZ*cosY,sinZ*cosY,-sinY), so merely adding roll-90 while preserving arbitrary yaw would not produce vertical fish. At final yaw0/roll-90, model head axis-X maps to world+Y. Non-Caught yaw formula remains exact. Existing world mouth offset is inverse-yaw transformed then transformed by new RzRy, and scale applies to this rotated offset. Tests cover all casting quadrants and final vertical head direction. No in-game confirmation for this pose yet.

## 0.1.62

User confirms vertical Caught pose0.1.61. Replace manual scale experiment with per-cast category roll50/30/20 and separate within-category roll. Integer hundredths ranges40..99,100..500,501..1000 avoid UI/category ambiguity. Threshold scale by same weight<1,<=5,>5. No weight reroll at Bite/Fight/Caught. Remove scale test keys/HUD; retain guarded setter, fish yaw, mouth transform and hanging transition. Tests cover boundary draws, exact1kg/5kg scale and100000 seeded distribution. Baseline0.1.59 retained until user confirms new release.

## 0.1.63 native reel sound

User-extracted tables decoded with raw Deflate(-15), not Zstandard. sounds.dat20 data has two exact sample0x01B4B46C references: HUD_MENU_MENU_060308_DPAD_03 offset402465,size27,type12; HUD_HONOR_HUD_MENU_MENU_060308_DPAD_03 offset410457,size27,type12. Selected first event. Record payload:0c2f9505aa02000000000000010000000000004deb37826cb4b401. Bank hash8237EB4D resolves STATIC\SFX name table. Native B157BBB4 atE33A20 reads integer sound ID slot0 and string pointer slot1, dispatches persistent frontend play. Allocate6AE0AD56, finishedE85AEC2E, stopCD7F4030, release9C080899. Own one sound at a time; >=80ms repeat only after finish, reclaim stuck voice after.5s, no frame-catchup burst. Stop/release on key-up, Q, phase exit, focus loss, pause, cleanup. No embedded samples, WinMM, archive modifications or extra sound assets. Only game sound IDs. In-game audible result unverified.

## 0.1.64

Use exactly six samples user marked suitable: DPAD01/02/04, NAV01/03/04. NAV02(0x1224B450) excluded. Original DPAD03 and safe tumbler are not implicitly added to explicit six-item selection. Independent xorshift chooses uniformly among five alternatives after first sound, so no consecutive duplicates; generator seeded at script startup without touching Game PRNG. No overlap; existing native sound lifecycle retained. 60000-selection test covers all six, approximate balance and no repeats. No in-game audio validation here.

## 0.1.65

User reports0.1.64 reel clicks too frequent. Minimum inter-onset interval doubled80->160ms. No other audio lifecycle/random selection changes. Timing expectation adjusted in existing test. No in-game audio validation.

## 0.1.66

User reports a visually huge fish at1.37kg. Weight generator and thresholds verified,1.37 maps to1x. Existing condition fishScale!=1 bypassed guarded matrix setter/readback for normal category. Remove bypass: explicitly normalize/set all three categories, including1x. Log object+weight+category+target+observed to diagnose visual/model baseline discrepancies. Cannot establish exact cause of user observation without runtime log. Tests include2->1->.5->2->1 on pre-scaled matrices; odds/weights unchanged. Preserve160ms reel cadence.

## 0.1.67 — camera aim during charge

Do not acquire CastControls when binding spin while CastCharge.active. Ordinary throw still owns/restores controls as before. Press begins charge without water verification or initial turn lock; sample camera while held. CastCharge.observe now returns a one-shot release edge; prepareCast executes on that edge and commits current camera/water target. Failed release stops animation, restores only owned controls, resets charge and returns Ready with existing notice. Success enters existing release->stop spin->turn->throw sequence. Invalid/missing water not silently replaced by press-time target. Post-release no further sampling, fish/cast direction remains fixed. Tests cover long hold, unique release capture, repress, quick tap and reset. In-game camera/animation behavior pending user check.

## 0.1.68

Remove user-disliked sample0x0FEF10E1 (DPAD02) from reel list. Five entries remain; generator derives alternatives from array size, no adjacent repeats. Timing160ms and all0.1.67 behavior retained. Selection count test and mapping validator updated.

## 0.1.69

Remove user-disliked NAV01(0x0B2CA65B); four events remain. Selection uses array size, previous cadence and lifecycle retained.

## 0.1.70 sound audition

Fixed selection only, no random mixing. Keys1-4 map existing four in order;5 maps sample04766715 to FOLEY_DOORS_SAFE_TUMBLER_TURN_04. Key press stops old owned voice, selects new event and previews once while fishing active. R inFight repeats selected event only,160ms min. HUD/log show selected key/sample. Preview finishes naturally (5s guard), focus/pause/F6 still stop it. Tests cover selecting all five and invalid index; static table mapping validated. Baseline0.1.62 unchanged.

## 0.1.71

User hears alternating normal/quiet instances of a fixed clip. Confirmed old implementation called STOP/RELEASE/allocate on every repeat and forcibly restarted unfinished voices after.5s. Remove those operations between repeats: one owned soundID per held-reel sequence, replay only on HAS_SOUND_FINISHED with >=160ms interval. Natural preview completion releases without STOP. Explicit cancellation still stops/releases. Tests require one allocation and zero STOP/RELEASE through1000 repeat updates, and no timeout truncation. This does not prove the audible fluctuation root cause; game mixer/category behavior remains unverified. No global volume or shared audio metadata modifications.

## 0.1.72

User confirms0.1.71 improves/fixes volume inconsistency. Retain lifetime changes; random independent draw among all five current sounds, repeats permitted, own RNG. Add one-shot owned LASSO_ACTIONS_THROW_MASTER on actual Cast flight release, not button-up. Table chain resolves to STATIC_WEAPONS_LASSO_THROW_01 sample0x040BA803. CastSound is separate owner, natural finish releases only; cleanup/pause stops own voice. Played latch resets on new charge. Manual test keys/HUD removed. Tests cover distribution with repeats, stable reel ID, cast sound once-only/natural finish/pause. Audible whoosh not verified in game.

## 0.1.73

Latest user log0.1.72:0.43kg=.5x,8.18kg=2x,4.16/3.22/4.03kg=1x; all50 readback samples match. No fish size/weight changes. User confirms throw whoosh.

Reel: use a retained ID PER CLIP, max5, only one event actively repeating at a time. Each ID always receives same event, eliminating event-switching on one persistent voice; natural completion and no between-clickSTOP retained. Explicit cancel releases owned pool. This is a targeted hypothesis, not proof of uniform perceived waveform levels or mixer behavior. Log each sample/ID.

Water: exact aliases all in STATIC\SFX, verified against extracteddat20. Landing at Cast->Wait with flightReleased, not E release; choose0x008CE18D/0x00E2AE50/0x014E76D5. Fight pulling false->true, including first hook, choose0x016EF8B8/0x00E2AE50. Shared fishPulling helper keeps burst timing identical to Game. Fight->Caught choose0x0F8C00C2/0x016EF8B8. Separate RNG does not alter fish odds. Each request once per edge, own transient IDs, natural finish release, pause/cleanup stops only own audio. No assets embedded or game archives modified. In-game audio pending.

## 0.1.74

User prioritizes water/reel conflict, requests landing008CE18D quieter and moves00E2AE50 from landing to caught while keeping struggle. Water now uses native-owned POSITIONAL sound path rather than FRONTEND. Exact E33D40 params112bytes reproduced: gainDb0,pitch/priority4=FFFF0000,speed8=1,positionPtr20,handle60=-1,max64=23900,min68=-20,flags6C=200000FF. Calls same guarded private DEB2B0(manager,[id],event,params) as public5B05E3E0; manager global2AD3CF0. Code/profile fingerprints guard ABI. Single changed gain=-6dB for008CE18D only. No shared mixer settings. Failed guard skips water rather than reverting to conflicting frontend. Reel still per-clip frontend retained IDs. Groups updated exactly as requested. In-game coexistence not verified.

## 0.1.75

User confirms0.1.74 still ducks/interrupts clicks with struggle water, asks fixed-key audition. Add fixed1-5,6autoStruggle toggle with scoped stopCue,7manualStruggle,8native one-shot MENU vs retained CHANNEL. Default MENU uses public2E458F74 at160ms, no soundID/HAS_SOUND_FINISHED dependency; in-flight one-shot tails naturally finish afterrelease. Persistent path untouched for A/B. Log input gateR/Q and finished/IDs to distinguish key suppression, blocked scheduling and mixer behavior. Keep world water/gain/groups from74. No claim actual mixer root cause established. Tests cover fixed selection and deterministic MENU schedule withoutID dependencies.

## 0.1.76

User confirmsMENU does not interrupt reel with water,CHANNEL does; fixed clip still fluctuates loud/quiet. E33810 disassembly shows default gain is NOT always0: read contextual UI scalar then (scalar-1)*45, store into native params. E33910/49053A94 instead reads gain from explicit input struct0 and bypasses this context calculation. Use nativeINITPARAMS with28byte input, gain0dB and all other fields zero, preserving default flags. This fixes launch-level variability; actual mixer contribution/perceived output unverified. No writes to game/system/master volume. Remove test keys/CHANNEL; restore random five, repeats allowed,160ms and independent audio RNG.

Add FightMotion shared with fishPulling bursts. Fade in.18s/out.28s, additional rodPitch<=8deg/roll<=6deg, endpoint side<=.14m/y<=.08m, default fish flutter up to28deg. Endpoint movement applied jointly to bobber/hook/fish so line remains connected. Nonzero custom mouth offsets preserve prior no-flutter rule, but endpoint motion still applies. Caught remains vertical, fish yaw formula unchanged, no actor/camera/physics changes. Tests bound motion and verify pause/rest reset.


## 0.1.77 — splash preview, RDR1 vfx.rpf

User archive SHA256 40b2616bf50396d1706b005af82ffd3d1606a95cb2fdaf8f4f7e0073351e9932.
RPF6: 162 entries, encrypted TOC/debug names (16 AES ECB rounds), ordinary list
payloads use Zstandard. vfx/rdr2_core.fxlist and fullfxlist confirm all ten
splashEffects spellings. rdr2_core is the RDR1 resource's original filename.
Archive itself is not redistributed. No explosion effects are used.

PC EXE native ABI verified from handlers (SDK declarations are placeholders):
CREATE_RMPTFX_EMITTER_IN_LAYOUT F1F8AFCA @0x14022EAE0:
(layout, instanceName, effectName, packedXYPosition, ZPosition) -> handle.
_RMPTFX_EFFECT_START 6745191B @0x14022E5E0:
(handle, packedXYEulerDegrees, ZEulerDegrees) -> bool.
IMPORTANT: START's vector is rotation, NOT position. 0x140695940 converts it to radians.
SET_RMPTFX_SCALE 1A4C98C1 @0x14022EFF0: (handle,floatScale).
Stop/reset and DESTROY_OBJECT act only on our one emitter, then owned layout;
never RESET_RMPTFX_ALL. Manual preview up to3s, auto burst up to1.5s, one emitter.
Surface Y = waterTarget.y -0.08 +0.025 (cast target includes +0.08 float pivot lift).
Native started=true is not evidence of visible suitability; user must compare in game.


## 0.1.78 — user-selected production splash mapping
User confirmed v0.1.77 keys1/4/8. Struggle onset only, fixed scale1 and1.5s
maximum auto lifetime retained. Weight<1: bullet_water (key4); 1<=weight<=5:
ped_water_thrash (key1); weight>5: amb_water_rocksplash_2 (key8).
Same game.weight as model scaling. Removed preview keys/HUD. Stop immediately
on leaving Fight, F6 cleanup, pause. Boundary and onset scheduler tests added.


## 0.1.79 — underhand molotov animation preview

Source dyn.was SHA256 b37f6558175ce912710e298e6d79fc1c148d7b61836d64a88e758bd06258e3c9.
Contains MOLOTOV_THROW_DYNAMIC event. Key1 standing nor_dyn_stn_for_mid_und_trw;
keys2–9 directional leaf keys nor_dyn_run_for_mid_und_trw_SUFFIX where suffix
180,135,225,090,270,045,315,000 resolves to authored source000,045,315,090,270,135,225,180.
These runtime hash names differ from source names. The unsuffixed WAT run track
is a directional container and is NOT a playable key in dyn.was. Verification
resolves each actual hash -> resource pointer -> authored source string.
Key0 nor_dyn_stn_for_mid_trw comparison. TASK_PLAY_ANIM rate1, forced loopfalse,
timer-1, no seek; native playing/time observations logged every0.2s. Release after
native playback ends, no fixed early hold. Separate30s runaway watchdog.
Use existing scoped animset ownership; no global actor speed or camera control.
Only Ready/Caught/Lost, pause mini-game during preview, cleanup onF6/player loss.
Landing excludes008CE18D (event metadata retained for later use); only014E76D5.
No assets/projectiles spawned by test. Main baseline0.1.78 unchanged.


## 0.1.80 — catch choice and underhand fish release

User confirmed key1 in0.1.79: dyn/nor_dyn_stn_for_mid_und_trw. Caught now waits
indefinitely for Action keep or Ease release. Existing total catches semantics
unchanged; Progress/Kept and Released separately persisted; no game inventory item.
Preview keys removed. Scoped dyn binding, positive rate1/nonloop/timer-1 retained.
Fish transfers from hooked pivot to right wrist over0.25s; rod scoped attachment
moves to wrist_l for release, original bone/attachment restored afterwards.
Release at normalized phase0.48 is an initial synchronization value, not a proven
native throw event. Failure before detach returns to Caught without a fake splash.
Flight lasts distance/7 clamped0.65–1.5s, parabolic lift1.2m, ends exactly on saved
verified water surface. Fish is removed and Release water cue008CE18D is played
once only at flight completion; its prior-verified -6dB gain retained. Landing
still only014E76D5. Release is a fourth owned water slot, isolated from reel MENU.
Size-selected splash reused at water target; release retains current fish scale.
Cleanup on cancel/player loss releases owned animation/assets/attachments only.
Tests: indefinite choice, natural task args, phase gate, exact endpoints, one
impact, pause dt0, sound selection by cue. No RDR runtime in cloud.


## 0.1.81 — bounded missing-startup recovery for fish release

User log0.1.80, seven release requests: four impacts; three6s Hand-stage timeouts.
Old version did not log per-frame playing/time, so it cannot distinguish a missing
startup from a stalled playback or establish the exact engine rejection cause.
Generic castClipMatched/timeAdvanced release logs are not updated by this path
and must NOT be used as proof the release clip never played.

Introduce Bound stage after dyn bind; issue TASK_PLAY_ANIM on next script frame,
as in the existing stable pose controller. ReleaseStartup observes native playing;
only if never matched, retry at0.35s (at most two retries), check scoped ownership
before resetting/reissuing. After third missing request, fail after0.75s preserving
catch. Any observed playing irrevocably disables startup retries for this release.
End-of-playback requires0.25s continuously missing queries, avoiding a one-frame
false interruption. Log stage/playing/time/age/seen/attempts every0.2s. Release
phase0.48, trajectory, impact008CE18D, size, rod grip/choice unchanged. This is a
bounded startup fix and better diagnosis, not proof of universal runtime success.
Regression tests cover missing startup, recovery, no replay after playing even
through long query gaps, finite retry cap, and zero-delta pause.


## 0.1.82 — standing item draw/stow preview

Twenty actual runtime hash->source pairs, verified by verify_item_preview.py
against extracted lso_base/dyn_base/tkn_base/ptl_base/rfl_base/item_binoculars/
item_bottle/item_tobacco/item_bait WAS. First page1–4 lasso draw/post/stowpre/stow,
5–6 dynamite/bottle draw/stow,7–8 throwing knife draw/stow,9–0 binocular pre/post.
Second page1–4 pistol draw/post/stowpre/stow,5–7 rifle draw/post/stowpre,
8–0 inventory bottle/medicine/bait full actions (not pure draw/stow).
No run/hrs source clips used. No game asset data redistributed, only verified keys.

F7 page,1–0 play/replay, Backspace cancel. Ready/Caught/Lost only and not fishRelease.
Pause minigame while viewing, no full player-control lock. Scoped existing binding,
Bound frame before task dispatch, ReleaseStartup missing-only cap reused from0.1.81.
Natural nonloop/rate1/timer-1 playback, no seek/freeze; observation logged0.2s.
One owned animset session, unique request per tested set, cleanup on F6/player loss.
Ordinary fishing/release/impact sound unchanged. Runtime suitability awaits user.


## 0.1.83 — pinned stow selection, further draw candidates

User selected0.1.82 page1/key6: dyn_base/nor_dyn_stn_hls. Record in
CONFIRMED_ITEM_ANIMATIONS.md and keep page1 unchanged; no automatic integration yet.
User rejected all prior takeout candidates as too quick. lso_base standing draw
resource range6.366666–6.7 and post5.999999–6.333333 are indeed short fragments.
New second page: bandana pre/pst (full ranges0–5.6/0–4.0667), give_money player
handoff (0–6.3333), standing lantern draw (NPC Gped source, explicitly labelled),
lasso four directional storage-preparations, long lasso holster post (runtime key
nor_lso_stn_hls_pst maps to shared Gent_nor_ptl_stn_hls_pst,3.3–5.8333), dyn pre.
All20 keys/source pairs verified; new candidates are not claimed to be the desired
bag retrieval until user sees them. Mission give_money key resolves only to male
player handoff source; no NPC role/money transfers spawned. No slowdown/reversal
or new timing alteration; existing scoped preview and gameplay unchanged.


## 0.1.84 — user-specified item lifecycle, v0.1.83 layout authoritative

Mapping: small keep index2 lso_base/nor_lso_stn_hls_pre; normal index3
nor_lso_stn_hls; large index5 dyn_base/nor_dyn_stn_hls. Recover index19
nor_dyn_stn_hls_pre. Equip index19 then13 ltn_base/nor_ltn_stn_drw. Stow index8
item_binoculars/gent_useinventory_binocs_pre. Do not use v0.1.82 page2 indices.
Catch transition switches rod attachment to wrist_l and retains original right
bone. Caught fish uses right wrist anchor and confirmed vertical fishHang transform.
Keep removes fish once at phase0.65 and restores rod right at same event. catchResolved
suppresses Caught fish respawn. Release retains confirmed0.48 flight and impact audio,
then invokes Recover rather than immediately restoring rod. Transfer at Recover0.65.
Equip postpones all tackle prop creation until second clip phase0.45. Stow deletes
owned tackle props at0.65, cleans whole session only after clip completion. F6 during
an active sequence/release remains emergency cancel. Scoped animation binding and
missing-only startup recovery retained. Native natural end observed with0.25s gap,
then next step binds/starts; there is no intentional long inter-step hold.
Sync phases are initial values awaiting in-game alignment; no runtime guarantee.
Tests verify exact key/weight boundaries, ordered equip steps, one event, reset.


## 0.1.85 — overlap rod draw, earlier stow/transfer events

User confirms0.1.84 works but draw step2 late, disappearance and hand transfer late.
Stream all sequence steps at begin. Equip step0->1 at normalized0.80 while first
is still playing, only if next set loaded; retain necessary Bound/request frames
but skip natural-end0.25s gap. If streaming lags, normal natural-end fallback remains.
Stow prop disappearance phase0.65->0.30. Keep simultaneous fish removal+rod right
and Recover rod-right phase0.65->0.45. Equip prop appearance second clip0.45 unchanged.
Release throw0.48/impact audio unchanged. Exact visual bag contact remains user-tested.
Tests assert overlap applies only Equip step0 and one-shot earlier events per kind.


## 0.1.86 — remove equip preparation; recast animation preview
Equip now single index13 ltn_base/nor_ltn_stn_drw; event0.45 of sole clip.
Removed overlap logic and initial index19; retained other0.1.85 event thresholds.
Ten lasso retrieve/outcome/tug/pull keys individually verified against WAS.
Numeric preview in Ready/Wait/Bite/Caught/Lost, excluded active item/release/Fight.
Gameplay timers suspended only while preview, free camera. Natural rate1 nonloop,
no frame hold. Scoped ownership, Bound barrier and missing-only retries reused.
Digit0 plays full normal fight animation without its usual .5238 freeze. No real
recast is implemented before user selects clip. Rod/fish decisions remain unchanged.


## 0.1.87 — integrate user-selected retrieval4 and hook5

0.1.86 key4: lso/nor_lso_stn_mid_trw_suc; key5: gent/lso_stn_tug.
Key4 available Wait/Bite/Fight; rod forced right. Freeze gameplay during action,
commit retrieve at observed0.25, discard current fish without catch increment,
suppress Fight fish respawn, interpolate actual captured bobber/hook -> moving
rod-tip stowed offsets with smoothstep0.25–0.85 and0.6m arc. Finish Ready, E can
cast again; no automatic cast. Missing startup before commit preserves attempt.
Bite->Fight via existing Game.update E hook logic triggers Hook action before
fight pose controller. No freeze on the short tug; after native end resume usual
fight pose request/blend/exact .5238 hold. Fight timer frozen during tug so no
damage/reel progress before control returns. Normal Wait/Fight pose does not
interrupt owned action. Existing Bound barrier/scoped retries retained; camera
unlocked. Preview keys other than4 removed. Capture right-bone/cleanup retained.
Tests verify valid phases, key mappings, single commit, no Hook commit, return
endpoints and reset. Runtime visuals not executed in cloud.


## 0.1.88 — hook-to-fight handoff without neutral reset

User confirms0.1.87 but hook->fight gap too long. At hook normalized phase0.72,
when lso_base loaded, verify scoped ownership, release only owned override flag1
if necessary (base gent requires none); bind lso_base without CLEAR_ACTOR_TASK
or stopCastAnimation, retain current hook task until next-frame fight request.
Set FightPose owned/Bound with poseIsFight=true so normal controller immediately
requests fight clip with blend0.18 instead of default0.65. Avoid native end
0.25s gap and Idle->Loading setup. Default normal blend retained elsewhere;
startup retries/advancement and exact .5238 hold unchanged. Preload fight set
at hook begin. If fast handoff unavailable, existing normal-end fallback remains.
Tests cover Hook-only0.72 gate and fast blend argument; runtime continuity
still requires user game verification. No camera or retrieval4 change.


## 0.1.89 — 3-second charge distance and category reel speed

User requests stronger reason to spin, max charge3+s; reel small faster/normal
unchanged/large slower, then explicitly caps large at0.5. Use1.5/1.0/0.5.
CastCharge tracks unpaused active hold time capped3s; first keydown frame adds no
previous-frame dt. Charge is sampled before observe(release) and prepareCast,
latched requestedDistance persists after animation controller resets CastCharge.
Distance3+(existingCastDistanceMax-3)*clamp(hold/3,0,1). Existing INI9 =>3..9m,
custom3..20 preserved. Water search scans only at/below request down to3m; manual
water fallback uses same charge; cast flight duration uses actual validated target.
Camera still freely aimed during hold, target locked on release; no new natives.
Progress R&&!Q only:0.105*sizeMultiplier. Same weight boundaries as scaling:
<1 small,1..5 normal,>5 large. Negative drift0.025 and tension/pull unchanged.
Tests: charge monotonic/min/cap/custom max, pause/cancel/release latch, category
boundary progress gains, unchanged tension/ease; existing500 seeded catches pass.
No cloud game runtime; baseline0.1.88 remains authoritative for rollback.


## 0.1.90 — 2s charge, size-dependent click intervals, empty-hook reeling

Full charge cap2s and divisor2. User overrides small click interval0.12 and normal
0.18; large0.32 and empty0.70. ReelMenuAudio accepts per-call interval, retains
overshoot to preserve average rhythm across frame steps, at most one click/frame.
Same MENU_INITPARAMS explicit gain0 and five sample selection; no pitch/channel change.
Wait R&&!Q increases Game.emptyReeled by0.10m/s, bounded actualCastRange-2m. No
change tension/progress/catch count. Wait timer still advances; Bite stops empty
reeling. Geometry starts at shifted waterTarget for Wait/Bite/Fight so hook E does
not teleport float outward; Fight lerps from reeled-in start to same2m endpoint.
Fully empty reel enters Ready, no catch. Ready action resets empty distance.
Cue gating enables clicks Wait/Fight only, including pause/focus prior guard.
Tests cover2s charge, interval thresholds/rhythm ordering, empty pause/Q stop,
Wait->Bite continuity and full empty return/no catch; existing500 catches pass.
Game runtime/audio/mesh movement not executed in cloud; baseline0.1.88 unchanged.


## 0.1.91 — retained tension, size-dependent resistance, audible line payout

Charge divisor/cap1.7. Release fish only: yaw=atan2(forward.x,forward.z)+90deg,
180deg from prior release orientation; model head local -X faces water. Swimming
formula stays -90deg. Four cardinal-vector dot-product tests verify release head.
Fight Q priority: tension-=0.30dt clamp0, progress-=0.04dt clamp0. R only:
progress+=0.105*sizeSpeed*dt, tension increases only if fishPulling, rates0.10/
0.20/0.30 by existing size thresholds. Idle holds both; only tension>=1 loses fish,
not tension0. Removed old passive drift. Kept catch count/size probabilities.
Separate payout scheduler0.22s selects only DPAD_02/sample0FEF10E1 or NAV_01/
sample0B2CA65B, actual names verified in user dat20. Same explicit MENU gain0.
No return of excluded samples to forward five. Q sound gated to actual nonzero
before-step tension or progress, so no infinite sound at fully slack endpoint.
WaterTriggers starts existing Struggle cue on Bite edge; pulling logical state
spans Bite->Fight to avoid duplicate initial splash. Visual same active edge,
actual bobber position at Bite. Hook action preserves water sound/emitter, and
its paused gameplay loop ages effect naturally. Retrieve still stops owned cues.
Tests update old slack-loss expectation and extend large-fish simulation budget
from48s to192s for new slower give/take balance; all500 adaptive catches pass.
New invariants independently verify no idle drift, safe nonpull reel, size slope,
Q rollback and release orientation. Runtime balance/audio still user-validated.

## v0.1.92 — actual honor/cash and mouse layout

- Uploaded Rampage.asi decoded statically. Native-obfuscation seed 4717358C;
  independently matches CREATE_ACTOR_IN_LAYOUT 8D67F397, IS_ACTOR_VALID BA6C3E92,
  GET_LOCAL_SLOT AD68A22E. Honor helper VA180048280 writes DECOR_SET_INT DB718B21
  for `honor` and `honorAward` on a temporary actor; KILL_ACTOR_WITH_KILLER 6085F7AC
  triggers game reward handling and RELEASE_ACTOR 32489AFB releases the actor.
  We deliberately do not use the artificial-kill approach for fish releases.
- Real stat layout cross-reference: public DoctorSpechemen/RDR-AP,
  plugin/Application.cpp, StatPtr and StatChangeCommand:
  https://github.com/DoctorSpechemen/RDR-AP/blob/main/plugin/Application.cpp
  Global_54086 array: header one 8-byte slot, each float in low four bytes of
  an eight-byte entry. RedHook's GetGlobalPtr() returns the raw buffer;
  address = base + (54086 + 2*(statId+1))*4. Cash id0, honor id1.
  Exact EXE fingerprints and comparison with independently located native honor
  cache guard writes. No modification on unsupported/mismatched profiles.
- SET_PLAYER_CURRENT_HONOR 4D918005 at RVA AD7380 takes player slot0 and FLOAT
  slot1, contrary to the one-float SDK declaration. Writes float at player-state
  +434 through module+22CBF00 if state+5E9 is ready. This is a cache update;
  persistent stat is written separately and read back, honor clamped -5000..5000.
- UI_SET_MONEY F71BD93A uses `nMoneyText`, `Dmoney_amount`, integer cash;
  PRINT_MONEY 51948EA6 is the ordinary game cash popup. A popup alone is not payment.
- RedHook exports GetGlobalPtr and RH_ActionDisable resolved dynamically;
  no ScriptHookRDR import. FIRE/TARGET/JUMP/SPRINT names verified in game action
  table. Camera axes are not disabled; original full-control ownership for
  individual confirmed throw sequences remains scoped/restored as before.
- Positive awards happen at committed Keep or actual release landing, with
  per-catch duplicate protection. Before/after/delta logged from actual reads.
  No persistent award replay on loading an older save (would duplicate rewards).
- Static analysis and local logic tests only. In-game changes and save/load
  persistence are not confirmed by running RDR in this workspace.

## v0.1.93 — prevent native RMB weapon draw during fishing

User reports weapon draw on RMB in .92. RedHook RH_ActionDisable hooks script
IsActionPressed/JustPressed/Released/GetActionValue queries (e.g. loader RVA251F2,
2529D checks disabled flag before original native); it does not block every
native player-controller input path. Previous docs overstated its effect.

Use ACTOR_START_FORCE_HOLSTER 7957CA4F(actor,1,0) before Equip; maintain through
fishing; ACTOR_END_FORCE_HOLSTER 231E7034(actor) on cleanup. No weapon removal,
render hiding, camera disabling, counter-based selection calls or every-frame
holster task restarts. Both native registrations traced in supplied RDR.exe:
- start wrapper B06D10 ->284C30, callback B067B0, bool slots1/2. Callback sets
  controller+48C bit20, bit40 from arg2; arg1=1 bypasses ordinary animated branch.
- end wrapper B06D20 ->259C20, callback B068A0 clears bits20/40 with AND9F.
- actor wrapper handle table module+2C36778 ->wrapper+B0 entity handle;
  entity table is DISTINCT module+2C36768 ->ped+70 weapon controller ->48C.
Runtime readback checks force flag; preserves existing force mode owned elsewhere.
Lease acquired once, reacquires only if lost; released once; actor switch releases
old lease. F6 cleanup, movement cancellation, death/off-foot cleanup use same exit.
Existing input layout and rewards unchanged. RDR runtime validation still pending.

## v0.1.94 — user's reward failure log

Fishing.log supplied by user: .93 loaded, weapon force-holster readback confirmed;
all repeated sale/release attempts rejected at `honor table/cache mismatch or
player not ready`. Thus earlier EXE/handler/table/range/writable-page gates passed.
The combined final condition did not distinguish unreadable/not-ready cache
from unequal values; it was not sufficient evidence of a bad persistent stat.
Remove ONLY the optional native/HUD-cache eligibility gate; table guards and
actual write/readback retained. Cache readability, readiness and value now
logged separately with actual table money/honor at every decision preflight.
Native refresh already safely checks readiness internally. No forced writes to
cache offsets and no attempt to fabricate game rewards on write failure.

Additional independent Rampage check: honor getter VA1800481D0 calls imported
getGlobalPtr(0xD346=54086), reads float at +0x10, passes to FLOOR 32E9BE04.
Money getter VA180048DA0 reads same table at +0x08. Consistent with the stat0/
stat1 entry layout used here and the RDR-AP source; no new guessed addresses.
User's live before/after values and save/load effect still require confirmation.

## v0.1.95 — real honor confirmed, native honor HUD, longer rest, 10m cast

User log .94: honor before5000 after5000 delta0 (cap); new test after trainer
reduction: before4950 after4955 delta5, cache at preflight4950. Real raw honor
increase is confirmed by user's log; save/reload was not tested.

On positive delta call native SET_STAT_MESSAGE 73DA6AF1 with Jenkins sn_hnrr
AFA3172F, +actualDelta text, 3s, type2, honor selector0; arguments match game's
stat-increase pattern cross-referenced in RDR-AP StatPopup. Refresh honor value
via existing SET_PLAYER_CURRENT_HONOR first. Handler RVA655230 forwards all13
slots to native HUD manager651580; uses game localization/UI, not a custom bar.
No own help/corner text for honor. At cap no fake gain notification or cache
write. Native HUD appearance still awaits in-game visual validation.

Fish pulling common function now 3.2s burst /4.8s rest (8s cycle), replacing
3.2s burst /1.6s rest. Shared helper drives tension, movement, water audio/VFX
and HUD, removing duplicate old timing in displayed YES/NO. Existing thresholds
and reel rates unchanged. Tests cover new rest/no extra splash until next burst.

Maximum cast10m (user corrected earlier19 typo). Runtime default10; existing
INI default9 migrates effectively to10 without replacing file/statistics; cap10.
1.7s charge unchanged. Resting four-plus-second tension holds and 3/6.5/10m
power endpoints tested. Previous 500-catch regression suite remains passing.

Final user follow-up before handoff: random bite wait changed from4..10s to7..15s
(wait=7+random()*8). A1000-roll test verifies bounds and coverage near both ends;
existing500 catch simulations pass with this final timing.

## v0.1.96 — quiet HUD, random calm windows, configurable controls and fish grip

Delete old persistent left HUD rendering entirely; old HUD/Enabled=1 cannot
restore status, power, tension/progress text or gauge. Preserve money/honor
native notifications and existing cash receipt. Caught choices rendered only
lower-right, outlined Russian captions and shaded keycaps, using actual Keep/
Release bindings; hide during decision animations. These are RedHook draws
styled after the supplied reference, not modifications of global native prompt
slots (the native UI_SET_PROMPT_STRING has unchecked slot-index writes).
Hapna font1 used for Cyrillic; supplied loader's embedded Hapna Slab Serif font
contains all required Cyrillic glyphs, unlike embedded Chinese Rocks. Actual
font presentation needs in-game visual confirmation.

FishStruggle is per-fight state: fixed3.2s burst; on every burst->calm transition
one fresh uniform draw selects3..4s. No per-frame resampling. Pause preserves
clock/seed. Tension, fight motion, splash and water cue use same bool; remove
old independently inferred elapsed%8 timing. Tests cover deterministic extremes,
new draw per cycle, >100 random windows/bounds/variation, pause and calm reeling.
Prior500 simulated catches still pass. Quiet status doesn't affect mechanics.

All9 actions read [Keys]: Toggle/Spin/Cast/Hook/Reel/Ease/Retrieve/Keep/Release.
Separate cast/hook edge latches permit independent binding, with context sharing
for defaults. No hardcoded GetAsyncKeyState operands. One-time LayoutVersion2
adds missing entries in existing INI, retains unrelated settings/progress and
migrates obsolete default R/Q82/81 to effective Space/Shift; subsequent edits
fully respected. Current key names shown on caught prompts. Key strings use
Unicode Win32 lookup ->UTF8; mouse buttons have readable labels. Existing F8/F9
reservation retained. Non-simultaneous actions may share a key; simultaneous
bindings should differ. Settings apply on game restart.

Caught grip offset3cm toward fingers (screen-right in supplied front view),4cm
down, in actor horizontal frame. Applied only to caught fish following hand;
underwater transform/size and throw path unchanged. Four-cardinal projection
tests verify lateral/down direction independent of world heading. Runtime
placement and prompt appearance await user visual verification.

## v0.1.97 — en/ru UI, catch details and immediate recast after loss

User confirmed Cyrillic question marks in .96. Font file cmap coverage alone
was insufficient: RedHook's baked font atlas omitted these glyphs. Default UI
now English (en), selectable ru in [UI]/Language. All own captions, fish size/
weight and loss notice share localization; existing native reward UI unchanged.
ASCII draws use known working font0. Non-ASCII uses Win32 GDI Unicode glyph
rasterization (Georgia, checked Cyrillic coverage, Segoe UI fallback), cached
per character as alpha-outlined BMP V4 textures via exported RH_LoadImage /
RH_DrawImage. No font redistribution/installation or game-font atlas patch.
Only Windows GDI32.dll added, not another mod dependency. Temp glyph files
are deleted after synchronous image load. Glyph cache is reused across changing
weights. English fallback on Unicode failure, with log reason, rather than ?.

RedHook .8 loader statically checked: RH_LoadImage export B6A0 returns UINT64_MAX
on failure (zero is valid); raw-file load E3E0 ->E4C0 decoder requests4 channels,
no extension filter. DrawImage command render BF50 uses center +/- half width/
height normalized to viewport. PNG/font assets not bundled. BMP V4 explicit
RGBA masks and bottom-up rows verified by independent Pillow decoder; glyph
texture alpha/outline/row orientation tests pass. Actual GDI/D3D game rendering
not executable in cloud, so RU presentation awaits user test.

Lost previously waited4s and consumed first action to return Ready. Add explicit
recoverLoss, call it immediately at runtime failure after stopping our animation/
fish/audio/splash state. Session, pole and weapon lock retained; next cast/spin
is available immediately. Three-second localized top-left notice is independent
of fishing phase, not a cooldown. Tests cover broken line/missed bite ->recover
->first-click Cast, no added catch, repeat recovery idempotent.

Caught bottom-right now has localized size category +2-decimal kg above choices,
using existing <1 /1..5 />5 boundaries; hidden alongside choices during action.
No tension/progress reveal. Language/size boundaries, ASCII-vs-Unicode dispatch,
bitmap encoder, existing random-window/500-catch regressions checked. All9 key
settings remain intact.13 exact RedHook exports, Windows system DLLs only.
