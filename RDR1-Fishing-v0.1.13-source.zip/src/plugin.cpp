#include "redhook.hpp"
#include "fishing.hpp"
#include "visuals.hpp"
#include "line_raster.hpp"
#include <cstdio>
#include <cmath>
#include <string>
#include <cstdarg>

static HMODULE module;
static std::string iniPath,logPath;
static fishing::Game game;
static unsigned savedCatches;
static int toggleKey=VK_F6,actionKey='E',reelKey='R',easeKey='Q';
static fishing::Button toggleButton,actionButton;
static std::string toggleName="F6",actionName="E",reelName="R",easeName="Q";
static const char* stateName(fishing::Phase p){
 static const char* names[]={"Off","Ready","Cast","Wait","Bite","Fight","Caught","Lost"};return names[int(p)];
}
static std::string keyName(int key){
 char name[80]{};LONG scan=LONG(MapVirtualKeyA(key,MAPVK_VK_TO_VSC)<<16);
 if(GetKeyNameTextA(scan,name,sizeof(name)))return name;
 return "key "+std::to_string(key);
}
static int readKey(const char* name,int fallback){
 int key=int(GetPrivateProfileIntA("Keys",name,fallback,iniPath.c_str()));
 // F8 and F9 are reserved by the user's installed mods.
 return key>0&&key<256&&key!=VK_F8&&key!=VK_F9?key:fallback;
}
static bool visuals=true;
static bool hudEnabled=true;
static float hudTextHeight=.018f;
static float waterOffset=-.65f,castDistance=9;
static rh::Vec origin,forward,waterTarget,bobberPosition,lineTip;
static bool autoWater=true,requireWater=true,showLine=true;
static float noticeTime=0,visualLogTime=0;
static const char* notice="";
static const char* handBone=nullptr;
static bool hasWaterTarget=false;
static int rodAttachment=0;
static float rodAttachRetry=0;
static fishing::Point geom(rh::Vec p){return {p.x,p.y,p.z};}
static rh::Vec vector(fishing::Point p){return {p.x,p.y,p.z};}
struct Prop {const char* name;int asset=-1,object=0;bool done=false;};
static Prop props[]={{"p_gen_fishingpole01x"},{"p_gen_fishingbobber01x"},{"p_gen_fishinghook01x"}};
// Mesh inspection confirmed fish01 is sliced; fish02 is the intact fish.
static std::string fishModel;
static int fishAsset=-1,fishObject=0;
static bool fishRequestPending=false,fishLoaded=false,fishSpawnAttempted=false;
static float fishLoadTime=0;
static rh::Vec fishMouthOffset{};
static void log(const char* format,...);
static bool fishVisiblePhase(){
 using fishing::Phase;
 return game.phase==Phase::Bite||game.phase==Phase::Fight||game.phase==Phase::Caught;
}
static void removeFish(){
 if(rh::validObject(fishObject)){rh::invoke<0x21144994>(fishObject);log("Hooked fish removed: object=%d",fishObject);}
 fishObject=0;fishSpawnAttempted=false;
}
static int layout=0;static float loadTime=0;
static void log(const char* format,...) {
 char buf[1024];va_list a;va_start(a,format);vsnprintf(buf,sizeof(buf),format,a);va_end(a);
 rh::print(1,"[Fishing] %s",buf);
 if(FILE* f=fopen(logPath.c_str(),"a")){fprintf(f,"[%llu ms] %s\n",static_cast<unsigned long long>(GetTickCount64()),buf);fclose(f);}
}
static void save(){char b[32];snprintf(b,sizeof(b),"%u",game.catches);if(!WritePrivateProfileStringA("Progress","Catches",b,iniPath.c_str()))log("Cannot save catches (Win32 %lu)",GetLastError());savedCatches=game.catches;}
static void cleanup(){
 if(rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment))rh::invoke<0xE894DC13>(rodAttachment);
 rodAttachment=0;rodAttachRetry=0;
 removeFish();
 if(fishing::validAsset(fishAsset))rh::invoke<0xA8D12960>(fishAsset);
 fishAsset=-1;fishLoaded=false;fishRequestPending=false;fishLoadTime=0;
 for(auto& p:props){if(rh::validObject(p.object))rh::invoke<0x21144994>(p.object);p.object=0;if(fishing::validAsset(p.asset))rh::invoke<0xA8D12960>(p.asset);p.asset=-1;p.done=false;}
 if(layout&&rh::validObject(layout))rh::invoke<0x21144994>(layout);
 layout=0;hasWaterTarget=false;handBone=nullptr;
}
static void requestProps(){
 if(!visuals)return;
 layout=rh::invoke<0x6CA53214,int>("RDR1Fishing");loadTime=0;
 for(auto& p:props){std::string path="$/fragments/";path+=p.name;rh::invoke<0x9AA02DA7,int>(path.c_str(),0);p.asset=rh::invoke<0x6005B514,int>(path.c_str(),0);log("Request %s: asset=%d",path.c_str(),p.asset);if(fishing::validAsset(p.asset))rh::invoke<0x38DC1F50,bool>(p.asset,true);else p.done=true;}
 if(!fishModel.empty()){
  std::string path="$/fragments/"+fishModel;
  rh::invoke<0x9AA02DA7,int>(path.c_str(),0);fishAsset=rh::invoke<0x6005B514,int>(path.c_str(),0);
  fishRequestPending=fishing::validAsset(fishAsset);fishLoadTime=0;
  if(fishRequestPending)rh::invoke<0x38DC1F50,bool>(fishAsset,true);
  log("Fish request %s: asset=%d pending=%d",path.c_str(),fishAsset,int(fishRequestPending));
 }else log("Fish rendering disabled: no installed fish model configured in [Fish] Model");
}
static rh::Vec point(float distance,float height,float side=0){return {origin.x+forward.x*distance+forward.z*side,origin.y+height,origin.z+forward.z*distance-forward.x*side};}
static bool updateCastDirection(){
 // RDR.exe 0x1403AAEF0: output vector pointer first, camera channel second.
 // Channel 0 is the rendered view; the handler returns its forward direction.
 alignas(16) rh::Vec direction{};
 if(!rh::invoke<0x6ED00237,bool>(&direction,0))return false;
 fishing::Point flat{};
 if(!fishing::horizontalDirection(geom(direction),flat))return false;
 forward=vector(flat);return true;
}
static void findHandBone(int actor){
 int object=rh::invoke<0x4A2063EC,int>(actor);
 for(const char* name:{"Hand_Right","RightHand","SKEL_R_Hand","R_Hand"}){
  rh::Vec p{};
  if(rh::invoke<0x30516389,bool>(object,name,&p)){
   float dx=p.x-origin.x,dy=p.y-origin.y,dz=p.z-origin.z;
   if(fishing::finite(geom(p))&&dx*dx+dy*dy+dz*dz<9){handBone=name;log("Hand bone found: %s",name);return;}
  }
 }
 log("Hand bone not found; using body-relative rod placement");
}
static rh::Vec handPosition(int actor){
 rh::Vec p{};
 if(handBone){
  int object=rh::invoke<0x4A2063EC,int>(actor);
  if(rh::invoke<0x30516389,bool>(object,handBone,&p)&&fishing::finite(geom(p)))return p;
 }
 return point(.35f,1.0f,.3f);
}
static bool attachRod(float dt,int actor){
 if(rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment))return true;
 rodAttachment=0;rodAttachRetry-=dt;
 if(rodAttachRetry>0||!rh::validObject(props[0].object))return false;
 rodAttachRetry=1.f;
 if(!handBone)findHandBone(actor);
 if(!handBone)return false;
 int parent=rh::invoke<0x4A2063EC,int>(actor);
 if(!rh::validObject(parent))return false;
 // RDR.exe 0x140230E80: child, parent, parent bone, packed offset,
 // offset Z, packed rotation, rotation Z, flags (8 native slots).
 rodAttachment=rh::invoke<0xE1421B42,int>(props[0].object,parent,handBone,
     rh::XY{0,0},0.f,rh::XY{0,0},0.f,0);
 bool attached=rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment);
 if(attached){
  // 0x1402DAA5C: preserve child rotation while the engine updates hand translation.
  rh::invoke<0xA870B28E>(rodAttachment,true);
 }
 log("Rod attachment: bone=%s child=%d parent=%d attachment=%d valid=%d",
     handBone,props[0].object,parent,rodAttachment,int(attached));
 return attached;
}
static bool findWater(rh::Vec candidate,rh::Vec& hit){
 // RDR.exe 1.0.40 handler 0x1402965D0: two packed input vectors,
 // then two vector output pointers. The SDK's eight-int placeholder is incomplete.
 alignas(16) rh::Vec intersection{},normal{};
 float top=origin.y+8, bottom=origin.y-40;
 bool ok=rh::invoke<0x4F193BE4,bool>(rh::XY{candidate.x,top},candidate.z,rh::XY{candidate.x,bottom},candidate.z,&intersection,&normal,0,0);
 if(ok&&fishing::waterHitValid(geom(candidate),geom(intersection),top,bottom)){
  hit=intersection;log("Water hit at %.3f %.3f %.3f",hit.x,hit.y,hit.z);return true;
 }
 log("No water intersection at %.3f %.3f (result=%d xyz=%.3f %.3f %.3f)",candidate.x,candidate.z,int(ok),intersection.x,intersection.y,intersection.z);
 return false;
}
static bool prepareCast(int actor){
 origin=rh::position(actor);hasWaterTarget=false;
 if(!updateCastDirection()){
  notice="Cannot read camera direction.\nLook toward the water and try again.";noticeTime=4;
  log("Cast refused: camera direction unavailable or vertical");return false;
 }
 log("Cast direction from camera: %.4f %.4f %.4f",forward.x,forward.y,forward.z);
 if(autoWater){
  // Prefer requested distance; shorten until we find a water surface ahead.
  for(float distance=castDistance;distance>=2.9f;distance-=2){
   auto candidate=point(distance,0);
   if(findWater(candidate,waterTarget)){hasWaterTarget=true;break;}
  }
 }
 if(!hasWaterTarget){
  if(requireWater&&autoWater){notice="No water ahead.\nFace the water and press your cast key.";noticeTime=4;log("Cast refused: no verified water surface ahead");return false;}
  waterTarget=point(castDistance,waterOffset);hasWaterTarget=true;
  log("Manual water target: %.3f %.3f %.3f",waterTarget.x,waterTarget.y,waterTarget.z);
 }
 // Keep the model pivot slightly above water so the float remains visible.
 waterTarget.y+=.08f;
 noticeTime=0;
 log("Cast target: %.3f %.3f %.3f (player %.3f %.3f %.3f)",waterTarget.x,waterTarget.y,waterTarget.z,origin.x,origin.y,origin.z);
 return true;
}
static bool project(rh::Vec p,float& x,float& y){
 if(!rh::invoke<0xBAA72911,bool>(&p,&x,&y))return false;
 return std::isfinite(x)&&std::isfinite(y)&&x>=0&&x<=1&&y>=0&&y<=1;
}
static void drawRig(){
 using fishing::Phase;
 bool out=game.phase==Phase::Cast||game.phase==Phase::Wait||game.phase==Phase::Bite||game.phase==Phase::Fight;
 if(!out)return;
 if(showLine){
  RECT viewport{};
  if(!GetClientRect(GetForegroundWindow(),&viewport))return;
  int width=int(viewport.right-viewport.left),height=int(viewport.bottom-viewport.top);
  if(width<1||height<1)return;
  float invWidth=1.f/width,invHeight=1.f/height;
  bool previousValid=false,connected=false;int previousX=0,previousY=0;
  for(int i=0;i<=48;i++){
   float t=i/48.f;auto p=fishing::mix(geom(lineTip),geom(bobberPosition),t);
   p.y-=std::sin(t*3.14159265f)*.18f;
   float x=0,y=0;
   if(!project(vector(p),x,y)){previousValid=false;connected=false;continue;}
   int px=std::clamp(int(std::lround(x*(width-1))),0,width-1);
   int py=std::clamp(int(std::lround(y*(height-1))),0,height-1);
   if(previousValid){
    fishing::solidLine(previousX,previousY,px,py,connected,[&](int left,int top,int w,int h){
     rh::drawRect((left+w*.5f)*invWidth,(top+h*.5f)*invHeight,w*invWidth,h*invHeight,220,225,215,190);
    });
    connected=true;
   }
   previousX=px;previousY=py;previousValid=true;
  }
 }
}
static void updateFish(float dt,rh::Vec hook){
 if(fishRequestPending){
  fishLoadTime+=dt;
  if(rh::invoke<0xD7F80035,bool>(fishAsset)){fishRequestPending=false;fishLoaded=true;log("Fish asset loaded: %s",fishModel.c_str());}
  else if(fishLoadTime>5){fishRequestPending=false;log("Fish asset unavailable: %s (no substitute model created)",fishModel.c_str());}
 }
 if(!fishVisiblePhase()){removeFish();return;}
 if(!fishLoaded)return;
 // Default anchor is the model pivot. Fine mouth alignment requires in-game verification.
 rh::Vec position{hook.x-fishMouthOffset.x,hook.y-fishMouthOffset.y,hook.z-fishMouthOffset.z};
 if(!fishSpawnAttempted){
  fishSpawnAttempted=true;std::string path="$/fragments/"+fishModel;
  fishObject=rh::invoke<0xE351587D,int>(layout,"FishingHookedFish",path.c_str(),rh::XY{position.x,position.y},position.z,rh::XY{0,0},0.f,true);
  log("Fish spawn in %s: model=%s object=%d valid=%d",stateName(game.phase),fishModel.c_str(),fishObject,int(rh::validObject(fishObject)));
 }
 if(rh::validObject(fishObject)){
  rh::move(fishObject,position);
  // Fish head is local -X. Point the head toward John, tail toward the sea.
  // Reverse v0.1.11 yaw by 180 degrees; keep the fish horizontal.
  float flutter=fishMouthOffset.x==0&&fishMouthOffset.y==0&&fishMouthOffset.z==0?10.f*std::sin(game.elapsed*10):0.f;
  float fishYaw=std::atan2(forward.x,forward.z)*57.295779513f+90.f;
  rh::invoke<0xC8A4EE74,bool>(fishObject,rh::XY{0,fishYaw},flutter);
 }
}
static void updateProps(float dt,int actor){
 if(!visuals||!layout)return;
 loadTime+=dt;
 for(auto& p:props){if(p.done)continue;
  if(fishing::validAsset(p.asset)&&rh::invoke<0xD7F80035,bool>(p.asset)){
   auto at=point(.4f,1);std::string path="$/fragments/";path+=p.name;
   p.object=rh::invoke<0xE351587D,int>(layout,p.name,path.c_str(),rh::XY{at.x,at.y},at.z,rh::XY{0,0},0.f,true);p.done=true;log("Created %s: object=%d valid=%d",p.name,p.object,int(rh::validObject(p.object)));
  }else if(loadTime>5){p.done=true;log("Model unavailable: %s; continuing gameplay without it",p.name);}
 }
 if(game.phase==fishing::Phase::Ready)updateCastDirection();
 auto hand=handPosition(actor);
 // Procedural rod motion; body animation is not fabricated from unknown lasso clip names.
 float pitch=-12;
 if(game.phase==fishing::Phase::Cast)pitch=-55+90*std::clamp(game.elapsed/1.1f,0.f,1.f);
 else if(game.phase==fishing::Phase::Bite)pitch=-28+8*std::sin(game.elapsed*12);
 else if(game.phase==fishing::Phase::Fight)pitch=-20-game.tension*22+4*std::sin(game.elapsed*5);
 bool rodAttached=attachRod(dt,actor);
 bool rodMoved=rodAttached;
 if(!rodAttached&&rh::validObject(props[0].object))
  rodMoved=rh::invoke<0xC5D796F8,bool>(props[0].object,rh::XY{hand.x,hand.y},hand.z);
 if(rh::validObject(props[0].object))rh::invoke<0xC8A4EE74,bool>(props[0].object,rh::XY{pitch,std::atan2(forward.x,forward.z)*57.295779513f},0.f);
 lineTip={hand.x+forward.x*1.7f,hand.y+1,hand.z+forward.z*1.7f};
 // Use the actual rod tip when this model exposes its named terminal bone.
 if(rh::validObject(props[0].object)){
  rh::Vec tip{};
  if(rh::invoke<0x30516389,bool>(props[0].object,"joint5",&tip)&&fishing::finite(geom(tip))){
   float dx=tip.x-hand.x,dy=tip.y-hand.y,dz=tip.z-hand.z;
   if(dx*dx+dy*dy+dz*dz<100)lineTip=tip;
  }
 }
 using fishing::Phase;
 bool cast=game.phase==Phase::Cast;
 bool out=cast||game.phase==Phase::Wait||game.phase==Phase::Bite||game.phase==Phase::Fight;
 bobberPosition=point(.65f,.9f,.25f);
 if(out&&hasWaterTarget){
  bobberPosition=waterTarget;
  if(cast)bobberPosition=vector(fishing::castPath(geom(hand),geom(waterTarget),game.elapsed/1.1f));
  else if(game.phase==Phase::Fight){
   auto closePoint=point(2,0);closePoint.y=waterTarget.y;
   bobberPosition=vector(fishing::mix(geom(waterTarget),geom(closePoint),game.progress));
   bobberPosition.y+=.025f*std::sin(game.elapsed*8);
  }else if(game.phase==Phase::Bite)bobberPosition.y+=.06f*std::sin(game.elapsed*18);
  else bobberPosition.y+=.018f*std::sin(game.elapsed*3);
 }
 bool bobberMoved=rh::validObject(props[1].object)&&rh::invoke<0xC5D796F8,bool>(props[1].object,rh::XY{bobberPosition.x,bobberPosition.y},bobberPosition.z);
 auto hook=bobberPosition;hook.y-=out?.3f:.12f;
 rh::move(props[2].object,hook);
 updateFish(dt,hook);
 drawRig();
 visualLogTime+=dt;
 if(visualLogTime>=2){
  visualLogTime=0;rh::Vec actual{};
  if(rh::validObject(props[1].object))rh::invoke<0x31201B4C,bool>(props[1].object,&actual);
  log("Rig %s: moveRod=%d moveFloat=%d desired=(%.3f %.3f %.3f) actual=(%.3f %.3f %.3f)",stateName(game.phase),int(rodMoved),int(bobberMoved),bobberPosition.x,bobberPosition.y,bobberPosition.z,actual.x,actual.y,actual.z);
  if(rh::validObject(fishObject)){rh::Vec fishAt{};rh::invoke<0x31201B4C,bool>(fishObject,&fishAt);log("Fish follows hook: object=%d hook=(%.3f %.3f %.3f) fish=(%.3f %.3f %.3f)",fishObject,hook.x,hook.y,hook.z,fishAt.x,fishAt.y,fishAt.z);}
 }
}
static void hud(){
 if(!hudEnabled)return;
 using fishing::Phase;
 // RedHook queues draw calls; storage must remain valid after this function returns.
 static char buf[1024];char detail[512]{};
 switch(game.phase){
 case Phase::Ready:snprintf(detail,sizeof(detail),"%s: CAST | %s: stop\nLook toward the water with the camera",actionName.c_str(),toggleName.c_str());break;
 case Phase::Cast:snprintf(detail,sizeof(detail),"Casting...");break;
 case Phase::Wait:snprintf(detail,sizeof(detail),"Waiting for a bite: %.0f s\nWait for BITE, then press %s",std::ceil(std::max(0.f,game.wait-game.elapsed)),actionName.c_str());break;
 case Phase::Bite:snprintf(detail,sizeof(detail),"BITE! Press %s NOW! %.1f s",actionName.c_str(),std::max(0.f,game.biteWindow-game.elapsed));break;
 case Phase::Fight:snprintf(detail,sizeof(detail),"Hold %s: reel | Hold %s: ease\nTension: %d%% | Reeled: %d%%\nFish pulls: %s",reelName.c_str(),easeName.c_str(),int(game.tension*100),int(game.progress*100),(int(game.elapsed/1.6f)%3)!=2?"YES":"NO");break;
 case Phase::Caught:snprintf(detail,sizeof(detail),"CAUGHT! %.2f kg | %s: next cast",game.weight,actionName.c_str());break;
 case Phase::Lost:snprintf(detail,sizeof(detail),"Fish escaped / line lost. %s: try again",actionName.c_str());break;
 default:return;
 }
 if(noticeTime>0)snprintf(detail,sizeof(detail),"%s",notice);
 snprintf(buf,sizeof(buf),"FISHING v0.1.13 | Total catches: %u\n%s",game.catches,detail);
 // HUD text has no panel background; keep the tension gauge only.
 // Eight black copies form a one-pixel outline around every glyph, including diagonals.
 // Use client pixels, since RedHook text coordinates are normalized.
 RECT viewport{};
 float outlineX=1.f/1920.f,outlineY=1.f/1080.f;
 if(GetClientRect(GetForegroundWindow(),&viewport)&&viewport.right>viewport.left&&viewport.bottom>viewport.top){
  outlineX=1.f/(viewport.right-viewport.left);outlineY=1.f/(viewport.bottom-viewport.top);
 }
 for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
  if(dx||dy)rh::drawText(buf,.035f+dx*outlineX,.25f+dy*outlineY,0,hudTextHeight,0,0,0,255,0);
 }
 rh::drawText(buf,.035f,.25f,0,hudTextHeight,255,255,255,255,0);
 if(game.phase==Phase::Fight){
  rh::drawRect(.24f,.345f,.41f,.008f,60,60,60,255);
  float width=.41f*std::clamp(game.tension,0.f,1.f);
  rh::drawRect(.035f+width*.5f,.345f,width,.008f,game.tension>.8f?255:80,game.tension>.8f?60:220,60,255);
 }
}
static void script(){
 char path[MAX_PATH];GetModuleFileNameA(module,path,MAX_PATH);std::string root=path;root=root.substr(0,root.find_last_of("\\/")+1);iniPath=root+"Fishing.ini";logPath=root+"Fishing.log";
 hudEnabled=GetPrivateProfileIntA("HUD","Enabled",1,iniPath.c_str())!=0;
 hudTextHeight=std::clamp(GetPrivateProfileIntA("HUD","TextHeightPermille",18,iniPath.c_str()),12u,24u)/1000.f;
 char fishName[160]{};
 GetPrivateProfileStringA("Fish","Model","p_gen_fish02x",fishName,sizeof(fishName),iniPath.c_str());
 fishModel=fishName;
 if(fishModel=="p_gen_fish01x"){fishModel="p_gen_fish02x";log("Replaced sliced fish01 with intact fish02");}
 if(!GetPrivateProfileIntA("Fish","Enabled",1,iniPath.c_str()))fishModel.clear();
 // Resource names only: do not accept paths or a local WFT masquerading as an installed asset.
 if(fishModel.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")!=std::string::npos)fishModel.clear();
 fishMouthOffset={std::clamp(int(GetPrivateProfileIntA("Fish","MouthOffsetXcm",0,iniPath.c_str())),-500,500)/100.f,std::clamp(int(GetPrivateProfileIntA("Fish","MouthOffsetYcm",0,iniPath.c_str())),-500,500)/100.f,std::clamp(int(GetPrivateProfileIntA("Fish","MouthOffsetZcm",0,iniPath.c_str())),-500,500)/100.f};
 visuals=GetPrivateProfileIntA("Fishing","Visuals",1,iniPath.c_str())!=0;
 waterOffset=std::clamp(int(GetPrivateProfileIntA("Fishing","WaterOffsetCm",-65,iniPath.c_str()))/100.f,-5.f,2.f);
 autoWater=GetPrivateProfileIntA("Fishing","AutoWater",1,iniPath.c_str())!=0;
 requireWater=GetPrivateProfileIntA("Fishing","RequireWater",1,iniPath.c_str())!=0;
 showLine=GetPrivateProfileIntA("HUD","ShowLine",1,iniPath.c_str())!=0;
 castDistance=std::clamp(GetPrivateProfileIntA("Fishing","CastDistance",9,iniPath.c_str())*1.f,3.f,20.f);
 toggleKey=readKey("Toggle",VK_F6);actionKey=readKey("Action",'E');reelKey=readKey("Reel",'R');easeKey=readKey("Ease",'Q');
 if(toggleKey==actionKey||toggleKey==reelKey||toggleKey==easeKey||actionKey==reelKey||actionKey==easeKey||reelKey==easeKey){toggleKey=VK_F6;actionKey='E';reelKey='R';easeKey='Q';log("Duplicate bindings: restored F6/E/R/Q");}
 toggleName=keyName(toggleKey);actionName=keyName(actionKey);reelName=keyName(reelKey);easeName=keyName(easeKey);
 game.biteWindow=std::clamp(GetPrivateProfileIntA("Fishing","BiteWindowSeconds",6,iniPath.c_str())*1.f,3.f,20.f);
 game.catches=GetPrivateProfileIntA("Progress","Catches",0,iniPath.c_str());savedCatches=game.catches;game.seed=GetTickCount();
 log("v0.1.13 loaded. Toggle=%s action=%s reel=%s ease=%s visuals=%d biteWindow=%.1f",toggleName.c_str(),actionName.c_str(),reelName.c_str(),easeName.c_str(),int(visuals),game.biteWindow);
 log("HUD enabled=%d textHeight=%.3f (fraction of screen height)",int(hudEnabled),hudTextHeight);
 log("Fish model=%s (pivot anchor; mouth alignment unverified)",fishModel.empty()?"disabled":fishModel.c_str());
 float previous=rh::invoke<0x5842B9D1,float>();
 rh::help("Fishing v0.1.13 loaded. Stand on shore. Default toggle: F6.");
 while(true){
  rh::wait(0);
  float now=rh::invoke<0x5842B9D1,float>();float dt=std::clamp(now-previous,0.f,.1f);previous=now;
  DWORD foregroundPid=0;
  GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);
  bool toggleEdge=toggleButton.sample((GetAsyncKeyState(toggleKey)&0x8000)!=0);
  bool actionEdge=actionButton.sample((GetAsyncKeyState(actionKey)&0x8000)!=0);
  if(foregroundPid!=GetCurrentProcessId()||rh::invoke<0x57246C02,bool>())continue;
  int a=rh::player();bool alive=rh::validActor(a)&&!rh::invoke<0x0D798FFE,bool>(a);
  if(game.phase!=fishing::Phase::Off&&(!alive||!rh::invoke<0x63D6551C,bool>(a))){cleanup();game.enter(fishing::Phase::Off);log("Stopped: player unavailable or not on foot");}
  if(toggleEdge){
   if(game.phase!=fishing::Phase::Off){cleanup();game.enter(fishing::Phase::Off);rh::help("Fishing stopped. Safe to unload Fishing.red.");log("Stopped by player");}
   else if(alive&&rh::invoke<0x63D6551C,bool>(a)){
    origin=rh::position(a);float h=rh::invoke<0x42DE39F0,float>(a)*.01745329252f;forward={std::sin(h),0,std::cos(h)};updateCastDirection();game.enter(fishing::Phase::Ready);findHandBone(a);requestProps();log("Enabled at %.3f %.3f %.3f heading %.3f",origin.x,origin.y,origin.z,h);
   }
  }
  if(game.phase==fishing::Phase::Off)continue;
  auto pos=rh::position(a);float dx=pos.x-origin.x,dz=pos.z-origin.z;
  if(dx*dx+dz*dz>4){cleanup();game.enter(fishing::Phase::Off);rh::help("Fishing stopped: moved away from casting spot.");log("Stopped: player moved");continue;}
  noticeTime=std::max(0.f,noticeTime-dt);
  auto old=game.phase;
  if(actionEdge&&old==fishing::Phase::Ready&&!prepareCast(a))actionEdge=false;
  if(actionEdge)log("Action pressed in %s at %.2f s%s",stateName(old),game.elapsed,old==fishing::Phase::Wait?" (waiting for bite; ignored)":"");
  game.update(dt,{actionEdge,(GetAsyncKeyState(reelKey)&0x8000)!=0,(GetAsyncKeyState(easeKey)&0x8000)!=0});
  if(old!=game.phase){
   log("State %s -> %s (wait=%.2f tension=%.2f progress=%.2f)",stateName(old),stateName(game.phase),game.wait,game.tension,game.progress);
   if(game.phase==fishing::Phase::Bite)log("BITE: press %s within %.1f seconds",actionName.c_str(),game.biteWindow);
   if(old==fishing::Phase::Bite&&game.phase==fishing::Phase::Lost)log("Missed bite: no new Action press during bite window");
  }
  if(game.catches!=savedCatches)save();
  updateProps(dt,a);hud();
 }
}
BOOL WINAPI DllMain(HMODULE m,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH){module=m;DisableThreadLibraryCalls(m);if(!rh::bind())return FALSE;rh::reg(m,script);}
 else if(reason==DLL_PROCESS_DETACH&&rh::unreg)rh::unreg(m);
 return TRUE;
}
