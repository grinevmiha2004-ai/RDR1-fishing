#pragma once
#include <cmath>
namespace fishing {
// TASK_PLAY_ANIM ABI verified in RDR.exe, not the SDK's guessed parameter names.
// Slot 4 is the playback-rate multiplier. Slot 8 is the optional seconds timer.
inline constexpr float castPlaybackRate=1.f;
inline constexpr float castTaskTimer=-1.f;
template<class Native> void requestCastClip(Native native,int actor,const char* clip){
 native(actor,clip,.1f,.1f,castPlaybackRate,0,false,false,castTaskTimer);
}
struct CastClipProgress {
 float last=-1;
 bool advanced=false;
 void reset(){last=-1;advanced=false;}
 bool observe(bool matched,float time){
  if(!matched||!std::isfinite(time)||time<0)return false;
  bool first=!advanced&&last>=0&&time>last+.0001f;
  advanced=advanced||first;last=time;return first;
 }
};
}
