#pragma once
#include <algorithm>
#include <cmath>
namespace fishing {
inline constexpr const char* reelEvent="HUD_MENU_MENU_060308_DPAD_03";
// The sample is ~59ms; leave a short gap and never overlap owned voices.
struct ReelAudio {
 int sound=-1;
 float elapsed=0,retry=0;
 template<class Audio> void stop(Audio& audio){
  if(sound>=0){audio.stop(sound);audio.release(sound);sound=-1;}
  elapsed=0;retry=0;
 }
 template<class Audio> bool update(bool wanted,float dt,Audio& audio){
  if(!wanted){stop(audio);return true;}
  dt=std::isfinite(dt)?std::clamp(dt,0.f,.1f):0.f;
  if(dt<=0){stop(audio);return true;}
  if(sound>=0){
   elapsed+=dt;
   if(elapsed<.08f)return true;
   // Normally allow the one-shot to finish. A stuck voice is reclaimed.
   if(!audio.finished(sound)&&elapsed<.5f)return true;
   audio.stop(sound);audio.release(sound);sound=-1;elapsed=0;
  }
  retry=std::max(0.f,retry-dt);if(retry>0)return true;
  sound=audio.allocate();
  if(sound<0){retry=.25f;return false;}
  audio.play(sound,reelEvent);elapsed=0;return true;
 }
};
}
