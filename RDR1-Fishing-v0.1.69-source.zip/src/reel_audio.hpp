#pragma once
#include <algorithm>
#include <cmath>
#include <array>
#include <cstdint>
namespace fishing {
struct ReelClip {const char* event;uint32_t sample;};
inline constexpr std::array<ReelClip,4> reelClips={{{"HUD_MENU_MENU_060308_DPAD_01",0x062C7D5B},
 {"HUD_MENU_MENU_060308_DPAD_04",0x0D414B88},
 {"HUD_MENU_MENU_060308_NAV_03",0x04E7D9D6},
 {"HUD_MENU_MENU_060308_NAV_04",0x0F88EF19}}};
// The sample is ~59ms; leave a short gap and never overlap owned voices.
struct ReelAudio {
 int sound=-1,last=-1;
 uint32_t seed=0x9e3779b9u;
 const char* choose(){
  if(!seed)seed=0x9e3779b9u;
  seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;
  int selected=int(seed%uint32_t(last<0?reelClips.size():reelClips.size()-1));
  if(last>=0&&selected>=last)++selected;
  last=selected;return reelClips[selected].event;
 }
 float elapsed=0,retry=0;
 template<class Audio> void stop(Audio& audio){
  if(sound>=0){audio.stop(sound);audio.release(sound);sound=-1;}
  elapsed=0;retry=0;
 }
 template<class Audio> bool update(bool wanted,float dt,Audio& audio){
  if(!wanted){stop(audio);return true;}
  dt=std::isfinite(dt)?std::clamp(dt,0.f,.1f):0.f;
  if(dt<=0){stop(audio);return true;}
  if(sound>=0){
   elapsed+=dt;
   if(elapsed<.16f)return true;
   // Normally allow the one-shot to finish. A stuck voice is reclaimed.
   if(!audio.finished(sound)&&elapsed<.5f)return true;
   audio.stop(sound);audio.release(sound);sound=-1;elapsed=0;
  }
  retry=std::max(0.f,retry-dt);if(retry>0)return true;
  sound=audio.allocate();
  if(sound<0){retry=.25f;return false;}
  audio.play(sound,choose());elapsed=0;return true;
 }
};
}
