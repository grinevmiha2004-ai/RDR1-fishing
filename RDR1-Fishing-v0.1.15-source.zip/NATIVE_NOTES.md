# Native-call evidence (RDR.exe supplied by user)

Executable SHA256: 22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e.
Static analysis only; no claim of runtime validation for the new calls.

- `SET_OBJECT_POSITION`, hash C5D796F8: handler VA 0x14022F920 reads the object
  handle at argument slot 0, packed XY at slot 1, and Z at slot 2. The SDK signature
  and our existing packing agree; motion failure must be diagnosed through the
  boolean return and `GET_OBJECT_POSITION`, rather than assuming a packing defect.
- `SET_OBJECT_ORIENTATION`, hash C8A4EE74: handler VA 0x1402308D0 reads the same
  packed vector pattern and applies a degrees-to-radians conversion before dispatch.
- `FIND_WATER_INTERSECTION`, hash 4F193BE4: registration points to VA 0x1402965D0.
  It reads two packed vectors from argument slots 0/1 and 2/3, then vector output
  pointers from slots 4 and 5. It invokes the intersection routine at 0x140295DC0
  with the water collision mask 0x400000 and writes a boolean result. The adapter
  supplies two initialized, aligned vector outputs and two trailing zero arguments
  for the SDK's placeholder arity. Output position is validated before use.
- `WORLD_TO_SCREEN`, hash BAA72911: supplied by RedHook v0.8, not base game.
  Handler VA 0x180024780 in supplied RedHook.dll reads a position pointer and two
  float output pointers. It returns false for points outside the view; successful
  outputs are normalized screen coordinates. Used only for visual markers.
- `GET_OBJECT_NAMED_BONE_POSITION`, hash 30516389, and `GET_OBJECT_FROM_ACTOR`,
  hash 4A2063EC: typed signatures from the supplied SDK. Bone names are probed
  and validated by proximity; a body-relative fallback is used when unavailable.

No unknown animator or lasso task parameters were guessed in this release.
Player animation and WAS/WAT playback remain unfinished.

## v0.1.13 attachment and cast direction

- GET_CAMERA_CHANNEL_DIRECTION (6ED00237), handler 0x1403AAEF0:
  output vector pointer at slot 0, channel at slot 1; channel zero supported.
  Returns negated camera backward basis, the actual forward view direction.
- GET_HEADING uses atan2(actor +Z basis X, actor +Z basis Z) at 0x140AD4AB0.
  Old -sin(heading) reflected X incorrectly. The cast now uses the view vector
  directly, and yaw reconstruction uses atan2(X,Z).
- ATTACH_OBJECTS (E1421B42), handler 0x140230E80 and helper 0x1402DA4D0:
  child object, parent object, parent bone name, offset XY, offset Z,
  rotation XY (degrees), rotation Z, integer flags. 8 slots, not SDK's 10 ints.
  Parent bone resolved by helper 0x1402F2400. Child is object whose attachment
  field gets assigned at 0x1402DA8AA.
- SET_ATTACHMENT_IGNORE_ROTATION (A870B28E) writes attachment byte +0x62.
  Update 0x1402DAA5C copies existing child basis and applies only translation
  when this flag is set. This retains procedural rod rotation while binding
  the pivot to the animated hand. No finger/arm animation is claimed.
- Cleanup removes only this plugin's saved attachment before deleting the rod.

Static disassembly evidence only; in-game validation remains necessary.

## v0.1.14 live actor bone discovery

The user's 0.1.13 log contains repeated Hand bone not found and no created rod
attachment. Do not interpret that run as successful attachment validation.

GET_OBJECT_FROM_ACTOR at 0x14022BA90 is identity, returning the actor handle.
GET_OBJECT_NAMED_BONE_POSITION at 0x140230A90 resolves the handle through
RVA 0x2C36778 (16-byte records with generation at +8) and calls the object's
vtable +0x100 getter with true. Returned pose +8 is the skeleton descriptor.
Helper 0x1402D9D10 obtains the bone count at descriptor +0x30 (uint16),
and compares C-string names at the first pointer in each 0x110-byte descriptor
record through descriptor +0. This exact read-only path is used to enumerate
actual actor bone names instead of assuming animation semantic labels match.

Private offsets are gated by the supplied executable's PE timestamp 6711591D,
SizeOfImage 5A5DD600, AMD64 PE32+, and two handler fingerprints. Pointer reads
use ReadProcessMemory; counts and string lengths are bounded. The one pose
getter call has the same ABI and argument as the existing native. There are no
writes or patches to game memory. This is static ABI evidence, not a game run.

## v0.1.15 wrist_r and camera independence

The user's v0.1.14 log confirms successful live skeleton enumeration, including
wrist_r, wristroll_r and wrist_r_Attachment. Our name filter rejected wrist_r.
Use wrist_r first via the existing named-bone native and native attachment.
The classifier accepts wrist_r but rejects wristroll_r and wrist_r_Attachment.
Rod yaw now uses actor heading, not saved camera/cast direction; idle props and
fallback hand/tip positions use actor coordinates. Camera direction is sampled
only for enabling/actual cast targeting and never drives held rod yaw.
The native attachment retains procedural world rotation while following wrist
translation. Finger grip and bone-relative rod rotation are not implemented.
