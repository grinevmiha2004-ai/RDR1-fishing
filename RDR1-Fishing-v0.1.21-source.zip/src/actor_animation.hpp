#pragma once
#include "rig_names.hpp"
namespace actor_animation {
inline bool profile(uintptr_t base){
 IMAGE_DOS_HEADER dos{};IMAGE_NT_HEADERS64 nt{};
 if(!rig::read(base,dos)||dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<=0||dos.e_lfanew>0x100000||
    !rig::read(base+uintptr_t(dos.e_lfanew),nt)||nt.Signature!=IMAGE_NT_SIGNATURE||
    nt.FileHeader.Machine!=IMAGE_FILE_MACHINE_AMD64||nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||
    nt.FileHeader.TimeDateStamp!=0x6711591d||nt.OptionalHeader.SizeOfImage!=0x5a5dd600)return false;
 // Task execution at 140B3B450 calls this exact engine routine with this ABI.
 const unsigned char expected[]={0x48,0x89,0x54,0x24,0x10,0x56,0x57,0x48,0x81,0xec,0xc8,0,0,0,0x48,0x83};
 unsigned char actual[sizeof(expected)]{};
 return rig::read(base+0xcde6f0,actual)&&!std::memcmp(actual,expected,sizeof(expected));
}
inline bool handle(uintptr_t table,int value,uintptr_t& object){
 if(!table)return false;
 uintptr_t entry=table+uintptr_t(uint32_t(value)&0xffff)*16;
 uint16_t generation=0;
 return rig::read(entry+8,generation)&&generation==uint16_t(uint32_t(value)>>16)&&rig::read(entry,object)&&object;
}
inline bool context(int actor,uintptr_t& component,uintptr_t& controller,const char*& reason){
 uintptr_t base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
 if(!profile(base)){reason="unsupported executable profile/fingerprint";return false;}
 uintptr_t objects=0,controllers=0,object=0;
 int controllerHandle=0;
 if(!rig::read(base+0x2c36778,objects)||!handle(objects,actor,object)||
    !rig::read(object+0xb0,controllerHandle)||!rig::read(base+0x2c36768,controllers)||
    !handle(controllers,controllerHandle,controller)||!rig::read(controller+0x38,component)||!component){
  reason="actor animation component unavailable";return false;
 }
 reason="ok";return true;
}
inline bool currentSet(int actor,std::string& name,const char*& reason){
 uintptr_t component=0,controller=0,set=0;
 if(!context(actor,component,controller,reason))return false;
 if(!rig::read(component+0x9a8,set)){reason="cannot read previous animation set";return false;}
 name.clear();if(!set)return true;
 if(!rig::string(set,name)){reason="cannot preserve previous animation set name";return false;}
 return true;
}
inline bool channelsReady(int actor,const char*& reason){
 uintptr_t component=0,controller=0,a=0,b=0;unsigned char blocked=0;
 if(!context(actor,component,controller,reason))return false;
 if(!rig::read(component+0xa18,a)||!rig::read(component+0xa20,b)||!rig::read(component+0xc6b,blocked)){
  reason="cannot read animation channels";return false;
 }
 if(!a||!b){reason="animation channels not initialized";return false;}
 if(blocked){reason="script playback currently blocked";return false;}
 reason="ready";return true;
}
inline bool play(int actor,const char* clip,const char*& reason){
 uintptr_t component=0,controller=0;
 if(!context(actor,component,controller,reason)||!channelsReady(actor,reason))return false;
 uintptr_t base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
 // Same types and arguments as the game's TASK_PLAY_ANIM executor, called
 // directly on the script thread so it doesn't depend on a player AI task queue.
 using Play=bool(*)(uintptr_t,uintptr_t,const char*,float,float,float,int,bool,bool,float);
 bool accepted=reinterpret_cast<Play>(base+0xcde6f0)(component,controller,clip,.1f,.1f,0.f,0,false,false,1.f);
 reason=accepted?"engine accepted":"engine rejected clip/state";
 return accepted;
}
}
