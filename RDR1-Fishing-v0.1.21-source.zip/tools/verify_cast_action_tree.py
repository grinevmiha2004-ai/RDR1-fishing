"""Validate cast paths against a decompressed default_character.wat resource."""
from pathlib import Path
import struct,sys,re,ast
b=Path(sys.argv[1]).read_bytes()
def u(o):return struct.unpack_from('<I',b,o)[0]
def pointer(o):
 p=u(o);assert p>>28==5,hex(p)
 return p&0xfffffff
def hash_name(s):
 h=0
 for c in s.lower().encode():
  h=(h+c)&0xffffffff;h=(h+(h<<10))&0xffffffff;h^=h>>6
 h=(h+(h<<3))&0xffffffff;h^=h>>11
 return (h+(h<<15))&0xffffffff
header=(Path(__file__).resolve().parent.parent/'src/cast_animation.hpp').read_text()
literal=re.search(r'castScriptNode=("[^"\n]+")',header).group(1)
parts=ast.literal_eval(literal).split('\\')
node=pointer(8)
assert u(node+0x20)==hash_name(parts[0])
for part in parts[1:]:
 start=pointer(node+8);count=u(node+12)&0xffff
 children=[pointer(start+i*4) for i in range(count)]
 matches=[x for x in children if u(x+0x20)==hash_name(part)]
 assert len(matches)==1,part
 parent=node;node=matches[0];assert pointer(node+4)==parent
 print(f'PASS: {part}: node 0x{node:X}, hash {hash_name(part):08X}')
for clip in ['nor_lso_stn_mid_trw_pre','nor_lso_stn_mid_trw_mid']:
 assert clip.encode()+b'\0' in b,clip
print('PASS: ScriptAnimation hierarchy and both lasso clip references')

if len(sys.argv)>2:
 exe=Path(sys.argv[2]).read_bytes()
 pe=struct.unpack_from('<I',exe,0x3c)[0]
 assert struct.unpack_from('<H',exe,pe+4)[0]==0x8664
 assert struct.unpack_from('<I',exe,pe+8)[0]==0x6711591d
 assert struct.unpack_from('<I',exe,pe+24+56)[0]==0x5a5dd600
 section_start=pe+24+struct.unpack_from('<H',exe,pe+20)[0]
 def file_offset(rva):
  for i in range(struct.unpack_from('<H',exe,pe+6)[0]):
   size,va,raw_size,raw=struct.unpack_from('<4I',exe,section_start+i*40+8)
   if va<=rva<va+raw_size:return raw+rva-va
  raise AssertionError('missing section')
 source=(Path(__file__).resolve().parent.parent/'src/actor_animation.hpp').read_text()
 text=re.search(r'expected\[\]=\{([^}]+)\}',source).group(1)
 fingerprint=bytes(int(x.strip(),0) for x in text.split(','))
 offset=file_offset(0xcde6f0)
 assert exe[offset:offset+len(fingerprint)]==fingerprint
 print('PASS: direct-play routine fingerprint and runtime PE profile match supplied executable')
