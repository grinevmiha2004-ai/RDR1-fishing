#pragma once
#include <cstring>
namespace fishing {
struct ItemPreviewClip {const char* set;const char* clip;const char* label;};
// Every runtime hash is mapped to its standing authored source in verify_item_preview.py.
inline constexpr ItemPreviewClip itemPreviewClips[]={
 {"lso_base","nor_lso_stn_drw","Lasso: draw"},
 {"lso_base","nor_lso_stn_drw_pst","Lasso: draw finish"},
 {"lso_base","nor_lso_stn_hls_pre","Lasso: stow preparation"},
 {"lso_base","nor_lso_stn_hls","Lasso: stow"},
 {"dyn_base","nor_dyn_stn_drw","Bottle/dynamite: draw"},
 {"dyn_base","nor_dyn_stn_hls","Bottle/dynamite: stow"},
 {"tkn_base","nor_tkn_stn_drw","Throwing knife: draw"},
 {"tkn_base","nor_tkn_stn_hls","Throwing knife: stow"},
 {"item_binoculars","gent_useinventory_binocs_pre","Binoculars: take out"},
 {"item_binoculars","gent_useinventory_binocs_pst","Binoculars: put away"},
 {"item_bandana","gent_useinventory_bandana_pre","Bandana: full take-out action"},
 {"item_bandana","gent_useinventory_bandana_pst","Bandana: full put-away action"},
 {"give_money","give_money","Money: take out and hand over"},
 {"ltn_base","nor_ltn_stn_drw","Lantern: standing draw (NPC source)"},
 {"lso_base","nor_lso_stn_lft_hls_pre","Lasso: left storage reach"},
 {"lso_base","nor_lso_stn_rgt_hls_pre","Lasso: right storage reach"},
 {"lso_base","nor_lso_stn_flt_hls_pre","Lasso: front-left storage reach"},
 {"lso_base","nor_lso_stn_frt_hls_pre","Lasso: front-right storage reach"},
 {"lso_base","nor_lso_stn_hls_pst","Lasso: long post-stow transition"},
 {"dyn_base","nor_dyn_stn_hls_pre","Bottle/dynamite: storage preparation"}
};
inline constexpr int itemPreviewCount=sizeof(itemPreviewClips)/sizeof(*itemPreviewClips);
inline constexpr int itemPreviewBanks=itemPreviewCount/10;
inline int itemPreviewResourceIndex(int index){
 if(index<0||index>=itemPreviewCount)return -1;
 for(int i=0;i<index;++i)if(std::strcmp(itemPreviewClips[i].set,itemPreviewClips[index].set)==0)return i;
 return index;
}
inline int itemPreviewIndex(int bank,int key){return bank>=0&&bank<itemPreviewBanks&&key>=0&&key<10?bank*10+key:-1;}
}
