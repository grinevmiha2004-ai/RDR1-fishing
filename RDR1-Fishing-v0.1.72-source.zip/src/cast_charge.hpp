#pragma once
namespace fishing {
inline constexpr const char* castSpinClip="nor_lso_stn_aup_swing";
inline constexpr const char* castSpinSet="lso_base";
struct CastCharge {
 bool active=false,released=false;
 void begin(){active=true;released=false;}
 bool observe(bool down){bool edge=active&&!released&&!down;if(edge)released=true;return edge;}
 void reset(){active=false;released=false;}
};
}
