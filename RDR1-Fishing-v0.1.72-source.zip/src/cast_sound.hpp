#pragma once
#include <algorithm>
#include <cmath>
namespace fishing {
inline constexpr const char* castWhooshEvent="LASSO_ACTIONS_THROW_MASTER";
struct CastSound {
 int sound=-1;bool played=false;float age=0;
 template<class Audio> void reset(Audio& audio){
  if(sound>=0){audio.stop(sound);audio.release(sound);}
  sound=-1;played=false;age=0;
 }
 template<class Audio> bool launch(Audio& audio){
  if(played)return true;
  played=true;sound=audio.allocate();age=0;
  if(sound<0)return false;
  audio.play(sound,castWhooshEvent);return true;
 }
 template<class Audio> void update(float dt,Audio& audio){
  if(sound<0)return;
  if(!std::isfinite(dt)||dt<=0){if(sound>=0){audio.stop(sound);audio.release(sound);sound=-1;}return;}
  age+=std::min(dt,.1f);
  if(age>=.08f&&audio.finished(sound)){audio.release(sound);sound=-1;}
  else if(age>5){audio.stop(sound);audio.release(sound);sound=-1;}
 }
};
}
