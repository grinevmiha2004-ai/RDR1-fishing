"""Static evidence for the Fight pose candidate; does not prove its visible pose.
Usage: python3 tools/verify_fight_resources.py /path/lso.was /path/default_character.wat
"""
from pathlib import Path
import hashlib,re,struct,sys
was,wat=[Path(p).read_bytes() for p in sys.argv[1:3]]
assert hashlib.sha256(was).hexdigest()=='7975b6f7294d192f2ecdea03b78d5293ac25566717b06fd762cbdb57da84075f'
assert hashlib.sha256(wat).hexdigest()=='1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1'
header=(Path(__file__).resolve().parent.parent/'src/fight_pose.hpp').read_text()
clip=re.search(r'fightHoldClip="([^"]+)"',header).group(1)
assert clip=='nor_lso_stn_mid_trw_suc'
assert clip.encode()+b'\0' in was
h=0
for c in clip.encode():
 h=(h+c)&0xffffffff;h=(h+(h<<10))&0xffffffff;h^=h>>6
h=(h+(h<<3))&0xffffffff;h^=h>>11;h=(h+(h<<15))&0xffffffff
assert struct.pack('<I',h) in was
u=lambda o:struct.unpack_from('<I',wat,o)[0]
p=lambda o:u(o)&0xfffffff
assert p(0xad440+4)==0xad380
assert u(0x9904c)==35
st=p(0x9904c+16)
assert wat[st:wat.index(b'\0',st)].decode()==clip
assert any(p(p(0xad380+44)+4*i)==0x9904c for i in range(u(0xad380+48)&65535))
# Pull-in and tug are distinct child actions under the successful-capture state.
for n,track,name in [(0xadb00,0x9704c,'nor_lso_stn_pulin'),(0xae180,0x76b48,'nor_lso_tug_stn')]:
 assert p(p(n+4)+4)==0xad440
 st=p(track+16);assert wat[st:wat.index(b'\0',st)].decode()==name
print('PASS: real lso clip name/hash; successful-capture state assignment; separate pull-in/tug child actions')
print('Visible two-hand stance with a fishing rod still requires a game test.')
