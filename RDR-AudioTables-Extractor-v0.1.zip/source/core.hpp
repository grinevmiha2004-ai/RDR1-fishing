#pragma once
#include <cstdint>
#include <vector>
#include <string>
#include <stdexcept>
#include <algorithm>
namespace extract {
using Bytes=std::vector<unsigned char>;
inline uint32_t word(const unsigned char* p,bool le){return le?uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24):(uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3];}
inline uint32_t hash(const std::string& s){uint32_t h=0;for(unsigned char c:s){if(c>='A'&&c<='Z')c+=32;h+=c;h+=h<<10;h^=h>>6;}h+=h<<3;h^=h>>11;h+=h<<15;return h;}
struct Header {uint32_t count=0,enc=0;uint64_t tocBytes=0;bool le=false;};
inline Header header(const Bytes& b,uint64_t fileSize){
 if(b.size()!=16)throw std::runtime_error("Incomplete RPF header");
 Header h;
 if(word(b.data(),false)==0x52504636)h.le=false;
 else if(word(b.data(),true)==0x52504636)h.le=true;
 else throw std::runtime_error("This is not an RPF6 archive. Select audio_d11generic.rpf");
 h.count=word(b.data()+4,h.le);h.enc=word(b.data()+12,h.le);
 if(!h.count||h.count>1000000)throw std::runtime_error("Invalid RPF entry count");
 h.tocBytes=(uint64_t(h.count)*20+15)&~uint64_t(15);
 if(h.tocBytes>fileSize-16)throw std::runtime_error("RPF directory extends beyond file");
 return h;
}
struct Entry {uint32_t name=0,size=0,rawOffset=0,flag1=0,flag2=0;bool dir=false;uint32_t first=0,count=0;};
inline std::vector<Entry> entries(const Header& h,const Bytes& toc,uint64_t fileSize){
 if(toc.size()!=h.tocBytes)throw std::runtime_error("Incomplete RPF directory");
 std::vector<Entry> out;
 for(uint32_t i=0;i<h.count;++i){const auto* p=toc.data()+i*20;
  Entry e;e.name=word(p,h.le);auto w1=word(p+4,h.le),w2=word(p+8,h.le);
  e.dir=(w2&0xff000000u)==0x80000000u;
  if(e.dir){e.first=w2&0x7fffffff;e.count=word(p+12,h.le)&0xfffffff;
   if(e.first>h.count||e.count>h.count-e.first)throw std::runtime_error("Invalid RPF directory links (decryption/profile mismatch)");
  }else{
   e.size=w1&0xfffffff;e.rawOffset=w2;e.flag1=word(p+12,h.le);e.flag2=word(p+16,h.le);
   uint64_t offset=uint64_t(w2&0x7fffffff)*8;
   // Validate only ordinary records. Resource records use a different offset mask.
   if(!(e.flag1&0x80000000u)&&(offset>fileSize||e.size>fileSize-offset))throw std::runtime_error("Invalid RPF file bounds (decryption/profile mismatch)");
  }
  out.push_back(e);
 }
 if(!out[0].dir)throw std::runtime_error("RPF root is not a directory (wrong encryption key/profile)");
 return out;
}
struct Target {std::string name;uint32_t index=0;uint64_t offset=0;uint32_t size=0,flag1=0,flag2=0;};
inline std::vector<Target> targets(const std::vector<Entry>& es){
 const char* names[]={"sounds.dat","sounds.dat20","game.dat","game.dat45","game.dat46","waveslots.xml","enginesettings.xml"};
 std::vector<Target> result;
 for(const auto& d:es)if(d.dir&&d.name==hash("config")){
  for(uint32_t i=d.first;i<d.first+d.count;++i){const auto& e=es[i];if(e.dir)continue;
   for(auto name:names)if(e.name==hash(name)){
    if(!e.size||e.size>8*1024*1024)throw std::runtime_error("Unexpected audio table size");
    result.push_back({name,i,uint64_t(e.rawOffset&0x7fffffff)*8,e.size,e.flag1,e.flag2});
   }
  }
 }
 bool sounds=false,game=false;
 for(const auto& t:result){sounds|=t.name=="sounds.dat"||t.name=="sounds.dat20";game|=t.name=="game.dat"||t.name=="game.dat46";}
 if(!sounds||!game)throw std::runtime_error("Required sounds/game tables were not found inside config");
 return result;
}
inline uint32_t crc(const Bytes& b){uint32_t c=0xffffffff;for(auto x:b){c^=x;for(int i=0;i<8;++i)c=(c>>1)^((c&1)?0xedb88320:0);}return ~c;}
inline void put(Bytes& b,uint32_t v,int n){for(int i=0;i<n;++i)b.push_back((v>>(8*i))&255);}
struct Zip {
 Bytes bytes,central;uint32_t count=0;
 void add(const std::string& name,const Bytes& data){
  uint32_t pos=uint32_t(bytes.size()),c=crc(data),size=uint32_t(data.size());
  put(bytes,0x04034b50,4);put(bytes,20,2);put(bytes,0,2);put(bytes,0,2);put(bytes,0,2);put(bytes,33,2);
  put(bytes,c,4);put(bytes,size,4);put(bytes,size,4);put(bytes,uint32_t(name.size()),2);put(bytes,0,2);
  bytes.insert(bytes.end(),name.begin(),name.end());bytes.insert(bytes.end(),data.begin(),data.end());
  put(central,0x02014b50,4);put(central,20,2);put(central,20,2);put(central,0,2);put(central,0,2);put(central,0,2);put(central,33,2);
  put(central,c,4);put(central,size,4);put(central,size,4);put(central,uint32_t(name.size()),2);
  put(central,0,2);put(central,0,2);put(central,0,2);put(central,0,2);put(central,0,4);put(central,pos,4);
  central.insert(central.end(),name.begin(),name.end());++count;
 }
 Bytes finish(){uint32_t offset=uint32_t(bytes.size());bytes.insert(bytes.end(),central.begin(),central.end());put(bytes,0x06054b50,4);put(bytes,0,2);put(bytes,0,2);put(bytes,count,2);put(bytes,count,2);put(bytes,uint32_t(central.size()),4);put(bytes,offset,4);put(bytes,0,2);return bytes;}
};
}
