#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
/workspace/toolchains/mingw/usr/bin/x86_64-w64-mingw32-g++-posix -std=c++17 -O2 -Wall -Wextra -Werror -municode -static main.cpp -o RDR-AudioTables-Extractor.exe -lcomdlg32 -lbcrypt -Wl,--no-insert-timestamp
