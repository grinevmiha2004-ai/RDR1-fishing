#include "core.hpp"
#include <fstream>
#include <cassert>
#include <iostream>
using namespace extract;
void be(Bytes& b,uint32_t x){b.push_back(x>>24);b.push_back(x>>16);b.push_back(x>>8);b.push_back(x);}
int main(int argc,char** argv){
 if(argc==4){
  std::ifstream f(argv[1],std::ios::binary),g(argv[2],std::ios::binary);
  Bytes h((std::istreambuf_iterator<char>(f)),{}),toc((std::istreambuf_iterator<char>(g)),{});
  auto info=header(h,std::stoull(argv[3]));auto es=entries(info,toc,std::stoull(argv[3]));
  std::cout<<"Parsed actual reference RPF entries: "<<es.size()<<"\n";return 0;
 }
 constexpr uint64_t fileSize=uint64_t(3)*1024*1024*1024;
 Bytes h;be(h,0x52504636);be(h,4);be(h,0);be(h,0);
 auto info=header(h,fileSize);Bytes toc;
 auto entry=[&](uint32_t name,uint32_t size,uint32_t offset,uint32_t f1,uint32_t f2){be(toc,name);be(toc,size);be(toc,offset);be(toc,f1);be(toc,f2);};
 entry(0,0,0x80000001,1,0);entry(hash("config"),0,0x80000002,2,0);
 uint64_t offset=uint64_t(2800)*1024*1024;
 entry(hash("sounds.dat20"),4,uint32_t(offset/8),0x40000000,0);
 entry(hash("game.dat46"),3,uint32_t(offset/8+1),0x40000000,0);
 auto all=entries(info,toc,fileSize);auto selected=targets(all);
 assert(selected.size()==2&&selected[0].offset==offset&&selected[0].offset>0x7fffffff);
 Zip z;z.add("sounds.dat20.stored.bin",{0x28,0xb5,0x2f,0xfd});z.add("game.dat46.stored.bin",{1,2,3});
 auto output=z.finish();std::ofstream("test_output.zip",std::ios::binary).write(reinterpret_cast<char*>(output.data()),output.size());
 bool failed=false;try{header(h,20);}catch(...){failed=true;}assert(failed);
 failed=false;toc[16]=1;try{entries(info,toc,fileSize);}catch(...){failed=true;}
 // Explicit truncated table rejected.
 toc.resize(20);try{entries(info,toc,fileSize);}catch(...){failed=true;}assert(failed);
 std::cout<<"PASS: 3GiB offsets, config selection, bounds checks and stored ZIP\n";
}
