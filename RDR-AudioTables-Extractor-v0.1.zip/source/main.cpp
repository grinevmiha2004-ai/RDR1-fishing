#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <bcrypt.h>
#include <cstdio>
#include <sstream>
#include <iomanip>
#include "core.hpp"
#include "key.hpp"
using namespace extract;
struct File {
 HANDLE h=INVALID_HANDLE_VALUE;
 ~File(){if(h!=INVALID_HANDLE_VALUE)CloseHandle(h);}
};
Bytes readAt(HANDLE h,uint64_t offset,uint32_t n){
 LARGE_INTEGER p{};p.QuadPart=LONGLONG(offset);
 if(!SetFilePointerEx(h,p,nullptr,FILE_BEGIN))throw std::runtime_error("Cannot seek archive");
 Bytes b(n);DWORD got=0;
 if(!ReadFile(h,b.data(),n,&got,nullptr)||got!=n)throw std::runtime_error("Cannot read selected archive range");
 return b;
}
void decrypt(Bytes& data){
 BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_KEY_HANDLE key=nullptr;
 auto fail=[&](){if(key)BCryptDestroyKey(key);if(alg)BCryptCloseAlgorithmProvider(alg,0);throw std::runtime_error("Windows AES decryption failed");};
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_AES_ALGORITHM,nullptr,0)<0)fail();
 if(BCryptSetProperty(alg,BCRYPT_CHAINING_MODE,reinterpret_cast<PUCHAR>(const_cast<wchar_t*>(BCRYPT_CHAIN_MODE_ECB)),sizeof(BCRYPT_CHAIN_MODE_ECB),0)<0)fail();
 DWORD objSize=0,got=0;
 if(BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&objSize),sizeof(objSize),&got,0)<0)fail();
 Bytes keyObject(objSize);
 if(BCryptGenerateSymmetricKey(alg,&key,keyObject.data(),objSize,const_cast<PUCHAR>(rpfKey),32,0)<0)fail();
 for(int round=0;round<16;++round){ULONG size=0;
  if(BCryptDecrypt(key,data.data(),ULONG(data.size()),nullptr,nullptr,0,data.data(),ULONG(data.size()),&size,0)<0||size!=data.size())fail();
 }
 BCryptDestroyKey(key);BCryptCloseAlgorithmProvider(alg,0);
}
std::wstring chooseArchive(){
 wchar_t path[32768]{};OPENFILENAMEW dialog{};dialog.lStructSize=sizeof(dialog);
 dialog.lpstrFile=path;dialog.nMaxFile=32768;
 dialog.lpstrFilter=L"RDR archive (audio_d11generic.rpf)\0*.rpf\0All files\0*.*\0";
 dialog.lpstrTitle=L"Select audio_d11generic.rpf (read only)";
 dialog.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;
 if(!GetOpenFileNameW(&dialog))return {};
 return path;
}
int wmain(int argc,wchar_t** argv){
 SetConsoleOutputCP(CP_UTF8);
 try{
  std::wstring path=argc>1?argv[1]:chooseArchive();if(path.empty())return 0;
  File archive;archive.h=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_RANDOM_ACCESS,nullptr);
  if(archive.h==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot open archive for read only");
  LARGE_INTEGER fileSize{};if(!GetFileSizeEx(archive.h,&fileSize)||fileSize.QuadPart<16)throw std::runtime_error("Archive too short");
  auto head=readAt(archive.h,0,16);auto info=header(head,uint64_t(fileSize.QuadPart));
  auto toc=readAt(archive.h,16,uint32_t(info.tocBytes));if(info.enc)decrypt(toc);
  auto all=entries(info,toc,uint64_t(fileSize.QuadPart));auto selected=targets(all);
  Zip zip;std::ostringstream manifest;
  manifest<<"RDR Audio Tables Extractor v0.1\nArchive bytes="<<fileSize.QuadPart<<"\nEntries="<<info.count<<"\nEncrypted TOC="<<info.enc<<"\n";
  manifest<<"Stored payloads, NO decompression. These are not directly usable game replacements.\n";
  uint64_t total=0;
  for(const auto& t:selected){
   if(t.offset>uint64_t(fileSize.QuadPart)||t.size>uint64_t(fileSize.QuadPart)-t.offset)throw std::runtime_error("Selected table is outside archive");
   total+=t.size;if(total>16*1024*1024)throw std::runtime_error("Selected data unexpectedly exceeds16MiB");
   auto raw=readAt(archive.h,t.offset,t.size);
   std::string name=std::to_string(t.index)+"_"+t.name+".stored.bin";
   zip.add(name,raw);
   manifest<<name<<" offset="<<t.offset<<" size="<<t.size<<" flag1=0x"<<std::hex<<t.flag1<<" flag2=0x"<<t.flag2<<" crc32=0x"<<crc(raw)<<std::dec<<"\n";
   std::printf("Read: %s (%u bytes)\n",t.name.c_str(),t.size);
  }
  auto text=manifest.str();zip.add("manifest.txt",Bytes(text.begin(),text.end()));zip.add("rpf_header.bin",head);
  auto bytes=zip.finish();
  wchar_t exe[32768]{};DWORD n=GetModuleFileNameW(nullptr,exe,32768);
  if(!n||n>=32768)throw std::runtime_error("Cannot get output directory");
  std::wstring folder(exe);auto slash=folder.find_last_of(L"\\/");folder=slash==std::wstring::npos?L"":folder.substr(0,slash+1);
  SYSTEMTIME now{};GetLocalTime(&now);wchar_t name[128]{};
  swprintf(name,128,L"RDR_AudioTables_%04u%02u%02u_%02u%02u%02u_%lu.zip",now.wYear,now.wMonth,now.wDay,now.wHour,now.wMinute,now.wSecond,GetCurrentProcessId());
  std::wstring output=folder+name;File out;
  out.h=CreateFileW(output.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
  if(out.h==INVALID_HANDLE_VALUE)throw std::runtime_error("Cannot create ZIP beside utility. Unpack utility to Downloads or Desktop and retry");
  DWORD wrote=0;if(!WriteFile(out.h,bytes.data(),DWORD(bytes.size()),&wrote,nullptr)||wrote!=bytes.size())throw std::runtime_error("Cannot write result ZIP");
  std::printf("\nSUCCESS: %u bytes. Send the RDR_AudioTables_*.zip created beside this utility.\nArchive unchanged.\n",unsigned(bytes.size()));
  MessageBoxW(nullptr,(L"Готово. Пришлите в чат созданный ZIP:\n\n"+output+L"\n\nИгровой архив не изменён.").c_str(),L"RDR Audio Tables",MB_OK|MB_ICONINFORMATION);
  return 0;
 }catch(const std::exception& e){
  std::fprintf(stderr,"ERROR: %s\n",e.what());MessageBoxA(nullptr,e.what(),"RDR Audio Tables - error",MB_OK|MB_ICONERROR);return 1;
 }
}
