#pragma once
namespace fishing {
inline constexpr const char* castWindupClip="nor_lso_stn_mid_trw_pre";
inline constexpr const char* castReleaseClip="nor_lso_stn_mid_trw_mid";
enum class CastAnimCommand {None,Windup,Release,Stop};
struct CastAnimation {
 enum class Stage {Idle,Windup,Release};
 Stage stage=Stage::Idle;
 // Timing is a first integration value, not measured animation duration.
 static constexpr float releaseAt=.35f;
 CastAnimCommand update(bool casting,float elapsed){
  if(!casting){
   bool active=stage!=Stage::Idle;stage=Stage::Idle;
   return active?CastAnimCommand::Stop:CastAnimCommand::None;
  }
  if(stage==Stage::Idle){stage=Stage::Windup;return CastAnimCommand::Windup;}
  if(stage==Stage::Windup&&elapsed>=releaseAt){stage=Stage::Release;return CastAnimCommand::Release;}
  return CastAnimCommand::None;
 }
 void reset(){stage=Stage::Idle;}
};
}
