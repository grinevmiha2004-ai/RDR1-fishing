"""Read-only verification of user-supplied, decompressed lso.was and RDR.exe.
No game assets are distributed by this tool; passing is static evidence only.
Usage: python3 tools/verify_cast_resources.py /path/to/lso.was /path/to/RDR.exe
"""
from pathlib import Path
import hashlib,re,struct,sys
was,exe=map(lambda p:Path(p).read_bytes(),sys.argv[1:3])
assert hashlib.sha256(was).hexdigest()=='7975b6f7294d192f2ecdea03b78d5293ac25566717b06fd762cbdb57da84075f'
assert hashlib.sha256(exe).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
assert was[0x38:0x40]==b'lso.ast\0'
header=(Path(__file__).resolve().parent.parent/'src/cast_animation.hpp').read_text()
def joaat(s):
 h=0
 for c in s.lower().encode():
  h=(h+c)&0xffffffff;h=(h+(h<<10))&0xffffffff;h^=h>>6
 h=(h+(h<<3))&0xffffffff;h^=h>>11
 return (h+(h<<15))&0xffffffff
for field in ['castWindupClip','castReleaseClip']:
 clip=re.search(field+r'="([^"]+)"',header).group(1)
 assert clip.encode()+b'\0' in was,clip
 assert struct.pack('<I',joaat(clip)) in was,clip
# Map PE RVAs without an extra pefile dependency.
nt=struct.unpack_from('<I',exe,0x3c)[0]
count=struct.unpack_from('<H',exe,nt+6)[0]
optional=struct.unpack_from('<H',exe,nt+20)[0]
sections=nt+24+optional
def at(rva,n):
 for i in range(count):
  off=sections+i*40
  virtual_size,start,raw_size,raw=struct.unpack_from('<4I',exe,off+8)
  if start<=rva and rva+n<=start+raw_size:
   return exe[raw+rva-start:raw+rva-start+n]
 raise AssertionError(hex(rva))
assert at(0xce01c9,16)==bytes.fromhex('488b4038488b88a80900004885c97428')
# Both table RIP references and the wrapper->actor handle read used by cast_animset.hpp.
assert 0xce0173+7+struct.unpack('<i',at(0xce0176,4))[0]==0x2c36778
assert at(0xce0199,6)==bytes.fromhex('8b88b0000000')
assert 0xce019f+7+struct.unpack('<i',at(0xce01a2,4))[0]==0x2c36768
assert at(0xce08a1,7)==bytes.fromhex('488b8ba8090000')
print('PASS: real lso animation set, both cast names/hashes, exact RDR.exe and read-only ownership lookup ABI')
