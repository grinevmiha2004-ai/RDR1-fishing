#pragma once
#include "redhook.hpp"
#include <string>
#include <vector>
namespace rig {
// Read-only enumeration of the supplied RDR.exe's skeleton descriptor.
// The sole engine call is the same pose getter used by native 30516389.
template<class T> bool read(uintptr_t address,T& out){
 SIZE_T copied=0;
 return address&&ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<const void*>(address),&out,sizeof(out),&copied)&&copied==sizeof(out);
}
inline bool string(uintptr_t address,std::string& out){
 out.clear();
 for(unsigned i=0;i<96;i++){
  char c=0;if(!read(address+i,c))return false;
  if(!c)return !out.empty();
  if(static_cast<unsigned char>(c)<32||static_cast<unsigned char>(c)>126)return false;
  out+=c;
 }
 return false;
}
inline bool names(int object,std::vector<std::string>& out,const char*& reason){
 out.clear();
 uintptr_t base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
 // Only the supplied RDR.exe PE profile may use these private descriptor offsets.
 IMAGE_DOS_HEADER dos{};IMAGE_NT_HEADERS64 nt{};
 if(!read(base,dos)||dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<=0||dos.e_lfanew>0x100000||
    !read(base+uintptr_t(dos.e_lfanew),nt)||nt.Signature!=IMAGE_NT_SIGNATURE||
    nt.FileHeader.Machine!=IMAGE_FILE_MACHINE_AMD64||nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||
    nt.FileHeader.TimeDateStamp!=0x6711591d||nt.OptionalHeader.SizeOfImage!=0x5a5dd600){
  reason="unsupported executable profile";return false;
 }
 // Additional native-handler fingerprints guard the selected profile.
 const unsigned char boneCode[]={0x48,0x89,0x5c,0x24,0x10,0x48,0x89,0x74,0x24,0x18,0x57,0x48,0x83,0xec,0x20};
 const unsigned char actorCode[]={0x48,0x8b,0x41,0x10,0x48,0x8b,0x09,0x8b,0x00,0x89,0x01,0xc3};
 unsigned char actualBone[sizeof(boneCode)]{},actualActor[sizeof(actorCode)]{};
 if(!read(base+0x230a90,actualBone)||!read(base+0x22ba90,actualActor)||
    std::memcmp(actualBone,boneCode,sizeof(boneCode))||std::memcmp(actualActor,actorCode,sizeof(actorCode))){
  reason="unsupported executable fingerprint";return false;
 }
 uintptr_t table=0,objectPtr=0,vtable=0,getter=0,descriptor=0,bones=0;
 uint16_t generation=0,count=0;
 uintptr_t entry=0;
 if(!read(base+0x2c36778,table)||!table){reason="object table unavailable";return false;}
 entry=table+uintptr_t(uint32_t(object)&0xffff)*16;
 if(!read(entry+8,generation)||generation!=uint16_t(uint32_t(object)>>16)||
    !read(entry,objectPtr)||!read(objectPtr,vtable)||!read(vtable+0x100,getter)){
  reason="invalid actor object";return false;
 }
 // Validate the getter's executable memory before calling the exact verified ABI.
 MEMORY_BASIC_INFORMATION region{};
 if(!VirtualQuery(reinterpret_cast<const void*>(getter),&region,sizeof(region))||
    region.State!=MEM_COMMIT||(region.Protect&(PAGE_GUARD|PAGE_NOACCESS))||
    !(region.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY))){
  reason="pose getter unavailable";return false;
 }
 using PoseGetter=uintptr_t(*)(uintptr_t,bool);
 uintptr_t pose=reinterpret_cast<PoseGetter>(getter)(objectPtr,true);
 if(!read(pose+8,descriptor)||!read(descriptor,bones)||!read(descriptor+0x30,count)||!bones||count==0||count>1024){
  reason="actor skeleton unavailable";return false;
 }
 for(unsigned i=0;i<count;i++){
  uintptr_t namePtr=0;std::string name;
  if(!read(bones+uintptr_t(i)*0x110,namePtr)||!string(namePtr,name)){
   continue; // Some skeletons contain unnamed entries; keep scanning valid names.
  }
  out.push_back(name);
 }
 if(out.empty()){reason="no readable skeleton names";return false;}
 reason="ok";return true;
}
}
