#pragma once
#include <algorithm>
namespace fishing {
// Wait for the real animation set; attempt actor binding once per cast.
struct CastPreparation {
 enum class Stage {Idle,Loading,Ready,Finished};
 enum class Result {None,Start,Timeout,Rejected};
 Stage stage=Stage::Idle;
 float elapsed=0;
 template<class Bind> Result update(bool casting,bool allowed,bool loaded,float dt,Bind bind){
  if(!allowed){reset();return Result::None;}
  if(stage==Stage::Finished){if(!casting)reset();return Result::None;}
  if(stage==Stage::Idle){if(!casting)return Result::None;stage=Stage::Loading;elapsed=0;}
  if(stage!=Stage::Loading)return Result::None;
  if(loaded){stage=Stage::Finished;if(!bind())return Result::Rejected;stage=Stage::Ready;return Result::Start;}
  elapsed+=std::clamp(dt,0.f,.1f);
  if(elapsed>=2.f){stage=Stage::Finished;return Result::Timeout;}
  return Result::None;
 }
 void complete(){stage=Stage::Finished;elapsed=0;}
 void reset(){stage=Stage::Idle;elapsed=0;}
};
}
