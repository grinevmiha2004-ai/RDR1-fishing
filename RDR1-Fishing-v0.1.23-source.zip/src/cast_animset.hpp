#pragma once
#include "rig_names.hpp"
namespace castset {
struct Snapshot {uintptr_t resource=0;bool locked=false;};
// Read-only ownership check. All animation changes use public game natives.
// Follow the same handle resolution as ACTOR_HAS_ANIM_SET in the supplied EXE.
inline bool snapshot(int actor,Snapshot& out,const char*& reason){
 out={};
 uintptr_t base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
 IMAGE_DOS_HEADER dos{};IMAGE_NT_HEADERS64 nt{};
 if(!rig::read(base,dos)||dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<=0||dos.e_lfanew>0x100000||
    !rig::read(base+uintptr_t(dos.e_lfanew),nt)||nt.Signature!=IMAGE_NT_SIGNATURE||
    nt.FileHeader.Machine!=IMAGE_FILE_MACHINE_AMD64||nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||
    nt.FileHeader.TimeDateStamp!=0x6711591d||nt.OptionalHeader.SizeOfImage!=0x5a5dd600){
  reason="unsupported executable profile";return false;
 }
 const unsigned char expected[]={0x48,0x8b,0x40,0x38,0x48,0x8b,0x88,0xa8,0x09,0x00,0x00,0x48,0x85,0xc9,0x74,0x28};
 unsigned char actual[sizeof(expected)]{};
 if(!rig::read(base+0xce01c9,actual)||std::memcmp(expected,actual,sizeof(expected))){reason="unsupported animation fingerprint";return false;}
 uintptr_t table=0,object=0,actorTable=0,actorPtr=0,component=0;
 uint16_t generation=0;uint32_t handle=0;unsigned char locked=0;
 if(!rig::read(base+0x2c36778,table)||!table){reason="object table unavailable";return false;}
 uintptr_t entry=table+uintptr_t(uint32_t(actor)&0xffff)*16;
 if(!rig::read(entry+8,generation)||generation!=uint16_t(uint32_t(actor)>>16)||
    !rig::read(entry,object)||!object||!rig::read(object+0xb0,handle)||
    !rig::read(base+0x2c36768,actorTable)||!actorTable){reason="actor handle unavailable";return false;}
 entry=actorTable+uintptr_t(handle&0xffff)*16;
 if(!rig::read(entry+8,generation)||generation!=uint16_t(handle>>16)||
    !rig::read(entry,actorPtr)||!actorPtr||!rig::read(actorPtr+0x38,component)||!component||
    !rig::read(component+0x9a8,out.resource)||!rig::read(component+0xc6a,locked)){
  reason="actor animation component unavailable";return false;
 }
 out.locked=locked!=0;reason="ok";return true;
}
}
