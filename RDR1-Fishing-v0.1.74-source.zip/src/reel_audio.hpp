#pragma once
#include <algorithm>
#include <cmath>
#include <array>
#include <cstdint>
namespace fishing {
struct ReelClip {const char* event;uint32_t sample;};
inline constexpr std::array<ReelClip,5> reelClips={{{"HUD_MENU_MENU_060308_DPAD_01",0x062C7D5B},
 {"HUD_MENU_MENU_060308_DPAD_04",0x0D414B88},
 {"HUD_MENU_MENU_060308_NAV_03",0x04E7D9D6},
 {"HUD_MENU_MENU_060308_NAV_04",0x0F88EF19},
 {"FOLEY_DOORS_SAFE_TUMBLER_TURN_04",0x04766715}}};
// The sample is ~59ms; leave a short gap and never overlap owned voices.
struct ReelAudio {
 int sound=-1,selected=0;
 std::array<int,reelClips.size()> channels{{-1,-1,-1,-1,-1}};
 uint64_t playCount=0;
 uint32_t seed=0x9e3779b9u;
 const char* choose(){
  if(!seed)seed=0x9e3779b9u;
  seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;
  selected=int(seed%reelClips.size());
  return reelClips[selected].event; // independent draw: repeats ARE allowed
 }
 float elapsed=0,retry=0;
 template<class Audio> void stop(Audio& audio){
  for(auto& id:channels)if(id>=0){audio.stop(id);audio.release(id);id=-1;}
  sound=-1;
  elapsed=0;retry=0;
 }
 template<class Audio> bool update(bool wanted,float dt,Audio& audio){
  if(!wanted){stop(audio);return true;}
  dt=std::isfinite(dt)?std::clamp(dt,0.f,.1f):0.f;
  if(dt<=0){stop(audio);return true;}
  if(sound>=0){
   elapsed+=dt;
   if(elapsed<.16f)return true;
   // Never truncate/release/reallocate between clicks. Reuse our channel
   // only after natural completion; STOP is reserved for explicit cancel.
   if(!audio.finished(sound))return true;
   // Finished: choose below, on that clip's own retained channel.
  }
  retry=std::max(0.f,retry-dt);if(retry>0)return true;
  const char* event=choose();
  auto& id=channels[selected];
  if(id<0)id=audio.allocate();
  sound=id;
  if(sound<0){retry=.25f;return false;}
  audio.play(sound,event);++playCount;elapsed=0;return true;
 }
};
}
