#pragma once
#include "fishing.hpp"
#include "reel_audio.hpp"
#include "world_audio_params.hpp"
namespace fishing {
enum class WaterCue {None=-1,Landing=0,Struggle=1,Caught=2};
inline constexpr std::array<ReelClip,2> waterLanding={{{"FOLEY_FOOTSTEPS_WATER_LG_LAND01",0x008CE18D},
 {"FOLEY_FOOTSTEPS_WATER_LG_WALK04_1",0x014E76D5}}};
inline constexpr std::array<ReelClip,2> waterStruggle={{{"STATIC_WATER_RIVER_WATER_LAP_SAMPLE01_1",0x016EF8B8},
 {"STATIC_PROPS_SPLASH_SML_02",0x00E2AE50}}};
inline constexpr std::array<ReelClip,3> waterCaught={{{"FOLEY_FOOTSTEPS_WATER_LG_JUMP01",0x0F8C00C2},
 {"STATIC_WATER_RIVER_WATER_LAP_SAMPLE01_1",0x016EF8B8},
 {"STATIC_PROPS_SPLASH_SML_02",0x00E2AE50}}};
struct WaterTriggers {
 Phase previous=Phase::Off;bool pulling=false;
 void reset(){*this={};}
 WaterCue update(Phase phase,bool released,float elapsed){
  bool nowPull=phase==Phase::Fight&&fishPulling(elapsed);
  WaterCue cue=WaterCue::None;
  if(previous==Phase::Cast&&phase==Phase::Wait&&released)cue=WaterCue::Landing;
  else if(previous==Phase::Fight&&phase==Phase::Caught)cue=WaterCue::Caught;
  else if(nowPull&&!pulling)cue=WaterCue::Struggle;
  previous=phase;pulling=nowPull;return cue;
 }
};
struct WaterAudio {
 std::array<int,3> sound{{-1,-1,-1}};std::array<float,3> age{};
 uint32_t seed=0x6a09e667u;uint32_t lastSample=0;
 ReelClip choose(WaterCue cue){
  if(!seed)seed=0x6a09e667u;
  seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;
  if(cue==WaterCue::Landing)return waterLanding[seed%waterLanding.size()];
  if(cue==WaterCue::Struggle)return waterStruggle[seed%waterStruggle.size()];
  return waterCaught[seed%waterCaught.size()];
 }
 template<class Audio> void stop(Audio& audio){
  for(auto& id:sound)if(id>=0){audio.stop(id);audio.release(id);id=-1;}
  age={};
 }
 template<class Audio> bool play(WaterCue cue,Audio& audio){
  int slot=int(cue);if(slot<0||slot>=3)return false;
  auto& id=sound[slot];
  if(id>=0){if(!audio.finished(id))audio.stop(id);audio.release(id);id=-1;}
  auto clip=choose(cue);lastSample=clip.sample;
  id=audio.allocate();age[slot]=0;if(id<0)return false;
  if(!audio.play(id,clip.event,waterGainDb(clip.sample))){audio.release(id);id=-1;return false;}
  return true;
 }
 template<class Audio> void update(float dt,Audio& audio){
  if(!std::isfinite(dt)||dt<=0){stop(audio);return;}
  for(unsigned i=0;i<sound.size();++i){auto& id=sound[i];if(id<0)continue;
   age[i]+=std::min(dt,.1f);
   if(age[i]>=.08f&&audio.finished(id)){audio.release(id);id=-1;}
   else if(age[i]>15){audio.stop(id);audio.release(id);id=-1;}
  }
 }
};
}
