#include "../src/fishing.hpp"
#include "../src/visuals.hpp"
#include "../src/line_raster.hpp"
#include "../src/hand_bone.hpp"
#include "../src/cast_animation.hpp"
#include "../src/cast_controls.hpp"
#include "../src/cast_preparation.hpp"
#include "../src/cast_playback.hpp"
#include "../src/cast_turn.hpp"
#include "../src/cast_charge.hpp"
#include "../src/spin_additive_plan.hpp"
#include "../src/fight_pose.hpp"
#include "../src/animset_binding.hpp"
#include <type_traits>
#include <tuple>
#include <cstring>
#include <set>
#include <utility>
#include <cassert>
#include <cstdio>
#include <limits>
using namespace fishing;
void advance(Game& g,Phase target){for(int i=0;i<1000&&g.phase!=target;i++)g.update(.05f,{});assert(g.phase==target);}
void hook(Game& g){g.toggle();g.update(.01f,{true});advance(g,Phase::Bite);g.update(.01f,{true});assert(g.phase==Phase::Fight);}
int main(){
 {
  std::array<uintptr_t,6> slots{};assert(additiveSlotAvailable(slots));
  slots[3]=123;assert(additiveSlotAvailable(slots)); // actual user log: existing layers must coexist
  slots.fill(123);assert(!additiveSlotAvailable(slots));
  slots[5]=0;assert(additiveSlotAvailable(slots));
  uintptr_t clip=456;int calls=0;
  bool accepted=requestAdditiveSpin([&](auto... args){auto a=std::make_tuple(args...);
   static_assert(std::tuple_size_v<decltype(a)> == 8);
   assert(std::get<0>(a)==123&&std::get<1>(a)==&clip);
   assert(!std::get<2>(a)&&std::get<3>(a));
   static_assert(std::is_same_v<std::tuple_element_t<4,decltype(a)>,float>);
   assert(std::get<4>(a)==.1f&&std::get<5>(a)==.15f&&std::get<6>(a)==1.f&&std::get<7>(a)==0);
   ++calls;return true;
  },123,&clip);assert(accepted&&calls==1);
  AdditiveLeaveContext leave(123,456);
  uint32_t mode=0;uintptr_t pointer=0;
  std::memcpy(&mode,leave.data.data()+0x28,4);assert(mode==1);
  assert(leave.data[0x4f]==1&&leave.data[0x53]==0&&leave.data[0x54]==0);
  std::memcpy(&pointer,leave.context.data()+0x30,8);assert(pointer==123);
  std::memcpy(&pointer,leave.state.data()+0x28,8);assert(pointer==456);
  std::memcpy(&pointer,leave.state.data()+0x40,8);assert(pointer==reinterpret_cast<uintptr_t>(leave.data.data()));
  std::memcpy(&pointer,leave.state.data()+0x48,8);assert(pointer==reinterpret_cast<uintptr_t>(leave.context.data()));
  puts("PASS: typed native additive ABI, free-slot coexistence/full-slot rejection and isolated additive leave context layout");
 }

 {
  CastCharge charge;Game g;g.toggle();g.update(.01f,{true});charge.begin();
  for(int i=0;i<10000;++i){charge.observe(true);g.update(castGameStep(true,false,.05f),{});}
  assert(charge.active&&!charge.released&&g.phase==Phase::Cast&&g.elapsed==0);
  charge.observe(false);assert(charge.released);charge.observe(true);assert(charge.released);
  charge.reset();assert(!charge.active&&!charge.released);
  advance(g,Phase::Wait);assert(g.phase==Phase::Wait);
  charge.begin();charge.observe(false);assert(charge.released); // quick tap before streaming/turn completes
  charge.reset();charge.observe(false);assert(!charge.active&&!charge.released); // cancelled release cannot cast
  int requests=0;
  requestCastClip([&](auto... args){auto a=std::make_tuple(args...);
   assert(!std::strcmp(std::get<1>(a),castSpinClip)&&std::get<4>(a)==1.f&&std::get<6>(a)&&std::get<8>(a)==-1.f);++requests;
  },42,castSpinClip);assert(requests==1);
  puts("PASS: unlimited hold gates flight, release is latched, quick tap/cancel and positive-rate looping spin ABI");
 }

 {
  FightFrameTransition transition;
  for(float time:{.02f,.1f,.3f,.5f,.52f})assert(transition.sample(time,.016f)<0);
  assert(transition.sample(.54f,0)<0);
  assert(transition.sample(.54f,.016f)==.5238f);
  assert(transition.sample(.9f,.016f)==.5238f);
  transition.reset();assert(transition.sample(.8f,.016f)<0);
  for(float time:{.9f,.01f,.3f,.52f})assert(transition.sample(time,.016f)<0);
  assert(transition.sample(.55f,.016f)==.5238f);
  transition.reset();assert(transition.sample(-1,.016f)<0);
  puts("PASS: natural phase crossing, exact user-confirmed .5238 hold, no early seek, pause and loop wrap");
 }

 {
  int requests=0;
  requestFightClip([&](auto... args){
   auto a=std::make_tuple(args...);static_assert(std::tuple_size_v<decltype(a)> == 9);
   assert(std::get<0>(a)==42&&!std::strcmp(std::get<1>(a),"nor_lso_pul_wlk_000"));
   static_assert(std::is_same_v<std::tuple_element_t<4,decltype(a)>,float>);
   assert(std::get<2>(a)==.65f);
   assert(std::get<4>(a)==1.f&&std::get<5>(a)==0&&std::get<6>(a)&&!std::get<7>(a)&&std::get<8>(a)==-1.f);
   ++requests;
  },42);
  assert(requests==1);
  FightPose pose;using C=FightPose::Command;auto bind=[](){return true;};
  pose.update(true,true,.05f,false,-1,bind);
  assert(pose.update(true,true,.05f,false,-1,bind)==C::Request);
  assert(pose.update(true,true,.05f,true,0,bind)==C::None);
  assert(pose.stage==FightPose::Stage::Starting);
  assert(pose.update(true,true,.05f,true,.02f,bind)==C::None);
  assert(pose.stage==FightPose::Stage::Holding);
  for(int i=0;i<2000;++i)assert(pose.update(true,true,.05f,true,0.35f,bind)==C::None);
  assert(pose.update(false,true,.05f,true,0.35f,bind)==C::Release);
  assert(pose.update(false,true,.05f,false,-1,bind)==C::None);
  puts("PASS: user-selected key-3 task ABI, advancement before frame hold, no task replay, cancellation");
 }

 {
  using B=AnimBinding;
  assert(classifyAnimBinding(true,false,true,0,false,123,123)==B::Base); // actual v0.1.31 log case
  assert(classifyAnimBinding(true,false,false,0,false,123,123)==B::Rejected); // cast still requires override
  assert(classifyAnimBinding(true,true,false,456,true,123,123)==B::Override);
  assert(classifyAnimBinding(false,false,true,0,false,123,123)==B::Rejected);
  assert(classifyAnimBinding(true,false,true,0,false,123,789)==B::Rejected);
  assert(classifyAnimBinding(true,false,true,0,false,0,0)==B::Rejected);
  assert(classifyAnimBinding(true,false,true,456,false,123,123)==B::Rejected);
  assert(classifyAnimBinding(true,false,true,0,true,123,123)==B::Rejected);
  assert(matchesBaseSession(123,123,0,false));
  assert(!matchesBaseSession(123,789,0,false));
  assert(!matchesBaseSession(123,123,456,false));
  assert(!matchesBaseSession(123,123,0,true));
  puts("PASS: native-base success without override; cast override requirement; base/override ownership changes");
 }

 {
  FightPose pose;using C=FightPose::Command;using S=FightPose::Stage;
  int binds=0;auto bind=[&](){++binds;return true;};
  for(int i=0;i<10;++i)assert(pose.update(false,true,.05f,false,-1,bind)==C::None);
  assert(binds==0); // Cast/Wait/Bite must never bind or request this pose.
  assert(pose.update(true,true,.05f,false,-1,bind)==C::None&&binds==1);
  assert(pose.update(true,true,.05f,false,-1,bind)==C::Request);
  assert(pose.update(true,true,.05f,true,.02f,bind)==C::None&&pose.stage==S::Starting);
  assert(pose.update(true,true,.05f,true,.04f,bind)==C::None&&pose.stage==S::Holding);
  // Long fights, including normalized loop wraps, must not replay the task.
  for(int i=0;i<2000;++i)assert(pose.update(true,true,.05f,true,float(i%20)/20,bind)==C::None);
  assert(binds==1&&pose.owned);
  assert(pose.update(false,true,.05f,false,-1,bind)==C::Release);
  assert(pose.stage==S::Idle&&!pose.owned);
  assert(pose.update(false,true,.05f,false,-1,bind)==C::None);
  pose.update(true,true,.05f,false,-1,bind);pose.update(true,true,.05f,false,-1,bind);
  int retries=0,releases=0;
  for(int i=0;i<50;++i){auto c=pose.update(true,true,.05f,false,-1,bind);retries+=c==C::Retry;releases+=c==C::Release;}
  assert(retries==1&&releases==1&&pose.stage==S::Failed);
  pose.reset();pose.update(true,true,0,false,-1,bind);pose.update(true,true,0,false,-1,bind);
  for(int i=0;i<100;++i)assert(pose.update(true,true,0,false,-1,bind)==C::None);
  // Playing but frozen is bounded, and is never restarted.
  retries=0;releases=0;
  for(int i=0;i<30;++i){auto c=pose.update(true,true,.05f,true,0,bind);retries+=c==C::Retry;releases+=c==C::Release;}
  assert(!retries&&releases==1);
  pose.reset();for(int i=0;i<50;++i)pose.update(true,false,.05f,false,-1,bind);
  assert(pose.stage==S::Failed&&!pose.owned);
  pose.reset();pose.update(true,true,.05f,false,-1,[](){return false;});assert(pose.stage==S::Failed&&!pose.owned);
  pose.reset();pose.update(true,true,.05f,false,-1,bind);pose.update(true,true,.05f,false,-1,bind);pose.update(true,true,.05f,true,.1f,bind);pose.update(true,true,.05f,true,.2f,bind);
  releases=0;for(int i=0;i<20;++i)releases+=pose.update(true,true,.05f,false,-1,bind)==C::Release;
  assert(releases==1&&pose.stage==S::Failed);
  puts("PASS: Fight-only pose lifecycle, single request through long loops, bounded startup/retry, interruption and release");
 }

 {
  CastControls controls;bool enabled=true;int disables=0,restores=0;
  auto read=[&](){return enabled;};
  auto write=[&](bool value){enabled=value;if(value)++restores;else ++disables;};
  assert(controls.acquire(read,write)&&controls.owned&&!enabled);
  controls.acquire(read,write);assert(disables==1); // no repeated toggles
  assert(controls.restore(write)&&enabled&&restores==1);
  assert(!controls.restore(write)&&restores==1); // cleanup idempotent
  enabled=false;assert(!controls.acquire(read,write)&&!controls.owned);
  assert(!controls.restore(write)&&!enabled); // preserve pre-existing disabled control
  enabled=true;controls.acquire(read,write);
  assert(controls.restore(write)&&enabled); // early cancellation, independent of actor validity
 }
 puts("PASS: scoped player-control restoration, cancellation, idempotence and pre-existing disabled state");
 {
  // Streaming may finish after Cast->Wait. No bind or clip request before readiness.
  CastPreparation prep;using Result=CastPreparation::Result;
  int bindings=0;auto bind=[&](){++bindings;return true;};
  Game loading;loading.toggle();loading.update(.01f,{true});
  for(int i=0;i<13;i++){
   assert(prep.update(loading.phase==Phase::Cast,true,false,.1f,bind)==Result::None);
   loading.update(.1f,{});
  }
  assert(loading.phase==Phase::Wait&&bindings==0);
  assert(prep.update(false,true,true,.01f,bind)==Result::None&&bindings==1);
  assert(prep.stage==CastPreparation::Stage::Binding);
  assert(prep.update(false,true,true,.016f,bind)==Result::Start&&bindings==1);
  for(int i=0;i<10;i++)assert(prep.update(false,true,true,.1f,bind)==Result::None);
  assert(bindings==1);
  prep.complete();prep.update(false,true,true,.1f,bind);
  assert(prep.stage==CastPreparation::Stage::Idle);
  // Cancellation while loading must not attach anything, including on late completion.
  prep.update(true,true,false,.1f,bind);
  prep.update(false,false,true,.1f,bind);
  assert(prep.update(false,true,true,.1f,bind)==Result::None&&bindings==1);
  // An existing override rejects binding once; held casting cannot retry every frame.
  assert(prep.update(true,true,true,0,[](){return false;})==Result::Rejected);
  for(int i=0;i<30;i++)assert(prep.update(true,true,true,.1f,bind)==Result::None);
  assert(bindings==1);
  prep.reset();int timeouts=0;
  for(int i=0;i<50;i++)if(prep.update(true,true,false,.1f,bind)==Result::Timeout)++timeouts;
  assert(timeouts==1&&bindings==1);
  prep.reset();prep.update(true,true,false,.1f,bind);
  for(int i=0;i<100;i++)assert(prep.update(true,true,false,0,bind)==Result::None);
  assert(prep.elapsed<.11f); // paused game time must not consume the streaming deadline
 }
 puts("PASS: animation-set streaming, Cast->Wait readiness, cancellation, binding rejection and bounded timeout");
 {
  // Exercise the same native submission used in plugin.cpp. Speed must reach slot 4
  // as a float; the layer is int, both flags bool, and the timer is float.
  float rate=0,timer=0;int calls=0;
  requestCastClip([&](int actor,const char* clip,float,float,auto speed,auto layer,auto loop,auto flag,auto seconds){
   static_assert(std::is_same_v<decltype(speed),float>);
   static_assert(std::is_same_v<decltype(layer),int>);
   static_assert(std::is_same_v<decltype(loop),bool>);
   static_assert(std::is_same_v<decltype(flag),bool>);
   static_assert(std::is_same_v<decltype(seconds),float>);
   assert(actor==42&&clip==castReleaseClip&&layer==0&&loop&&!flag);
   rate=speed;timer=seconds;++calls;
  },42,castReleaseClip);
  assert(calls==1&&rate>0&&timer<0);
  // Verified engine relation: clip-time increments are multiplied by this rate.
  // Reproduce the user's 0.1.23 samples, then feed progression at the submitted rate.
  CastClipProgress progress;
  for(int i=0;i<111;i++)assert(!progress.observe(true,0.f));
  assert(!progress.advanced);
  float clock=0;
  for(int i=0;i<30;i++){clock+=(1.f/60.f)*rate;progress.observe(true,clock);}
  assert(clock>.49f&&progress.advanced);
  progress.reset();assert(!progress.observe(false,-1));
  assert(!progress.observe(true,std::numeric_limits<float>::quiet_NaN()));
  assert(!progress.observe(true,0));assert(progress.observe(true,.016f));
  assert(!progress.observe(true,.032f)); // advancing logged once per request
 }
 puts("PASS: typed native playback request, positive clock rate, natural completion timer and frozen-log regression");
 using Cmd=CastAnimCommand;
 {
  CastAnimation plan;
  assert(plan.update(false,true,0,false,-1)==Cmd::None);
  assert(plan.update(true,true,0,false,-1)==Cmd::Request);
  assert(plan.update(true,true,.1f,false,-1)==Cmd::None);
  assert(plan.update(true,true,.1f,false,-1)==Cmd::None);
  assert(plan.update(true,true,.05f,false,-1)==Cmd::Retry);
  assert(plan.update(true,true,.016f,true,0)==Cmd::None);
  assert(plan.update(true,true,.016f,true,.015f)==Cmd::Launch);
  // Native looping crosses the end of the short clip without ending the hold.
  assert(plan.update(true,true,.1f,true,.98f)==Cmd::None);
  assert(plan.update(true,true,.1f,true,.02f)==Cmd::None);
  for(int i=0;i<25;i++)assert(plan.update(true,true,.1f,true,.5f)==Cmd::None);
  assert(plan.stage==CastAnimation::Stage::Holding);
  assert(plan.update(false,true,.01f,true,.8f)==Cmd::EndHold&&plan.end==CastEnd::Landed);
  for(int i=0;i<2;i++)assert(plan.update(false,true,.1f,false,-1)==Cmd::None);
  assert(plan.update(false,true,.05f,false,-1)==Cmd::Stop);
 }
 {
  CastAnimation absent;assert(absent.update(true,true,0,false,-1)==Cmd::Request);
  int retries=0,ends=0,stops=0;
  for(int i=0;i<50;i++){
   auto c=absent.update(true,true,.1f,false,-1);
   if(c==Cmd::Retry)++retries;
   if(c==Cmd::EndHold)++ends;
   if(c==Cmd::Stop)++stops;
  }
  assert(retries==1&&ends==1&&stops==1&&absent.end==CastEnd::Missing);
  CastAnimation frozen;frozen.update(true,true,0,false,-1);retries=0;
  for(int i=0;i<20;i++)if(frozen.update(true,true,.1f,true,0)==Cmd::Retry)++retries;
  assert(retries==0&&frozen.end==CastEnd::Missing); // never restart a matched active clip
  CastAnimation interrupted;interrupted.update(true,true,0,false,-1);
  assert(interrupted.update(true,true,.016f,true,.02f)==Cmd::Launch);
  assert(interrupted.update(true,true,.1f,false,-1)==Cmd::EndHold&&interrupted.end==CastEnd::Interrupted);
  CastAnimation watchdog;watchdog.update(true,true,0,false,-1);watchdog.update(true,true,.016f,true,.02f);
  for(int i=0;i<70;i++)watchdog.update(true,true,.1f,true,.5f);
  assert(watchdog.end==CastEnd::Watchdog);
  for(auto stage:{CastAnimation::Stage::AwaitStart,CastAnimation::Stage::Holding,CastAnimation::Stage::BlendOut}){
   CastAnimation cancel;cancel.stage=stage;
   assert(cancel.update(false,false,.01f,false,-1)==Cmd::Stop&&cancel.end==CastEnd::Cancelled);
  }
 }
 puts("PASS: confirmed startup, one missing-only retry, loop wrap, hold until landing, cancellation and watchdog");
 for(float distance:{3.f,9.f,20.f}){
  Game synced;synced.castSeconds=castFlightSeconds(distance,true);
  synced.toggle();synced.update(.01f,{true});
  CastAnimation plan;bool released=false;float now=0,launched=-1,landed=-1,ended=-1,finished=-1;
  for(int frame=0;frame<500;frame++){
   constexpr float step=.016f;now+=step;
   synced.update(castGameStep(synced.phase==Phase::Cast,released,step),{});
   if(!released)assert(synced.elapsed==0&&synced.phase==Phase::Cast);
   // Simulate first request missing, bounded retry, then a looping clip starting.
   bool playing=now>.35f;
   float time=playing?std::fmod(now-.35f,1.066f)/1.066f:-1.f;
   auto c=plan.update(synced.phase==Phase::Cast,true,step,playing,time);
   if(c==Cmd::Launch){assert(!released);released=true;launched=now;synced.elapsed=0;}
   if(synced.phase==Phase::Wait&&landed<0)landed=now;
   if(c==Cmd::EndHold)ended=now;
   if(c==Cmd::Stop){finished=now;break;}
  }
  assert(launched>.35f&&launched<.4f);
  assert(landed-launched>=synced.castSeconds-.001f&&landed-launched<synced.castSeconds+.04f);
  assert(ended==landed&&finished>ended&&finished-ended<.3f);
 }
 assert(std::abs(castFlightSeconds(9,true)-1.8f)<.001f);
 assert(castFlightSeconds(20,false)==1.1f);
 puts("PASS: 3/9/20-metre flight timing, flight held until native startup, hands held through landing, immediate cancellation");
 {
  // John starts facing any quadrant; the saved camera ray is the target, not
  // a moving view sampled again during the turn. Simulate native readback.
  for(Point view:{Point{0,0,1},Point{1,.8f,0},Point{0,0,-1},Point{-1,-.8f,0},Point{3,5,4}}){
   for(float initial:{0.f,90.f,179.f,-179.f,270.f,359.f}){
    CastTurn turn;assert(turn.begin(view));float heading=initial;
    float fixedTarget=turn.target;int turningFrames=0;
    Game gate;gate.toggle();gate.update(.01f,{true});
    CastAnimation animation;bool requested=false;
    for(int frame=0;frame<100;frame++){
     constexpr float dt=.016f;float next=heading;
     auto state=turn.update(heading,dt,next);
     assert(turn.target==fixedTarget);
     if(state==CastTurn::Result::Ready){
      assert(std::abs(std::remainder(heading-fixedTarget,360.f))<=.5f);
      // Regression for v0.1.28: native-heading agreement alone allowed John to
      // face the camera. Verify the visible front against the saved throw ray.
      float yaw=heading*.01745329252f;
      Point visibleFront{-std::sin(yaw),0,-std::cos(yaw)},desired{};
      assert(horizontalDirection(view,desired));
      assert(visibleFront.x*desired.x+visibleFront.z*desired.z>.9999f);
      assert(animation.update(true,true,dt,false,-1)==CastAnimCommand::Request);
      requested=true;break;
     }
     assert(state==CastTurn::Result::Turning);
     assert(std::abs(std::remainder(next-heading,360.f))<=360.f*dt+.001f);
     gate.update(castGameStep(true,false,dt),{});
     assert(gate.elapsed==0&&gate.phase==Phase::Cast);
     heading=next;++turningFrames;
    }
    assert(requested&&turningFrames<=33); // at most half a second for a 180-degree turn
   }
  }
  CastTurn wrap;assert(wrap.begin(Point{std::sin(1.f*.01745329252f),0,std::cos(1.f*.01745329252f)}));
  float next=0;assert(wrap.update(179,.001f,next)==CastTurn::Result::Turning);
  assert(next>179); // shortest route is +2 degrees across the seam, not -358
  CastTurn paused;paused.begin(Point{1,0,0});
  for(int i=0;i<100;i++){assert(paused.update(0,0,next)==CastTurn::Result::Turning);assert(next==0);}
  assert(paused.elapsed==0);
  CastTurn blocked;blocked.begin(Point{1,0,0});
  for(int i=0;i<12;i++)assert(blocked.update(0,.1f,next)==CastTurn::Result::Turning);
  assert(blocked.update(0,.1f,next)==CastTurn::Result::Failed);
  CastTurn cancelled;cancelled.begin(Point{-1,0,0});cancelled.reset();
  assert(cancelled.update(0,.1f,next)==CastTurn::Result::Ready&&!cancelled.pending);
  CastTurn invalid;assert(!invalid.begin(Point{0,1,0}));
  invalid.begin(Point{1,0,0});
  assert(invalid.update(std::numeric_limits<float>::quiet_NaN(),.01f,next)==CastTurn::Result::Failed);
 }
 puts("PASS: visible actor front aligned with throw ray, all quadrants, shortest turn, animation gate and cancellation");
 for(const char* name:{"wrist_r","WRIST_R","Hand_Right","SKEL_R_Hand","skel_r_hand","R_Hand","hand_r","Bip01 R Hand"})assert(rightHandBoneName(name));
 for(const char* name:{"wrist_l","wristroll_r","wrist_r_Attachment","Hand_Left","SKEL_L_Hand","R_Hand_Index1","R_Hand_Thumb","Lower_Arm_Right",""})assert(!rightHandBoneName(name));
 puts("PASS: right-hand bone matching; left hand, fingers and forearm rejected");
 // View rays keep their horizontal bearing at every pitch and in every quadrant.
 for(Point view:{Point{0,-.8f,1},Point{1,.4f,0},Point{0,1,-1},Point{-1,-1,0},Point{3,-9,4},Point{-3,9,-4}}){
  Point direction{};assert(horizontalDirection(view,direction));
  assert(direction.y==0&&std::abs(std::hypot(direction.x,direction.z)-1)<.00001f);
  assert(direction.x*view.x+direction.z*view.z>0);
  assert(std::abs(direction.x*view.z-direction.z*view.x)<.00001f);
  Point target{10+direction.x*9,3,20+direction.z*9};
  assert(std::abs(std::hypot(target.x-10,target.z-20)-9)<.00001f);
 }
 Point invalidOut{7,8,9};
 assert(!horizontalDirection(Point{0,1,0},invalidOut));
 assert(!horizontalDirection(Point{0,0,0},invalidOut));
 assert(!horizontalDirection(Point{std::numeric_limits<float>::quiet_NaN(),0,1},invalidOut));
 assert(!horizontalDirection(Point{1,std::numeric_limits<float>::infinity(),0},invalidOut));
 assert(invalidOut.x==7&&invalidOut.y==8&&invalidOut.z==9);
 puts("PASS: camera bearing in six directions and pitches; cast distance; invalid/vertical view rejection");
 Game g;hook(g);
 for(int i=0;i<2000&&g.phase==Phase::Fight;i++)g.update(.02f,{false,g.tension<.6f,g.tension>=.6f});
 assert(g.phase==Phase::Caught&&g.catches==1);
 Game missed;missed.toggle();missed.update(.01f,{true});advance(missed,Phase::Bite);advance(missed,Phase::Lost);assert(!missed.catches);
 Game broken;hook(broken);for(int i=0;i<1000&&broken.phase==Phase::Fight;i++)broken.update(.02f,{false,true,false});assert(broken.phase==Phase::Lost&&!broken.catches);
 Game slack;hook(slack);for(int i=0;i<1000&&slack.phase==Phase::Fight;i++)slack.update(.02f,{false,false,true});assert(slack.phase==Phase::Lost);
 Game cancel;hook(cancel);cancel.toggle();assert(cancel.phase==Phase::Off);
 Game paused;hook(paused);float t=paused.tension;paused.update(0,{false,true});assert(paused.tension==t);assert(paused.progress==0);
 for(unsigned seed=1;seed<=500;seed++){
  Game run;run.seed=seed;hook(run);
  for(int i=0;i<3000&&run.phase==Phase::Fight;i++)run.update(.016f,{false,run.tension<.6f,run.tension>=.6f});
  assert(run.phase==Phase::Caught&&run.catches==1);
  run.update(.1f,{true});assert(run.phase==Phase::Ready&&run.catches==1);
 }
 // Reproduce IDs reported by the user's game: both must reach streaming.
 assert(validAsset(872270493));assert(validAsset(-2085051245));assert(validAsset(-925462083));
 assert(!validAsset(0)&&!validAsset(-1));
 Button b;assert(!b.sample(false));assert(b.sample(true));assert(!b.sample(true));assert(!b.sample(false));assert(b.sample(true));
 Game early;early.toggle();early.update(.01f,{true});advance(early,Phase::Wait);
 early.update(.01f,{true});assert(early.phase==Phase::Wait);
 advance(early,Phase::Bite);
 // A reaction slower than the old 2.2-second window must now hook successfully.
 for(int i=0;i<35;i++)early.update(.1f,{});
 assert(early.phase==Phase::Bite);early.update(.01f,{true});assert(early.phase==Phase::Fight);
 Point hand{822,77,1380},surface{831,75,1380};
 auto first=castPath(hand,surface,0),last=castPath(hand,surface,1),mid=castPath(hand,surface,.5f);
 assert(std::abs(first.y-hand.y)<.0001f&&std::abs(last.y-surface.y)<.0001f);
 assert(last.x==surface.x&&last.z==surface.z&&mid.y>76);
 for(int i=0;i<=100;i++){
  auto p=castPath(hand,surface,i/100.f);assert(finite(p));assert(p.x>=hand.x&&p.x<=surface.x);
 }
 assert(waterHitValid(surface,surface,80,30));
 assert(!waterHitValid(surface,Point{0,0,0},80,30));
 assert(!waterHitValid(surface,Point{surface.x,90,surface.z},80,30));
 assert(!waterHitValid(surface,Point{surface.x+1,75,surface.z},80,30));
 // All slopes: exact one-pixel coverage, endpoints and no gaps between adjacent pixels.
 for(int endX=-10;endX<=10;endX++)for(int endY=-10;endY<=10;endY++){
  std::set<std::pair<int,int>> pixels;
  solidLine(0,0,endX,endY,false,[&](int x,int y,int w,int h){
   assert(w==1||h==1);
   for(int ix=x;ix<x+w;ix++)for(int iy=y;iy<y+h;iy++)assert(pixels.insert({ix,iy}).second);
  });
  int length=std::max(std::abs(endX),std::abs(endY));
  assert(int(pixels.size())==length+1&&pixels.count({0,0})&&pixels.count({endX,endY}));
  for(auto pixel:pixels){
   assert(std::abs(endX*pixel.second-endY*pixel.first)<=length*.5f+.01f);
   if(length){int neighbors=0;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)if((x||y)&&pixels.count({pixel.first+x,pixel.second+y}))++neighbors;assert(neighbors>0);}
  }
 }
 puts("PASS: solid one-pixel line at 441 slopes; cast endpoints, arc, invalid water hits; negative resource hashes, key edges, early action, 3.5-second hook; 500 seeded catches; catch, missed bite, broken line, slack line, cancel, zero-delta pause");
}
