"""Verify all diagnostic keys against actual clip-table entries, without game assets in release.
Usage: python3 tools/verify_picker_resources.py /directory/with/decompressed/WAS
"""
from pathlib import Path
import hashlib,re,struct,sys
root=Path(__file__).resolve().parent.parent
header=(root/'src/animation_picker.hpp').read_text()
pairs=re.findall(r'\{"([^"]+)","([^"]+)"\}',header)
assert len(pairs)==10
hashes={'gent':'93df0fc0d395980051606b5e496abd0ddae1ae97c300e2910d3d156123b772b7','lso_base':'8421b46d94cb22cfca7e3bac3fd0737dbd4a68551029881fa73399de53d48185','lso':'7975b6f7294d192f2ecdea03b78d5293ac25566717b06fd762cbdb57da84075f'}
for i,(clip,name) in enumerate(pairs):
 b=(Path(sys.argv[1])/(name+'.was')).read_bytes()
 assert hashlib.sha256(b).hexdigest()==hashes[name]
 h=0
 for c in clip.encode():h=(h+c)&0xffffffff;h=(h+(h<<10))&0xffffffff;h^=h>>6
 h=(h+(h<<3))&0xffffffff;h^=h>>11;h=(h+(h<<15))&0xffffffff
 hits=[];start=0
 while (at:=b.find(struct.pack('<I',h),start))>=0:
  start=at+1
  if at+8>len(b):continue
  ptr=struct.unpack_from('<I',b,at+4)[0]
  if ptr>>28!=5:continue
  ptr&=0xfffffff
  if ptr+12>len(b):continue
  st=struct.unpack_from('<I',b,ptr+8)[0]
  if st>>28!=5:continue
  st&=0xfffffff
  if st>=len(b):continue
  source=b[st:b.index(b'\0',st)]
  if source.startswith(b'Human\\'):hits.append(source.decode())
 assert hits,(clip,name)
 print(f'PASS key {(i+1)%10}: {clip} in {name}: {hits[0]}')
