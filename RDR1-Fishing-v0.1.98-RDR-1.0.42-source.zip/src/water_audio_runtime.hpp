#pragma once
#include "reel_audio_runtime.hpp"
#include "fish_scale_runtime.hpp"
#include "world_audio_params.hpp"
#include "owned_water_voices.hpp"
namespace fishing {
struct GameWaterAudio {
 OwnedWaterVoices pool;
 alignas(16) Point position{};const char* reason="not started";
 static bool supported(uintptr_t base){
  if(!fishscale::supported(base))return false;
  if(!fishscale::matches(base+0x80dcd0,std::array<unsigned char,32>{0x48,0x8b,0xc4,0x48,0x89,0x58,0x08,0x48,0x89,0x70,0x10,0x57,0x48,0x81,0xec,0x90,0x00,0x00,0x00,0x33,0xf6,0xc7,0x40,0x8c,0x00,0x00,0xff,0xff,0x0f,0x57,0xc0,0x89}))return false;
  if(!fishscale::matches(base+0x80d550,std::array<unsigned char,25>{0x4c,0x8b,0xdc,0x53,0x56,0x48,0x81,0xec,0xb8,0x00,0x00,0x00,0x49,0x8b,0xd8,0x81,0xfa,0x16,0xcf,0x8f,0xe3,0x0f,0x84,0x04,0x03}))return false;
  if(!fishscale::matches(base+0x834de,std::array<unsigned char,18>{0x4c,0x8b,0xac,0x24,0xc0,0x00,0x00,0x00,0x48,0x8b,0xd5,0x4c,0x89,0xa8,0xc0,0x00,0x00,0x00}))return false;
  if(!fishscale::matches(base+0x8eec0,std::array<unsigned char,21>{0x44,0x0f,0xb6,0x49,0x08,0x4c,0x8b,0xd1,0x41,0x81,0xf9,0xff,0x00,0x00,0x00,0x74,0x24,0x0f,0xb6,0x41,0x54}))return false;
  if(!fishscale::matches(base+0x8ef18,std::array<unsigned char,29>{0x4d,0x8b,0x82,0xc0,0x00,0x00,0x00,0x4d,0x85,0xc0,0x74,0x13,0x84,0xc9,0x78,0x0f,0x49,0xc7,0x00,0x00,0x00,0x00,0x00,0x41,0x0f,0xb6,0x81,0xaa,0x00}))return false;
  return true;
 }
 static bool profile(){
  uintptr_t base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
  static int checked=-1;if(checked<0)checked=supported(base)?1:0;return checked==1;
 }
 int allocate(){return pool.allocate();}
 bool finished(int id){auto slot=pool.pointer(id);uintptr_t voice=0;return !slot||!rig::read(reinterpret_cast<uintptr_t>(slot),voice)||!voice;}
 void stop(int id){
  auto slot=pool.pointer(id);uintptr_t voice=0,owner=0;
  if(!slot||!rig::read(reinterpret_cast<uintptr_t>(slot),voice)||!voice)return;
  if(profile()&&rig::read(voice+0xc0,owner)&&owner==reinterpret_cast<uintptr_t>(slot)){
   using Stop=void(*)(uintptr_t,bool);
   auto base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
   reinterpret_cast<Stop>(base+0x8eec0)(voice,false);
  }
 }
 void release(int id){stop(id);pool.recycle(id);}
 bool play(int id,const char* event,float gainDb){
  if(!profile()){reason="unsupported owned world-voice ABI";return false;}
  if(!pool.owns(id)||!finite(position)||!std::isfinite(gainDb)||gainDb>0||gainDb< -24){reason="invalid owned slot/position/gain";return false;}
  auto base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));uintptr_t manager=0;
  if(!rig::read(base+0x2ae2d70,manager)||!manager){reason="audio manager unavailable";return false;}
  stop(id);
  auto slot=pool.pointer(id);*slot=0;
  WorldAudioParams params(&position,gainDb);
  uint32_t hash=rh::invoke<0x84415E28,uint32_t>(event);
  using Play=void(*)(uintptr_t,uint32_t,uintptr_t*,const WorldAudioParams*);
  // Same engine voice creator used by positional audio, without the script-ID
  // wrapper that injects the currently executing script's group/context.
  reinterpret_cast<Play>(base+0x80dcd0)(manager,hash,slot,&params);
  uintptr_t voice=0,owner=0;
  if(!rig::read(reinterpret_cast<uintptr_t>(slot),voice)||!voice){reason="engine did not create a water voice";return false;}
  if(!rig::read(voice+0xc0,owner)||owner!=reinterpret_cast<uintptr_t>(slot)){
   reason="water voice ownership readback mismatch";return false;
  }
  reason="owned world voice created; no script sound ID/group";return true;
 }
};
}
