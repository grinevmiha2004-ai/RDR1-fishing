#pragma once
#include "redhook.hpp"
#include "fish_scale_runtime.hpp"
#include "catch_reward.hpp"
#include <cstdio>
namespace rewards {
struct Snapshot {uintptr_t cashAddress=0,honorAddress=0;float cash=0,honor=0;};
inline const char* reason="not checked";
inline bool writable(uintptr_t address){
 MEMORY_BASIC_INFORMATION page{};
 if(!VirtualQuery(reinterpret_cast<void*>(address),&page,sizeof(page))||page.State!=MEM_COMMIT||
    (page.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
 DWORD access=page.Protect&0xff;
 return (access==PAGE_READWRITE||access==PAGE_WRITECOPY||access==PAGE_EXECUTE_READWRITE||access==PAGE_EXECUTE_WRITECOPY)&&
 address+sizeof(float)<=reinterpret_cast<uintptr_t>(page.BaseAddress)+page.RegionSize;
}
inline bool inspect(Snapshot& state){
 uintptr_t base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
 static int supported=-1;if(supported<0)supported=fishscale::supported(base)?1:0;
 if(!supported){reason="unsupported RDR.exe profile";return false;}
 if(!fishscale::matches(base+0xad7750,std::array<unsigned char,9>{0x48,0x8b,0x41,0x10,0xf3,0x0f,0x10,0x40,0x08})){
  reason="honor handler fingerprint mismatch";return false;
 }
 uintptr_t globals=rh::globalPtr();int count=0;
 if(!globals||!rig::read(globals+54086u*4,count)||count<4||count>100000){reason="stat table unavailable";return false;}
 state.cashAddress=globals+54088u*4;state.honorAddress=globals+54090u*4;
 if(!rig::read(state.cashAddress,state.cash)||!rig::read(state.honorAddress,state.honor)||
    !std::isfinite(state.cash)||state.cash<0||state.cash>100000000||
    !std::isfinite(state.honor)||state.honor < -5000||state.honor>5000||
    !writable(state.cashAddress)||!writable(state.honorAddress)){
  reason="invalid or unwritable game stats";return false;
 }
 // The optional native/HUD cache is not the persistent stat table. In the
 // user's log its mismatch/readiness gate rejected EVERY sale and release.
 // Keep it for diagnostics; never make money or persistent honor depend on it.
 reason="game stats verified";return true;
}
struct Cache {bool readable=false,ready=false;float honor=0;};
inline Cache cache(){
 Cache result;uintptr_t state=0;unsigned char ready=0;
 auto base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
 if(rig::read(base+0x22daf30,state)&&state&&rig::read(state+0x5e9,ready)&&
    rig::read(state+0x434,result.honor)&&std::isfinite(result.honor)){
  result.readable=true;result.ready=ready!=0;
 }
 return result;
}
inline bool write(uintptr_t address,float value){
 SIZE_T bytes=0;float actual=0;
 if(!writable(address)||!WriteProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(address),&value,sizeof(value),&bytes)||bytes!=sizeof(value)){
  reason="stat write failed";return false;
 }
 if(!rig::read(address,actual)||actual!=value){reason="stat readback failed";return false;}
 return true;
}
inline bool apply(bool release,int price,float& before,float& after){
 Snapshot state;if(!inspect(state))return false;
 before=release?state.honor:state.cash;
 after=release?fishing::releasedHonor(before):before+price;
 if(!std::isfinite(after)||(!release&&(price<=0||after>100000000))){reason="invalid reward amount";return false;}
 if(!write(release?state.honorAddress:state.cashAddress,after))return false;
 if(release){
  // Actual signature verified in RDR.exe: player slot, raw honor. SDK omits slot.
  if(after>before){
   rh::invoke<0x4D918005>(0,after);
   static char amount[24];snprintf(amount,sizeof(amount),"+%d",int(std::lround(after-before)));
   // Game stat-increase popup: Jenkins hash of the actual sn_hnrr honor label.
   rh::invoke<0x73DA6AF1>(int32_t(0xAFA3172F),amount,3.f,"",2,-1.f,0,0,0,0,0,0,0);
  }
 }else{
  // UI_SET_MONEY absent in 1.0.42; stat write and PRINT_MONEY retained.
  rh::invoke<0x51948EA6>("sn_mny",int(std::lround(before)),price,7.5f,0.f,"HUD_MENU_MESSAGE_BOX_ALERT_MASTER");
 }
 reason="persistent stat updated and read back";return true;
}
}
