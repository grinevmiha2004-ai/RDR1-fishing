"""Read-only compatibility verification for supplied RDR1.0.42.49788435.
Usage: python3 tools/verify_friend_profile.py /path/to/RDR.exe
Does not execute the game. Older verify_* scripts target historical1.0.40.
"""
from pathlib import Path
import hashlib,re,struct,sys
root=Path(__file__).resolve().parents[1]
b=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(b).hexdigest()=='cc27983d9b9183ad32bf9f12d234a3b76ced27d32cce054279895d65e765b2c5','Unexpected executable'
nt=struct.unpack_from('<I',b,0x3c)[0];count=struct.unpack_from('<H',b,nt+6)[0];opt=struct.unpack_from('<H',b,nt+20)[0]
assert struct.unpack_from('<I',b,nt+8)[0]==0x673783f3
assert struct.unpack_from('<I',b,nt+24+56)[0]==0x5a5ec600
base=struct.unpack_from('<Q',b,nt+24+24)[0]
sections=[struct.unpack_from('<4I',b,nt+24+opt+i*40+8) for i in range(count)]
def at(rva,size):
 for _,start,length,raw in sections:
  if start<=rva and rva+size<=start+length:return b[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
source='\n'.join(p.read_text() for p in (root/'src').glob('*.hpp'))
checks=re.findall(r'(?:matches|fingerprint)\(base\+(0x[0-9a-f]+),(?:std::array<unsigned char,\d+>)?\{([^}]+)\}',source)
protected=[]
for rva,values in checks:
 if int(rva,16) in (0x834de,0x8eec0,0x8ef18):
  protected.append(int(rva,16));continue
 expected=bytes(int(x.strip(),16) for x in values.split(','));assert at(int(rva,16),len(expected))==expected,rva
assert len(checks)>=13
rig=(root/'src/rig_names.hpp').read_text()
for name,rva in [('boneCode',0x230700),('actorCode',0x22b700)]:
 expected=bytes(int(x,16) for x in re.search(name+r'\[\]=\{([^}]+)\}',rig)[1].split(','))
 assert at(rva,len(expected))==expected
anim=bytes.fromhex('488b4038488b88a80900004885c97428')
assert at(0xce05a9,len(anim))==anim
assert at(0x1c81d80+0xb8,8)==struct.pack('<Q',base+0x21a310)
assert at(0x1c81d80+0xc0,8)==struct.pack('<Q',base+0x21a320)
# Independently resolve globals from the new executable's RIP references.
assert 0x22b71b+struct.unpack('<i',at(0x22b717,4))[0]==0x2c45808
assert 0xad7760+struct.unpack('<i',at(0xad775c,4))[0]==0x22daf30
assert 0xcee366+struct.unpack('<i',at(0xcee362,4))[0]==0x2c457f8
assert 0xe3472a+struct.unpack('<i',at(0xe34726,4))[0]==0x2ae2d70
# Every game-native registration used by the script must exist in this EXE.
regs={}
for _,start,length,raw in sections:
 for m in re.finditer(rb'\x4c\x8d\x05(.{4})\xba(.{4})\xe8',b[raw:raw+length],re.S):
  a=start+m.start();regs[struct.unpack('<I',m[2])[0]]=a+7+struct.unpack('<i',m[1])[0]
all_source='\n'.join(p.read_text() for p in (root/'src').glob('*') if p.suffix in ('.cpp','.hpp'))
used={int(x,16) for x in re.findall(r'invoke<(0x[0-9a-fA-F]+)',all_source)}
provided_by_redhook={0x6afb8eb9,0xac93d58a,0xbaa72911}
assert used-provided_by_redhook<=regs.keys(),[hex(x) for x in used-provided_by_redhook-regs.keys()]
assert 0xf71bd93a not in used and b'\x3a\xd9\x1b\xf7' not in b
print(f'PASS: exact1.0.42 EXE, {len(checks)} runtime signatures, skeleton/animset layouts, matrix vtable,4 independently resolved globals and{len(used-provided_by_redhook)} game natives')

# These low .text routines are protected on disk. Their exact fingerprints
# remain mandatory at runtime before engine calls; do not claim static bytes.
assert set(protected)=={0x834de,0x8eec0,0x8ef18}
# Independently resolve creator and stop from unprotected callers.
for call,target in [(0x80dd60,0x80d550),(0x80d62a,0x83200),(0xe34a8b,0x8eec0),(0xde66ac,0x8eec0)]:
 assert at(call,1)==b'\xe8'
 assert call+5+struct.unpack('<i',at(call+1,4))[0]==target
header=(root/'src/water_audio_runtime.hpp').read_text()
assert 'base+0x80dcd0' in header and 'base+0x08eec0' not in header # canonical hex replacement
assert 'base+0x8eec0' in header
assert 'base+0x2ae2d70' in header
print('PASS: owned creator/stop call targets;3 protected-body fingerprints deferred to mandatory runtime checks')
