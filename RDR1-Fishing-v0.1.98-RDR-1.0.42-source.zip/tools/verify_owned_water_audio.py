"""Use friend EXE verifier, including protected-code runtime guard limitations."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name("verify_friend_profile.py")),run_name="__main__")
