#include "../src/fishing.hpp"
#include "../src/visuals.hpp"
#include <cassert>
#include <cstdio>
using namespace fishing;
void advance(Game& g,Phase target){for(int i=0;i<1000&&g.phase!=target;i++)g.update(.05f,{});assert(g.phase==target);}
void hook(Game& g){g.toggle();g.update(.01f,{true});advance(g,Phase::Bite);g.update(.01f,{true});assert(g.phase==Phase::Fight);}
int main(){
 Game g;hook(g);
 for(int i=0;i<2000&&g.phase==Phase::Fight;i++)g.update(.02f,{false,g.tension<.6f,g.tension>=.6f});
 assert(g.phase==Phase::Caught&&g.catches==1);
 Game missed;missed.toggle();missed.update(.01f,{true});advance(missed,Phase::Bite);advance(missed,Phase::Lost);assert(!missed.catches);
 Game broken;hook(broken);for(int i=0;i<1000&&broken.phase==Phase::Fight;i++)broken.update(.02f,{false,true,false});assert(broken.phase==Phase::Lost&&!broken.catches);
 Game slack;hook(slack);for(int i=0;i<1000&&slack.phase==Phase::Fight;i++)slack.update(.02f,{false,false,true});assert(slack.phase==Phase::Lost);
 Game cancel;hook(cancel);cancel.toggle();assert(cancel.phase==Phase::Off);
 Game paused;hook(paused);float t=paused.tension;paused.update(0,{false,true});assert(paused.tension==t);assert(paused.progress==0);
 for(unsigned seed=1;seed<=500;seed++){
  Game run;run.seed=seed;hook(run);
  for(int i=0;i<3000&&run.phase==Phase::Fight;i++)run.update(.016f,{false,run.tension<.6f,run.tension>=.6f});
  assert(run.phase==Phase::Caught&&run.catches==1);
  run.update(.1f,{true});assert(run.phase==Phase::Ready&&run.catches==1);
 }
 // Reproduce IDs reported by the user's game: both must reach streaming.
 assert(validAsset(872270493));assert(validAsset(-2085051245));assert(validAsset(-925462083));
 assert(!validAsset(0)&&!validAsset(-1));
 Button b;assert(!b.sample(false));assert(b.sample(true));assert(!b.sample(true));assert(!b.sample(false));assert(b.sample(true));
 Game early;early.toggle();early.update(.01f,{true});advance(early,Phase::Wait);
 early.update(.01f,{true});assert(early.phase==Phase::Wait);
 advance(early,Phase::Bite);
 // A reaction slower than the old 2.2-second window must now hook successfully.
 for(int i=0;i<35;i++)early.update(.1f,{});
 assert(early.phase==Phase::Bite);early.update(.01f,{true});assert(early.phase==Phase::Fight);
 Point hand{822,77,1380},surface{831,75,1380};
 auto first=castPath(hand,surface,0),last=castPath(hand,surface,1),mid=castPath(hand,surface,.5f);
 assert(std::abs(first.y-hand.y)<.0001f&&std::abs(last.y-surface.y)<.0001f);
 assert(last.x==surface.x&&last.z==surface.z&&mid.y>76);
 for(int i=0;i<=100;i++){
  auto p=castPath(hand,surface,i/100.f);assert(finite(p));assert(p.x>=hand.x&&p.x<=surface.x);
 }
 assert(waterHitValid(surface,surface,80,30));
 assert(!waterHitValid(surface,Point{0,0,0},80,30));
 assert(!waterHitValid(surface,Point{surface.x,90,surface.z},80,30));
 assert(!waterHitValid(surface,Point{surface.x+1,75,surface.z},80,30));
 puts("PASS: cast endpoints, arc, invalid water hits; negative resource hashes, key edges, early action, 3.5-second hook; 500 seeded catches; catch, missed bite, broken line, slack line, cancel, zero-delta pause");
}
