#pragma once
#include "visuals.hpp"
namespace fishing {
// World correction: shaft passes through the palm 12 cm above its butt.
inline Point gripWorld(Point shaft,Point facing){
 float n=std::sqrt(shaft.x*shaft.x+shaft.y*shaft.y+shaft.z*shaft.z);
 if(!finite(shaft)||n<.01f)return {};
 return {-.12f*shaft.x/n-.025f*facing.x-.02f*facing.z,-.12f*shaft.y/n,-.12f*shaft.z/n-.025f*facing.z+.02f*facing.x};
}
inline bool gripLocal(Point world,const Point (&axis)[3],Point& local){
 auto dot=[](Point a,Point b){return a.x*b.x+a.y*b.y+a.z*b.z;};
 for(int i=0;i<3;++i){
  if(!finite(axis[i])||std::abs(dot(axis[i],axis[i])-1.f)>.03f)return false;
  for(int j=0;j<i;++j)if(std::abs(dot(axis[i],axis[j]))>.03f)return false;
 }
 local={dot(world,axis[0]),dot(world,axis[1]),dot(world,axis[2])};
 return finite(world)&&finite(local);
}
}
