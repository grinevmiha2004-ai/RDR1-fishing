#pragma once
#include "visuals.hpp"
namespace fishing {
struct RodCone {
 float blend=0;
 void reset(){blend=0;}
 Point rotation(bool spinning,float dt,float angle,float normalPitch,float heading){
  float step=std::isfinite(dt)?std::clamp(dt,0.f,.1f)/.35f:0.f;
  blend=std::clamp(blend+(spinning?step:-step),0.f,1.f);
  float pitch=-8.f+7.5f*std::cos(angle),roll=7.5f*std::sin(angle);
  float tiltedPitch=normalPitch-8.f;
  return {tiltedPitch+(pitch-tiltedPitch)*blend,heading,roll*blend};
 }
};
}
