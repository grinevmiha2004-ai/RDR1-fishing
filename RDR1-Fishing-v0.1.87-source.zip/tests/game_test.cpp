#include "../src/fishing.hpp"
#include "../src/visuals.hpp"
#include "../src/line_raster.hpp"
#include "../src/hand_bone.hpp"
#include "../src/cast_animation.hpp"
#include "../src/cast_controls.hpp"
#include "../src/cast_preparation.hpp"
#include "../src/cast_playback.hpp"
#include "../src/cast_turn.hpp"
#include "../src/cast_charge.hpp"
#include "../src/tackle_motion.hpp"
#include "../src/rod_cone.hpp"
#include "../src/rod_grip.hpp"
#include "../src/fish_scale.hpp"
#include "../src/fish_hang.hpp"
#include "../src/fight_motion.hpp"
#include "../src/splash.hpp"
#include "../src/throw_preview.hpp"
#include "../src/fish_release.hpp"
#include "../src/item_preview.hpp"
#include "../src/item_sequence.hpp"
#include "../src/line_action.hpp"
#include "../src/recast_preview.hpp"
#include "../src/reel_menu_params.hpp"
#include "../src/reel_audio.hpp"
#include "../src/reel_menu_audio.hpp"
#include "../src/cast_sound.hpp"
#include "../src/water_audio.hpp"
#include "../src/reel_audio_gate.hpp"
#include "../src/tackle_camera.hpp"
#include "../src/spin_additive_plan.hpp"
#include "../src/fight_pose.hpp"
#include "../src/animset_binding.hpp"
#include <type_traits>
#include <tuple>
#include <cstring>
#include <set>
#include <utility>
#include <cassert>
#include <cstdio>
#include <limits>
using namespace fishing;
void advance(Game& g,Phase target){for(int i=0;i<1000&&g.phase!=target;i++)g.update(.05f,{});assert(g.phase==target);}
void hook(Game& g){g.toggle();g.update(.01f,{true});advance(g,Phase::Bite);g.update(.01f,{true});assert(g.phase==Phase::Fight);}
int main(){
 {
  assert(LineAction::canRetrieve(Phase::Wait)&&LineAction::canRetrieve(Phase::Fight)&&LineAction::canRetrieve(Phase::Bite));
  assert(!LineAction::canRetrieve(Phase::Ready)&&!LineAction::canRetrieve(Phase::Caught)&&!LineAction::canRetrieve(Phase::Cast));
  LineAction a;a.begin(LineAction::Kind::Retrieve,{8,0,0},{8,-.3f,0});
  assert(a.clipIndex()==3&&std::strcmp(recastCandidates[a.clipIndex()].clip,"nor_lso_stn_mid_trw_suc")==0);
  assert(!a.observe(-1)&&!a.observe(.24f)&&a.observe(.25f)&&!a.observe(.5f));
  auto start=a.retract(a.bobber,{0,2,0});assert(start.x<8&&start.x>0);
  a.observe(.85f);auto end=a.retract(a.bobber,{0,2,0});
  assert(std::abs(end.x)<.0001f&&std::abs(end.y-2)<.0001f);
  a.begin(LineAction::Kind::Hook);assert(a.clipIndex()==4&&std::strcmp(recastCandidates[a.clipIndex()].clip,"lso_stn_tug")==0);
  assert(!a.observe(.8f)&&!a.committed);a.reset();assert(!a.active());
 }

 {
  using K=ItemSequence::Kind;
  ItemSequence seq;
  for(float kg:{.4f,.99f,1.f,5.f,5.01f,10.f}){
   seq.begin(K::Keep,kg);int index=kg<1?2:kg<=5?3:5;assert(seq.index()==index);
   assert(!seq.eventDue(.44f));assert(seq.eventDue(.45f));assert(!seq.eventDue(.9f));
   assert(!seq.next());
  }
  seq.begin(K::Equip);assert(seq.index()==13&&seq.count==1);
  assert(!seq.eventDue(.44f));assert(seq.eventDue(.45f));assert(!seq.eventDue(1.f));assert(!seq.next());
  seq.begin(K::Stow);assert(seq.index()==8&&!seq.eventDue(.29f)&&seq.eventDue(.3f));
  seq.begin(K::Recover);assert(seq.index()==19&&seq.eventDue(.7f));
  assert(std::strcmp(itemPreviewClips[2].clip,"nor_lso_stn_hls_pre")==0);
  assert(std::strcmp(itemPreviewClips[3].clip,"nor_lso_stn_hls")==0);
  assert(std::strcmp(itemPreviewClips[5].clip,"nor_dyn_stn_hls")==0);
  assert(std::strcmp(itemPreviewClips[19].clip,"nor_dyn_stn_hls_pre")==0);
  assert(std::strcmp(itemPreviewClips[13].clip,"nor_ltn_stn_drw")==0);
  assert(std::strcmp(itemPreviewClips[8].clip,"gent_useinventory_binocs_pre")==0);
  seq.reset();assert(!seq.active()&&!seq.event);
 }

 {
  assert(itemPreviewIndex(0,0)==0&&itemPreviewIndex(0,9)==9);
  assert(itemPreviewIndex(1,0)==10&&itemPreviewIndex(1,9)==19);
  assert(itemPreviewIndex(2,0)==-1&&itemPreviewIndex(0,10)==-1&&itemPreviewIndex(-1,0)==-1);
  assert(itemPreviewResourceIndex(3)==0&&itemPreviewResourceIndex(9)==8&&itemPreviewResourceIndex(11)==10);
  assert(itemPreviewResourceIndex(19)==4&&itemPreviewResourceIndex(20)==-1);
 }

 {
  ReleaseStartup startup;
  assert(startup.update(false,0)==ReleaseStartup::Command::None&&startup.requests==1);
  assert(startup.update(false,.2f)==ReleaseStartup::Command::None);
  assert(startup.update(false,.2f)==ReleaseStartup::Command::Retry&&startup.requests==2);
  assert(startup.update(true,.01f)==ReleaseStartup::Command::None);
  for(int i=0;i<100;++i)assert(startup.update(false,.1f)==ReleaseStartup::Command::None);
  assert(startup.requests==2); // a query gap or interruption must never replay an observed clip
  startup.reset();int retries=0;bool failed=false;
  for(int i=0;i<30;++i){auto c=startup.update(false,.1f);retries+=c==ReleaseStartup::Command::Retry;if(c==ReleaseStartup::Command::Failed){failed=true;break;}}
  assert(retries==2&&failed&&startup.requests==3);
 }

 {
  Game caught;caught.enter(Phase::Caught);caught.catches=7;
  for(int i=0;i<1000;++i)caught.update(.1f,{});
  assert(caught.phase==Phase::Caught&&caught.catches==7);
  caught.update(.01f,{true});assert(caught.phase==Phase::Ready&&caught.catches==7);
  FishRelease release;release.begin({0,2,0},{5,0,0});
  release.stage=FishRelease::Stage::Hand;
  assert(!release.launch(.2f,{0,1,0}));assert(release.launch(.5f,{0,1,0}));
  assert(!release.launch(.8f,{1,1,0}));
  assert(!release.fly(0)&&release.flight==0);
  int impacts=0;bool above=false;
  for(int i=0;i<1000;++i){if(release.fly(.01f))++impacts;auto p=release.position();assert(finite(p));if(p.y>1)above=true;}
  assert(impacts==1&&above&&release.stage==FishRelease::Stage::Landed);
  auto end=release.position();assert(end.x==5&&end.y==0&&end.z==0);
  release.reset();assert(!release.active());
  WaterAudio water;
  for(int i=0;i<100;++i){assert(water.choose(WaterCue::Release).sample==0x008CE18D);assert(water.choose(WaterCue::Landing).sample==0x014E76D5);}
 }

 {
  requestThrowPreview([](int actor,const char* clip,float in,float out,float rate,int flags,bool loop,bool extra,float timer){
   assert(actor==123&&std::strcmp(clip,"nor_dyn_stn_for_mid_und_trw")==0);
   assert(in==.15f&&out==.25f&&rate==1.f&&flags==0&&!loop&&!extra&&timer==-1.f);
  },123,throwPreviewClips[0].clip);
 }

 {
  assert(std::strcmp(splashForWeight(.4f),"bullet_water")==0);
  assert(std::strcmp(splashForWeight(.99f),"bullet_water")==0);
  assert(std::strcmp(splashForWeight(1.f),"ped_water_thrash")==0);
  assert(std::strcmp(splashForWeight(5.f),"ped_water_thrash")==0);
  assert(std::strcmp(splashForWeight(5.01f),"amb_water_rocksplash_2")==0);
  assert(std::strcmp(splashForWeight(10.f),"amb_water_rocksplash_2")==0);
  StruggleSplash fx;assert(!fx.update(false,true,.016f));
  assert(!fx.update(true,true,0));assert(fx.update(true,true,.016f));
  assert(!fx.update(true,true,.016f));
  assert(!fx.update(true,false,.016f));assert(fx.update(true,true,.016f));
  assert(!fx.update(false,true,.016f));assert(fx.update(true,true,.016f));
  fx.reset();assert(!fx.wasPulling);
 }

 {
  ReelMenuParams params;assert(params.gainDb==0&&sizeof(params)==28);
  FightMotion motion;float maxRod=0,maxFish=0,maxSide=0;
  for(int i=0;i<1800;++i){float t=i*.016f;
   motion.update(true,fishPulling(t),.016f,t);
   assert(std::abs(motion.rodPitch)<=8.001f&&std::abs(motion.rodRoll)<=6.001f);
   assert(std::abs(motion.side)<=.1401f&&std::abs(motion.vertical)<=.0801f);
   maxRod=std::max(maxRod,std::abs(motion.rodPitch));maxFish=std::max(maxFish,std::abs(motion.fishRoll));maxSide=std::max(maxSide,std::abs(motion.side));
  }
  assert(maxRod>7&&maxFish>24&&maxSide>.12f);
  auto side=motion.side;motion.update(true,true,0,99);assert(motion.side==side);
  motion.update(false,false,.016f,0);assert(motion.blend==0&&motion.rodRoll==0&&motion.side==0);
  for(int i=0;i<100;++i)motion.update(true,false,.016f,i*.016f);
  assert(motion.rodPitch==0&&motion.rodRoll==0&&motion.side==0);
 }

 {
  struct Menu {int clicks=0;void oneShot(const char* name){assert(name);++clicks;}} audio;
  ReelMenuAudio menu;
  for(int i=0;i<1000;++i)menu.update(true,.016f,"test",audio);
  assert(audio.clicks>80&&audio.clicks<110);int clicks=audio.clicks;
  menu.update(false,.1f,"test",audio);menu.update(true,0,"test",audio);assert(audio.clicks==clicks);
  menu.update(true,.016f,"test",audio);assert(audio.clicks==clicks+1);
  ReelAudio selected;for(int i=0;i<5;++i){selected.fixed=i;for(int j=0;j<100;++j)assert(std::string(selected.choose())==reelClips[i].event);}
 }

 {
  struct Pool {std::array<bool,32> used{},done{};int clicks=0;};
  struct Audio {
   Pool& p;explicit Audio(Pool& pool):p(pool){}
   int allocate(){for(int i=0;i<32;++i)if(!p.used[i]){p.used[i]=true;return i;}return -1;}
   void play(int id,const char*){assert(p.used[id]);p.done[id]=true;++p.clicks;}
   bool finished(int id){assert(p.used[id]);return p.done[id];}
   void stop(int id){assert(p.used[id]);p.done[id]=true;}
   void release(int id){assert(p.used[id]);p.used[id]=false;}
  };
  struct Water:Audio {using Audio::Audio;
   bool play(int id,const char*,float gain){assert(p.used[id]&&gain<=0);p.done[id]=false;return true;}
  };
  Pool pool;Audio reelBackend(pool);Water waterBackend(pool);ReelAudio reel;WaterAudio water;
  reel.update(true,.1f,reelBackend);
  assert(water.play(WaterCue::Struggle,waterBackend));
  int waterId=water.sound[1],before=pool.clicks;
  for(int i=0;i<40;++i){reel.update(true,.1f,reelBackend);water.update(.1f,waterBackend);}
  assert(pool.clicks>before+10&&pool.used[waterId]); // reel continues through active water
  for(int id:reel.channels)if(id>=0)assert(id!=waterId);
  water.stop(waterBackend);assert(!pool.used[waterId]);
  before=pool.clicks;for(int i=0;i<10;++i)reel.update(true,.1f,reelBackend);
  assert(pool.clicks>before);reel.stop(reelBackend);
  for(bool used:pool.used)assert(!used);
 }

 {
  WaterTriggers triggers;
  assert(triggers.update(Phase::Cast,false,0)==WaterCue::None);
  assert(triggers.update(Phase::Cast,true,1)==WaterCue::None);
  assert(triggers.update(Phase::Wait,true,0)==WaterCue::Landing);
  assert(triggers.update(Phase::Wait,true,1)==WaterCue::None);
  assert(triggers.update(Phase::Bite,true,0)==WaterCue::None);
  assert(triggers.update(Phase::Fight,true,0)==WaterCue::Struggle);
  for(int i=1;i<30;++i)assert(triggers.update(Phase::Fight,true,i*.1f)==WaterCue::None);
  assert(triggers.update(Phase::Fight,true,3.3f)==WaterCue::None);
  assert(triggers.update(Phase::Fight,true,4.9f)==WaterCue::Struggle);
  assert(triggers.update(Phase::Caught,true,0)==WaterCue::Caught);
  assert(triggers.update(Phase::Caught,true,1)==WaterCue::None);
  triggers.reset();triggers.update(Phase::Cast,false,0);
  assert(triggers.update(Phase::Ready,false,0)==WaterCue::None);
  static_assert(sizeof(WorldAudioParams)==112);
  Point position{1,2,3};WorldAudioParams params(&position,-6.f);float gain=0;
  std::memcpy(&gain,params.bytes.data(),4);assert(gain==-6.f);
  const Point* readPosition=nullptr;std::memcpy(&readPosition,params.bytes.data()+0x20,sizeof(readPosition));
  assert(readPosition==&position);
  assert(waterGainDb(0x008CE18D)==-6&&waterGainDb(0x00E2AE50)==0);
  WaterAudio water;
  for(int i=0;i<1000;++i){
   auto a=water.choose(WaterCue::Landing).sample;
   auto b=water.choose(WaterCue::Struggle).sample;
   auto c=water.choose(WaterCue::Caught).sample;
   assert(a==0x014E76D5);
   assert(b==0x016EF8B8||b==0x00E2AE50);
   assert(c==0x0F8C00C2||c==0x016EF8B8||c==0x00E2AE50);
  }
 }

 {
  CastCharge charge;charge.begin();int captures=0;
  for(int i=0;i<500;++i){if(charge.observe(true))++captures;}
  assert(captures==0&&charge.active&&!charge.released);
  if(charge.observe(false))++captures;
  for(int i=0;i<100;++i){if(charge.observe(false))++captures;}
  assert(captures==1&&charge.released);
  assert(!charge.observe(true)); // repress cannot retarget a committed throw
  charge.reset();assert(!charge.observe(false));
  charge.begin();assert(charge.observe(false)); // quick tap still captures once
 }

 {
  struct Audio {
   int live=0,next=0,plays=0,releases=0,stops=0;bool fail=false,done=true;
   std::array<const char*,200> events{};
   int allocate(){if(fail)return -1;assert(live<5);++live;return next++;}
   void play(int id,const char* name){assert(id>=0);if(events[id])assert(std::string(events[id])==name);else events[id]=name;bool found=false;
    for(const auto& clip:reelClips)if(std::string(name)==clip.event)found=true;
    assert(found);++plays;}
   bool finished(int){return done;}
   void stop(int){assert(live>0);++stops;}
   void release(int){assert(live>0);--live;++releases;}
  } audio;
  ReelAudio selection;int counts[5]{};int last=-1,repeats=0;
  for(int i=0;i<60000;++i){selection.choose();++counts[selection.selected];if(last==selection.selected)++repeats;last=selection.selected;}
  for(int n:counts)assert(n>11000&&n<13000);
  assert(repeats>10000&&repeats<14000);
  ReelAudio loop;
  assert(loop.update(true,.016f,audio)&&audio.plays==1&&loop.sound==0);
  for(int i=0;i<1000;++i)loop.update(true,.016f,audio);
  assert(audio.live==5&&audio.plays>80&&audio.plays<110);
  assert(audio.next==5&&audio.stops==0&&audio.releases==0);
  loop.stop(audio);assert(audio.live==0&&audio.next==audio.releases);
  loop.stop(audio);assert(audio.next==audio.releases);
  loop.update(true,.016f,audio);loop.update(false,.016f,audio);assert(audio.live==0);
  loop.update(true,.016f,audio);loop.update(true,0,audio);assert(audio.live==0);
  audio.fail=true;assert(!loop.update(true,.016f,audio));assert(audio.live==0);
  audio.fail=false;loop.stop(audio);audio.done=false;
  loop.update(true,.016f,audio);int plays=audio.plays;
  for(int i=0;i<10;++i)loop.update(true,.016f,audio);
  assert(audio.plays==plays); // no truncation/overlap while unfinished
  for(int i=0;i<40;++i)loop.update(true,.016f,audio);
  assert(audio.plays==plays); // unfinished clips are never chopped on timeout
  int stops=audio.stops;
  audio.done=true;loop.update(true,.016f,audio);
  assert(audio.plays==plays+1&&audio.stops==stops);
  loop.stop(audio);
  struct WindAudio {
   int live=0,plays=0,releases=0;bool done=false;
   int allocate(){assert(live==0);++live;return 0;}
   void play(int,const char* name){assert(std::string(name)==castWhooshEvent);++plays;}
   bool finished(int){return done;}
   void stop(int){assert(live==1);}
   void release(int){assert(live>0);--live;++releases;}
  } wind;
  CastSound whoosh;
  assert(whoosh.launch(wind));for(int i=0;i<20;++i){assert(whoosh.launch(wind));whoosh.update(.016f,wind);}
  assert(wind.plays==1&&wind.live==1);
  wind.done=true;whoosh.update(.016f,wind);assert(wind.live==0&&wind.releases==1);
  whoosh.reset(wind);wind.done=false;whoosh.launch(wind);whoosh.update(0,wind);assert(wind.live==0);
  assert(wind.plays==2);

  for(int bits=0;bits<32;++bits)assert(reelSoundWanted(bits&1,bits&2,bits&4,bits&8,bits&16)==(bits==11));
 }

 {
  assert(fishScaleForWeight(1.37f)==1.f);
  assert(fishScaleForWeight(.99f)==.5f&&fishScaleForWeight(1.f)==1.f);
  assert(fishScaleForWeight(5.f)==1.f&&fishScaleForWeight(5.01f)==2.f);
  assert(rollFishWeight(0,0)==.4f&&rollFishWeight(.49999f,.999999f)==.99f);
  assert(rollFishWeight(.5f,0)==1.f&&rollFishWeight(.79999f,.999999f)==5.f);
  assert(rollFishWeight(.8f,0)==5.01f&&rollFishWeight(.99999f,.999999f)==10.f);
  int small=0,normal=0,large=0;Game rolls;
  for(int i=0;i<100000;++i){
   float category=rolls.random(),within=rolls.random();
   float kg=rollFishWeight(category,within);
   assert(kg>=.4f&&kg<=10.f);
   if(kg<1)++small;else if(kg<=5)++normal;else ++large;
  }
  assert(std::abs(small-50000)<1000&&std::abs(normal-30000)<1000&&std::abs(large-20000)<1000);
 }

 {
  for(float yaw:{-270.f,-180.f,-90.f,0.f,90.f}){
   auto initial=fishHang(yaw,{.2f,.1f,.3f},0);
   assert(std::abs(initial.mouth.x-.2f)<.00001f&&std::abs(initial.mouth.z-.3f)<.00001f);
   auto hang=fishHang(yaw,{},1);assert(hang.yaw==0&&hang.roll==-90);
   // Local head axis -X maps to world up, independent of casting bearing.
   float headY=-std::sin(hang.roll*.01745329252f)*std::cos(hang.yaw*.01745329252f);
   assert(std::abs(headY-1)<.00001f);
  }
 }

 {
  FishMatrix in{},out{};for(int i=0;i<4;++i)in.m[i][i]=1;
  in.m[3][0]=10;in.m[3][1]=20;in.m[3][2]=30;
  for(float scale:{.5f,1.f,2.f}){
   assert(scaledFishMatrix(in,scale,{.1f,.2f,.3f},out));
   for(int i=0;i<3;++i)assert(out.m[i][i]==scale&&out.m[i][3]==0);
   assert(std::abs(out.m[3][0]+.1f*scale-10.1f)<.00001f);
   FishMatrix twice{};assert(scaledFishMatrix(out,scale,{},twice));
   assert(twice.m[0][0]==scale); // no cumulative growth
  }
  // Explicitly restore normal/small size after a large fish, even if the
  // engine supplied an already scaled basis. No compounding/retained2x.
  FishMatrix current=in;
  for(float factor:{2.f,1.f,.5f,2.f,1.f}){
   FishMatrix next{};assert(scaledFishMatrix(current,factor,{},next));
   for(int i=0;i<3;++i)assert(std::abs(next.m[i][i]-factor)<.00001f);
   current=next;
  }
  assert(!scaledFishMatrix(in,0,{},out));in.m[0][0]=0;
  assert(!scaledFishMatrix(in,2,{},out));
 }

 {
  Point axes[3]={{0,0,1},{1,0,0},{0,1,0}},local{};
  auto world=gripWorld({0,2,0},{0,0,1});
  assert(std::abs(world.y+.12f)<.00001f&&std::abs(world.z+.025f)<.00001f);
  assert(gripLocal(world,axes,local));
  assert(std::abs(local.x+.025f)<.00001f&&std::abs(local.y+.02f)<.00001f&&std::abs(local.z+.12f)<.00001f);
  axes[1]={0,0,1};assert(!gripLocal(world,axes,local));
  assert(gripWorld({0,0,0},{0,0,1}).y==0);
  auto turned=gripWorld({1,0,0},{1,0,0});
  assert(std::abs(turned.x+.145f)<.00001f&&std::abs(turned.z-.02f)<.00001f);
  RodGripPose grip;
  auto ready=grip.update(GripPose::Ready,.016f,{0,0,1});
  auto paused=grip.update(GripPose::Waiting,0,{0,0,1});
  assert(ready.x==paused.x&&ready.y==paused.y);
  for(int i=0;i<100;++i)grip.update(GripPose::Waiting,.016f,{0,0,1});
  auto waiting=grip.update(GripPose::Waiting,0,{0,0,1});
  assert(std::abs(waiting.x-.02f)<.00001f&&std::abs(waiting.y+.01f)<.00001f);
  auto turnedGrip=grip.update(GripPose::Waiting,0,{1,0,0});
  assert(turnedGrip.x==0&&std::abs(turnedGrip.z+.02f)<.00001f);
  auto interrupted=grip.update(GripPose::Fighting,0,{0,0,1});
  assert(interrupted.x==waiting.x);
  for(int i=0;i<100;++i)grip.update(GripPose::Fighting,.016f,{0,0,1});
  auto fighting=grip.update(GripPose::Fighting,0,{0,0,1});
  assert(std::abs(fighting.x+.05f)<.00001f&&std::abs(fighting.y+.015f)<.00001f);
  for(int i=0;i<100;++i)grip.update(GripPose::Neutral,.016f,{0,0,1});
  auto neutral=grip.update(GripPose::Neutral,0,{0,0,1});assert(std::abs(neutral.x)<.00001f);
  grip.reset();assert(!grip.initialized);
  RodCone cone;
  for(float base : {-55.f,-12.f,35.f,-28.f,-42.f}){
   auto lean=cone.rotation(false,.016f,0,base,90);
   assert(std::abs(lean.x-(base-8.f))<.00001f);
  }
  for(int i=0;i<100;++i)cone.rotation(true,.016f,0,-12,90);
  for(int i=0;i<360;++i){auto r=cone.rotation(true,.016f,i*.01745329252f,-12,90);
   assert(r.x<=-32.5f&&r.x>=-47.5f);
   assert(std::abs(std::hypot(r.x+40.f,r.z)-7.5f)<.001f&&r.y==90);
   assert(std::cos(r.x*.01745329252f)*std::cos(r.z*.01745329252f)>.66f);
  }
  float old=cone.blend;cone.rotation(false,0,0,-12,90);assert(cone.blend==old);
  for(int i=0;i<100;++i)cone.rotation(false,.016f,0,-12,90);
  auto r=cone.rotation(false,.016f,0,-12,90);assert(r.x==-20&&r.z==0);
  TackleCamera camera;int adds=0,removes=0;
  auto add=[&](int cam,int object,int flags){assert(cam&&object&&flags==0);++adds;};
  auto remove=[&](int cam,int object){assert(cam&&object);++removes;};
  camera.sync(100,{1,2,3},add,remove);assert(adds==3&&!removes);
  camera.sync(100,{1,2,3},add,remove);assert(adds==3&&!removes);
  camera.sync(100,{1,20,3},add,remove);assert(adds==4&&removes==1);
  camera.sync(200,{1,20,3},add,remove);assert(adds==7&&removes==4);
  camera.clear(remove);assert(removes==7);camera.clear(remove);assert(removes==7);
  camera.sync(0,{1,2,3},add,remove);assert(adds==7&&!camera.camera);
  puts("PASS: grip world/local projection and rejection; forward-leaning 7.5-degree cone throughout rotation; scoped camera exclusions, camera/prop changes and cleanup");
 }

 {
  auto near=[](Point a,Point b){return std::abs(a.x-b.x)<.0001f&&std::abs(a.y-b.y)<.0001f&&std::abs(a.z-b.z)<.0001f;};
  Point tip={830,80,1380};TackleMotion rig;rig.stow(tip,.016f);
  assert(near(rig.bobber,{830,79.65f,1380})&&near(rig.hook,{830,79.45f,1380}));
  assert(near(tackleLine(tip,rig.bobber,rig.hook,0,.1f),tip));
  assert(near(tackleLine(tip,rig.bobber,rig.hook,.75f,.1f),rig.bobber));
  assert(near(tackleLine(tip,rig.bobber,rig.hook,1,.1f),rig.hook));
  for(int i=0;i<500;++i){rig.whirl(tip,{0,0,1},.01f,std::fmod(i*.01f/.69f,1.f));assert(finite(rig.bobber)&&finite(rig.hook));}
  assert(std::abs(std::hypot(rig.bobber.x-tip.x,rig.bobber.z-tip.z)-1.1f)<.0002f);
  assert(std::abs(std::hypot(rig.hook.x-tip.x,rig.hook.z-tip.z)-1.3f)<.0002f);
  assert(rig.bobber.y>79&&rig.hook.y>79); // both remain in the air
  Point before=rig.bobber;rig.whirl(tip,{0,0,1},0,.9f);assert(near(before,rig.bobber));
  Point b=rig.bobber,h=rig.hook;rig.beginFlight();Point water={839,76,1380};
  rig.fly(tip,water,0,1.8f,.016f);assert(near(rig.bobber,b)&&near(rig.hook,h));
  for(int i=0;i<=200;++i){rig.fly(tip,water,i/200.f,1.8f,.01f);assert(finite(rig.bobber)&&finite(rig.hook));}
  assert(near(rig.bobber,water)&&near(rig.hook,{839,75.7f,1380}));
  rig.stow({10,5,20},.016f);rig.prepare();rig.beginFlight();rig.fly({10,5,20},{15,0,20},0,2,.016f);
  assert(near(rig.bobber,{10,4.65f,20})); // second cast has no stale launch origin
  rig.reset();assert(!rig.valid&&!rig.whirling&&!rig.flight);
  Point tilted={.3f,.9f,.1f};rig.stow(tip,0);
  for(int i=0;i<100;++i)rig.whirl(tip,{0,0,1},.016f,-1,tilted);
  Point radial=subtract(rig.bobber,tip);radial.y+=.08f;
  assert(std::abs(radial.x*tilted.x+radial.y*tilted.y+radial.z*tilted.z)<.0002f);
  for(Point axis:{Point{0,0,1},Point{0,1,0},Point{0,0,0}}){rig.whirl(tip,{0,0,1},.016f,-1,axis);assert(finite(rig.bobber));}
  rig.reset();
  Point start={0,2,0},v={2,1,3},end={8,0,5};float dt=.001f;
  Point p=launchedPath(start,v,end,dt/2,2);Point estimate=scale(subtract(p,start),1/dt);
  assert(std::abs(estimate.x-v.x)<.03f&&std::abs(estimate.y-v.y)<.03f&&std::abs(estimate.z-v.z)<.03f);
  puts("PASS: tip-hung connected tackle, airborne orbit, pause, position/velocity-continuous launch and exact landing");
 }

 {
  std::array<uintptr_t,6> slots{};assert(additiveSlotAvailable(slots));
  slots[3]=123;assert(additiveSlotAvailable(slots)); // actual user log: existing layers must coexist
  slots.fill(123);assert(!additiveSlotAvailable(slots));
  slots[5]=0;assert(additiveSlotAvailable(slots));
  uintptr_t clip=456;int calls=0;
  bool accepted=requestAdditiveSpin([&](auto... args){auto a=std::make_tuple(args...);
   static_assert(std::tuple_size_v<decltype(a)> == 8);
   assert(std::get<0>(a)==123&&std::get<1>(a)==&clip);
   assert(!std::get<2>(a)&&std::get<3>(a));
   static_assert(std::is_same_v<std::tuple_element_t<4,decltype(a)>,float>);
   assert(std::get<4>(a)==.1f&&std::get<5>(a)==.15f&&std::get<6>(a)==1.f&&std::get<7>(a)==0);
   ++calls;return true;
  },123,&clip);assert(accepted&&calls==1);
  AdditiveLeaveContext leave(123,456);
  uint32_t mode=0;uintptr_t pointer=0;
  std::memcpy(&mode,leave.data.data()+0x28,4);assert(mode==1);
  assert(leave.data[0x4f]==1&&leave.data[0x53]==0&&leave.data[0x54]==0);
  std::memcpy(&pointer,leave.context.data()+0x30,8);assert(pointer==123);
  std::memcpy(&pointer,leave.state.data()+0x28,8);assert(pointer==456);
  std::memcpy(&pointer,leave.state.data()+0x40,8);assert(pointer==reinterpret_cast<uintptr_t>(leave.data.data()));
  std::memcpy(&pointer,leave.state.data()+0x48,8);assert(pointer==reinterpret_cast<uintptr_t>(leave.context.data()));
  puts("PASS: typed native additive ABI, free-slot coexistence/full-slot rejection and isolated additive leave context layout");
 }

 {
  CastCharge charge;Game g;g.toggle();g.update(.01f,{true});charge.begin();
  for(int i=0;i<10000;++i){charge.observe(true);g.update(castGameStep(true,false,.05f),{});}
  assert(charge.active&&!charge.released&&g.phase==Phase::Cast&&g.elapsed==0);
  charge.observe(false);assert(charge.released);charge.observe(true);assert(charge.released);
  charge.reset();assert(!charge.active&&!charge.released);
  advance(g,Phase::Wait);assert(g.phase==Phase::Wait);
  charge.begin();charge.observe(false);assert(charge.released); // quick tap before streaming/turn completes
  charge.reset();charge.observe(false);assert(!charge.active&&!charge.released); // cancelled release cannot cast
  int requests=0;
  requestCastClip([&](auto... args){auto a=std::make_tuple(args...);
   assert(!std::strcmp(std::get<1>(a),castSpinClip)&&std::get<4>(a)==1.f&&std::get<6>(a)&&std::get<8>(a)==-1.f);++requests;
  },42,castSpinClip);assert(requests==1);
  puts("PASS: unlimited hold gates flight, release is latched, quick tap/cancel and positive-rate looping spin ABI");
 }

 {
  FightFrameTransition transition;
  for(float time:{.02f,.1f,.3f,.5f,.52f})assert(transition.sample(time,.016f)<0);
  assert(transition.sample(.54f,0)<0);
  assert(transition.sample(.54f,.016f)==.5238f);
  assert(transition.sample(.9f,.016f)==.5238f);
  transition.reset();assert(transition.sample(.8f,.016f)<0);
  for(float time:{.9f,.01f,.3f,.52f})assert(transition.sample(time,.016f)<0);
  assert(transition.sample(.55f,.016f)==.5238f);
  transition.reset();assert(transition.sample(-1,.016f)<0);
  puts("PASS: natural phase crossing, exact user-confirmed .5238 hold, no early seek, pause and loop wrap");
 }

 {
  int requests=0;
  requestFightClip([&](auto... args){
   auto a=std::make_tuple(args...);static_assert(std::tuple_size_v<decltype(a)> == 9);
   assert(std::get<0>(a)==42&&!std::strcmp(std::get<1>(a),"nor_lso_pul_wlk_000"));
   static_assert(std::is_same_v<std::tuple_element_t<4,decltype(a)>,float>);
   assert(std::get<2>(a)==.65f);
   assert(std::get<4>(a)==1.f&&std::get<5>(a)==0&&std::get<6>(a)&&!std::get<7>(a)&&std::get<8>(a)==-1.f);
   ++requests;
  },42);
  assert(requests==1);
  FightPose pose;using C=FightPose::Command;auto bind=[](){return true;};
  pose.update(true,true,.05f,false,-1,bind);
  assert(pose.update(true,true,.05f,false,-1,bind)==C::Request);
  assert(pose.update(true,true,.05f,true,0,bind)==C::None);
  assert(pose.stage==FightPose::Stage::Starting);
  assert(pose.update(true,true,.05f,true,.02f,bind)==C::None);
  assert(pose.stage==FightPose::Stage::Holding);
  for(int i=0;i<2000;++i)assert(pose.update(true,true,.05f,true,0.35f,bind)==C::None);
  assert(pose.update(false,true,.05f,true,0.35f,bind)==C::Release);
  assert(pose.update(false,true,.05f,false,-1,bind)==C::None);
  puts("PASS: user-selected key-3 task ABI, advancement before frame hold, no task replay, cancellation");
 }

 {
  using B=AnimBinding;
  assert(classifyAnimBinding(true,false,true,0,false,123,123)==B::Base); // actual v0.1.31 log case
  assert(classifyAnimBinding(true,false,false,0,false,123,123)==B::Rejected); // cast still requires override
  assert(classifyAnimBinding(true,true,false,456,true,123,123)==B::Override);
  assert(classifyAnimBinding(false,false,true,0,false,123,123)==B::Rejected);
  assert(classifyAnimBinding(true,false,true,0,false,123,789)==B::Rejected);
  assert(classifyAnimBinding(true,false,true,0,false,0,0)==B::Rejected);
  assert(classifyAnimBinding(true,false,true,456,false,123,123)==B::Rejected);
  assert(classifyAnimBinding(true,false,true,0,true,123,123)==B::Rejected);
  assert(matchesBaseSession(123,123,0,false));
  assert(!matchesBaseSession(123,789,0,false));
  assert(!matchesBaseSession(123,123,456,false));
  assert(!matchesBaseSession(123,123,0,true));
  puts("PASS: native-base success without override; cast override requirement; base/override ownership changes");
 }

 {
  FightPose pose;using C=FightPose::Command;using S=FightPose::Stage;
  int binds=0;auto bind=[&](){++binds;return true;};
  for(int i=0;i<10;++i)assert(pose.update(false,true,.05f,false,-1,bind)==C::None);
  assert(binds==0); // Cast/Wait/Bite must never bind or request this pose.
  assert(pose.update(true,true,.05f,false,-1,bind)==C::None&&binds==1);
  assert(pose.update(true,true,.05f,false,-1,bind)==C::Request);
  assert(pose.update(true,true,.05f,true,.02f,bind)==C::None&&pose.stage==S::Starting);
  assert(pose.update(true,true,.05f,true,.04f,bind)==C::None&&pose.stage==S::Holding);
  // Long fights, including normalized loop wraps, must not replay the task.
  for(int i=0;i<2000;++i)assert(pose.update(true,true,.05f,true,float(i%20)/20,bind)==C::None);
  assert(binds==1&&pose.owned);
  assert(pose.update(false,true,.05f,false,-1,bind)==C::Release);
  assert(pose.stage==S::Idle&&!pose.owned);
  assert(pose.update(false,true,.05f,false,-1,bind)==C::None);
  pose.update(true,true,.05f,false,-1,bind);pose.update(true,true,.05f,false,-1,bind);
  int retries=0,releases=0;
  for(int i=0;i<50;++i){auto c=pose.update(true,true,.05f,false,-1,bind);retries+=c==C::Retry;releases+=c==C::Release;}
  assert(retries==1&&releases==1&&pose.stage==S::Failed);
  pose.reset();pose.update(true,true,0,false,-1,bind);pose.update(true,true,0,false,-1,bind);
  for(int i=0;i<100;++i)assert(pose.update(true,true,0,false,-1,bind)==C::None);
  // Playing but frozen is bounded, and is never restarted.
  retries=0;releases=0;
  for(int i=0;i<30;++i){auto c=pose.update(true,true,.05f,true,0,bind);retries+=c==C::Retry;releases+=c==C::Release;}
  assert(!retries&&releases==1);
  pose.reset();for(int i=0;i<50;++i)pose.update(true,false,.05f,false,-1,bind);
  assert(pose.stage==S::Failed&&!pose.owned);
  pose.reset();pose.update(true,true,.05f,false,-1,[](){return false;});assert(pose.stage==S::Failed&&!pose.owned);
  pose.reset();pose.update(true,true,.05f,false,-1,bind);pose.update(true,true,.05f,false,-1,bind);pose.update(true,true,.05f,true,.1f,bind);pose.update(true,true,.05f,true,.2f,bind);
  releases=0;for(int i=0;i<20;++i)releases+=pose.update(true,true,.05f,false,-1,bind)==C::Release;
  assert(releases==1&&pose.stage==S::Failed);
  puts("PASS: Fight-only pose lifecycle, single request through long loops, bounded startup/retry, interruption and release");
 }

 {
  CastControls controls;bool enabled=true;int disables=0,restores=0;
  auto read=[&](){return enabled;};
  auto write=[&](bool value){enabled=value;if(value)++restores;else ++disables;};
  assert(controls.acquire(read,write)&&controls.owned&&!enabled);
  controls.acquire(read,write);assert(disables==1); // no repeated toggles
  assert(controls.restore(write)&&enabled&&restores==1);
  assert(!controls.restore(write)&&restores==1); // cleanup idempotent
  enabled=false;assert(!controls.acquire(read,write)&&!controls.owned);
  assert(!controls.restore(write)&&!enabled); // preserve pre-existing disabled control
  enabled=true;controls.acquire(read,write);
  assert(controls.restore(write)&&enabled); // early cancellation, independent of actor validity
 }
 puts("PASS: scoped player-control restoration, cancellation, idempotence and pre-existing disabled state");
 {
  // Streaming may finish after Cast->Wait. No bind or clip request before readiness.
  CastPreparation prep;using Result=CastPreparation::Result;
  int bindings=0;auto bind=[&](){++bindings;return true;};
  Game loading;loading.toggle();loading.update(.01f,{true});
  for(int i=0;i<13;i++){
   assert(prep.update(loading.phase==Phase::Cast,true,false,.1f,bind)==Result::None);
   loading.update(.1f,{});
  }
  assert(loading.phase==Phase::Wait&&bindings==0);
  assert(prep.update(false,true,true,.01f,bind)==Result::None&&bindings==1);
  assert(prep.stage==CastPreparation::Stage::Binding);
  assert(prep.update(false,true,true,.016f,bind)==Result::Start&&bindings==1);
  for(int i=0;i<10;i++)assert(prep.update(false,true,true,.1f,bind)==Result::None);
  assert(bindings==1);
  prep.complete();prep.update(false,true,true,.1f,bind);
  assert(prep.stage==CastPreparation::Stage::Idle);
  // Cancellation while loading must not attach anything, including on late completion.
  prep.update(true,true,false,.1f,bind);
  prep.update(false,false,true,.1f,bind);
  assert(prep.update(false,true,true,.1f,bind)==Result::None&&bindings==1);
  // An existing override rejects binding once; held casting cannot retry every frame.
  assert(prep.update(true,true,true,0,[](){return false;})==Result::Rejected);
  for(int i=0;i<30;i++)assert(prep.update(true,true,true,.1f,bind)==Result::None);
  assert(bindings==1);
  prep.reset();int timeouts=0;
  for(int i=0;i<50;i++)if(prep.update(true,true,false,.1f,bind)==Result::Timeout)++timeouts;
  assert(timeouts==1&&bindings==1);
  prep.reset();prep.update(true,true,false,.1f,bind);
  for(int i=0;i<100;i++)assert(prep.update(true,true,false,0,bind)==Result::None);
  assert(prep.elapsed<.11f); // paused game time must not consume the streaming deadline
 }
 puts("PASS: animation-set streaming, Cast->Wait readiness, cancellation, binding rejection and bounded timeout");
 {
  // Exercise the same native submission used in plugin.cpp. Speed must reach slot 4
  // as a float; the layer is int, both flags bool, and the timer is float.
  float rate=0,timer=0;int calls=0;
  requestCastClip([&](int actor,const char* clip,float,float,auto speed,auto layer,auto loop,auto flag,auto seconds){
   static_assert(std::is_same_v<decltype(speed),float>);
   static_assert(std::is_same_v<decltype(layer),int>);
   static_assert(std::is_same_v<decltype(loop),bool>);
   static_assert(std::is_same_v<decltype(flag),bool>);
   static_assert(std::is_same_v<decltype(seconds),float>);
   assert(actor==42&&clip==castReleaseClip&&layer==0&&loop&&!flag);
   rate=speed;timer=seconds;++calls;
  },42,castReleaseClip);
  assert(calls==1&&rate>0&&timer<0);
  // Verified engine relation: clip-time increments are multiplied by this rate.
  // Reproduce the user's 0.1.23 samples, then feed progression at the submitted rate.
  CastClipProgress progress;
  for(int i=0;i<111;i++)assert(!progress.observe(true,0.f));
  assert(!progress.advanced);
  float clock=0;
  for(int i=0;i<30;i++){clock+=(1.f/60.f)*rate;progress.observe(true,clock);}
  assert(clock>.49f&&progress.advanced);
  progress.reset();assert(!progress.observe(false,-1));
  assert(!progress.observe(true,std::numeric_limits<float>::quiet_NaN()));
  assert(!progress.observe(true,0));assert(progress.observe(true,.016f));
  assert(!progress.observe(true,.032f)); // advancing logged once per request
 }
 puts("PASS: typed native playback request, positive clock rate, natural completion timer and frozen-log regression");
 using Cmd=CastAnimCommand;
 {
  CastAnimation plan;
  assert(plan.update(false,true,0,false,-1)==Cmd::None);
  assert(plan.update(true,true,0,false,-1)==Cmd::Request);
  assert(plan.update(true,true,.1f,false,-1)==Cmd::None);
  assert(plan.update(true,true,.1f,false,-1)==Cmd::None);
  assert(plan.update(true,true,.05f,false,-1)==Cmd::Retry);
  assert(plan.update(true,true,.016f,true,0)==Cmd::None);
  assert(plan.update(true,true,.016f,true,.015f)==Cmd::Launch);
  // Native looping crosses the end of the short clip without ending the hold.
  assert(plan.update(true,true,.1f,true,.98f)==Cmd::None);
  assert(plan.update(true,true,.1f,true,.02f)==Cmd::None);
  for(int i=0;i<25;i++)assert(plan.update(true,true,.1f,true,.5f)==Cmd::None);
  assert(plan.stage==CastAnimation::Stage::Holding);
  assert(plan.update(false,true,.01f,true,.8f)==Cmd::EndHold&&plan.end==CastEnd::Landed);
  for(int i=0;i<2;i++)assert(plan.update(false,true,.1f,false,-1)==Cmd::None);
  assert(plan.update(false,true,.05f,false,-1)==Cmd::Stop);
 }
 {
  CastAnimation absent;assert(absent.update(true,true,0,false,-1)==Cmd::Request);
  int retries=0,ends=0,stops=0;
  for(int i=0;i<50;i++){
   auto c=absent.update(true,true,.1f,false,-1);
   if(c==Cmd::Retry)++retries;
   if(c==Cmd::EndHold)++ends;
   if(c==Cmd::Stop)++stops;
  }
  assert(retries==1&&ends==1&&stops==1&&absent.end==CastEnd::Missing);
  CastAnimation frozen;frozen.update(true,true,0,false,-1);retries=0;
  for(int i=0;i<20;i++)if(frozen.update(true,true,.1f,true,0)==Cmd::Retry)++retries;
  assert(retries==0&&frozen.end==CastEnd::Missing); // never restart a matched active clip
  CastAnimation interrupted;interrupted.update(true,true,0,false,-1);
  assert(interrupted.update(true,true,.016f,true,.02f)==Cmd::Launch);
  assert(interrupted.update(true,true,.1f,false,-1)==Cmd::EndHold&&interrupted.end==CastEnd::Interrupted);
  CastAnimation watchdog;watchdog.update(true,true,0,false,-1);watchdog.update(true,true,.016f,true,.02f);
  for(int i=0;i<70;i++)watchdog.update(true,true,.1f,true,.5f);
  assert(watchdog.end==CastEnd::Watchdog);
  for(auto stage:{CastAnimation::Stage::AwaitStart,CastAnimation::Stage::Holding,CastAnimation::Stage::BlendOut}){
   CastAnimation cancel;cancel.stage=stage;
   assert(cancel.update(false,false,.01f,false,-1)==Cmd::Stop&&cancel.end==CastEnd::Cancelled);
  }
 }
 puts("PASS: confirmed startup, one missing-only retry, loop wrap, hold until landing, cancellation and watchdog");
 for(float distance:{3.f,9.f,20.f}){
  Game synced;synced.castSeconds=castFlightSeconds(distance,true);
  synced.toggle();synced.update(.01f,{true});
  CastAnimation plan;bool released=false;float now=0,launched=-1,landed=-1,ended=-1,finished=-1;
  for(int frame=0;frame<500;frame++){
   constexpr float step=.016f;now+=step;
   synced.update(castGameStep(synced.phase==Phase::Cast,released,step),{});
   if(!released)assert(synced.elapsed==0&&synced.phase==Phase::Cast);
   // Simulate first request missing, bounded retry, then a looping clip starting.
   bool playing=now>.35f;
   float time=playing?std::fmod(now-.35f,1.066f)/1.066f:-1.f;
   auto c=plan.update(synced.phase==Phase::Cast,true,step,playing,time);
   if(c==Cmd::Launch){assert(!released);released=true;launched=now;synced.elapsed=0;}
   if(synced.phase==Phase::Wait&&landed<0)landed=now;
   if(c==Cmd::EndHold)ended=now;
   if(c==Cmd::Stop){finished=now;break;}
  }
  assert(launched>.35f&&launched<.4f);
  assert(landed-launched>=synced.castSeconds-.001f&&landed-launched<synced.castSeconds+.04f);
  assert(ended==landed&&finished>ended&&finished-ended<.3f);
 }
 assert(std::abs(castFlightSeconds(9,true)-1.8f)<.001f);
 assert(castFlightSeconds(20,false)==1.1f);
 puts("PASS: 3/9/20-metre flight timing, flight held until native startup, hands held through landing, immediate cancellation");
 {
  // John starts facing any quadrant; the saved camera ray is the target, not
  // a moving view sampled again during the turn. Simulate native readback.
  for(Point view:{Point{0,0,1},Point{1,.8f,0},Point{0,0,-1},Point{-1,-.8f,0},Point{3,5,4}}){
   for(float initial:{0.f,90.f,179.f,-179.f,270.f,359.f}){
    CastTurn turn;assert(turn.begin(view));float heading=initial;
    float fixedTarget=turn.target;int turningFrames=0;
    Game gate;gate.toggle();gate.update(.01f,{true});
    CastAnimation animation;bool requested=false;
    for(int frame=0;frame<100;frame++){
     constexpr float dt=.016f;float next=heading;
     auto state=turn.update(heading,dt,next);
     assert(turn.target==fixedTarget);
     if(state==CastTurn::Result::Ready){
      assert(std::abs(std::remainder(heading-fixedTarget,360.f))<=.5f);
      // Regression for v0.1.28: native-heading agreement alone allowed John to
      // face the camera. Verify the visible front against the saved throw ray.
      float yaw=heading*.01745329252f;
      Point visibleFront{-std::sin(yaw),0,-std::cos(yaw)},desired{};
      assert(horizontalDirection(view,desired));
      assert(visibleFront.x*desired.x+visibleFront.z*desired.z>.9999f);
      assert(animation.update(true,true,dt,false,-1)==CastAnimCommand::Request);
      requested=true;break;
     }
     assert(state==CastTurn::Result::Turning);
     assert(std::abs(std::remainder(next-heading,360.f))<=360.f*dt+.001f);
     gate.update(castGameStep(true,false,dt),{});
     assert(gate.elapsed==0&&gate.phase==Phase::Cast);
     heading=next;++turningFrames;
    }
    assert(requested&&turningFrames<=33); // at most half a second for a 180-degree turn
   }
  }
  CastTurn wrap;assert(wrap.begin(Point{std::sin(1.f*.01745329252f),0,std::cos(1.f*.01745329252f)}));
  float next=0;assert(wrap.update(179,.001f,next)==CastTurn::Result::Turning);
  assert(next>179); // shortest route is +2 degrees across the seam, not -358
  CastTurn paused;paused.begin(Point{1,0,0});
  for(int i=0;i<100;i++){assert(paused.update(0,0,next)==CastTurn::Result::Turning);assert(next==0);}
  assert(paused.elapsed==0);
  CastTurn blocked;blocked.begin(Point{1,0,0});
  for(int i=0;i<12;i++)assert(blocked.update(0,.1f,next)==CastTurn::Result::Turning);
  assert(blocked.update(0,.1f,next)==CastTurn::Result::Failed);
  CastTurn cancelled;cancelled.begin(Point{-1,0,0});cancelled.reset();
  assert(cancelled.update(0,.1f,next)==CastTurn::Result::Ready&&!cancelled.pending);
  CastTurn invalid;assert(!invalid.begin(Point{0,1,0}));
  invalid.begin(Point{1,0,0});
  assert(invalid.update(std::numeric_limits<float>::quiet_NaN(),.01f,next)==CastTurn::Result::Failed);
 }
 puts("PASS: visible actor front aligned with throw ray, all quadrants, shortest turn, animation gate and cancellation");
 for(const char* name:{"wrist_r","WRIST_R","Hand_Right","SKEL_R_Hand","skel_r_hand","R_Hand","hand_r","Bip01 R Hand"})assert(rightHandBoneName(name));
 for(const char* name:{"wrist_l","wristroll_r","wrist_r_Attachment","Hand_Left","SKEL_L_Hand","R_Hand_Index1","R_Hand_Thumb","Lower_Arm_Right",""})assert(!rightHandBoneName(name));
 puts("PASS: right-hand bone matching; left hand, fingers and forearm rejected");
 // View rays keep their horizontal bearing at every pitch and in every quadrant.
 for(Point view:{Point{0,-.8f,1},Point{1,.4f,0},Point{0,1,-1},Point{-1,-1,0},Point{3,-9,4},Point{-3,9,-4}}){
  Point direction{};assert(horizontalDirection(view,direction));
  assert(direction.y==0&&std::abs(std::hypot(direction.x,direction.z)-1)<.00001f);
  assert(direction.x*view.x+direction.z*view.z>0);
  assert(std::abs(direction.x*view.z-direction.z*view.x)<.00001f);
  Point target{10+direction.x*9,3,20+direction.z*9};
  assert(std::abs(std::hypot(target.x-10,target.z-20)-9)<.00001f);
 }
 Point invalidOut{7,8,9};
 assert(!horizontalDirection(Point{0,1,0},invalidOut));
 assert(!horizontalDirection(Point{0,0,0},invalidOut));
 assert(!horizontalDirection(Point{std::numeric_limits<float>::quiet_NaN(),0,1},invalidOut));
 assert(!horizontalDirection(Point{1,std::numeric_limits<float>::infinity(),0},invalidOut));
 assert(invalidOut.x==7&&invalidOut.y==8&&invalidOut.z==9);
 puts("PASS: camera bearing in six directions and pitches; cast distance; invalid/vertical view rejection");
 Game g;hook(g);
 for(int i=0;i<2000&&g.phase==Phase::Fight;i++)g.update(.02f,{false,g.tension<.6f,g.tension>=.6f});
 assert(g.phase==Phase::Caught&&g.catches==1);
 Game missed;missed.toggle();missed.update(.01f,{true});advance(missed,Phase::Bite);advance(missed,Phase::Lost);assert(!missed.catches);
 Game broken;hook(broken);for(int i=0;i<1000&&broken.phase==Phase::Fight;i++)broken.update(.02f,{false,true,false});assert(broken.phase==Phase::Lost&&!broken.catches);
 Game slack;hook(slack);for(int i=0;i<1000&&slack.phase==Phase::Fight;i++)slack.update(.02f,{false,false,true});assert(slack.phase==Phase::Lost);
 Game cancel;hook(cancel);cancel.toggle();assert(cancel.phase==Phase::Off);
 Game paused;hook(paused);float t=paused.tension;paused.update(0,{false,true});assert(paused.tension==t);assert(paused.progress==0);
 for(unsigned seed=1;seed<=500;seed++){
  Game run;run.seed=seed;hook(run);
  for(int i=0;i<3000&&run.phase==Phase::Fight;i++)run.update(.016f,{false,run.tension<.6f,run.tension>=.6f});
  assert(run.phase==Phase::Caught&&run.catches==1);
  run.update(.1f,{true});assert(run.phase==Phase::Ready&&run.catches==1);
 }
 // Reproduce IDs reported by the user's game: both must reach streaming.
 assert(validAsset(872270493));assert(validAsset(-2085051245));assert(validAsset(-925462083));
 assert(!validAsset(0)&&!validAsset(-1));
 Button b;assert(!b.sample(false));assert(b.sample(true));assert(!b.sample(true));assert(!b.sample(false));assert(b.sample(true));
 Game early;early.toggle();early.update(.01f,{true});advance(early,Phase::Wait);
 early.update(.01f,{true});assert(early.phase==Phase::Wait);
 advance(early,Phase::Bite);
 // A reaction slower than the old 2.2-second window must now hook successfully.
 for(int i=0;i<35;i++)early.update(.1f,{});
 assert(early.phase==Phase::Bite);early.update(.01f,{true});assert(early.phase==Phase::Fight);
 Point hand{822,77,1380},surface{831,75,1380};
 auto first=castPath(hand,surface,0),last=castPath(hand,surface,1),mid=castPath(hand,surface,.5f);
 assert(std::abs(first.y-hand.y)<.0001f&&std::abs(last.y-surface.y)<.0001f);
 assert(last.x==surface.x&&last.z==surface.z&&mid.y>76);
 for(int i=0;i<=100;i++){
  auto p=castPath(hand,surface,i/100.f);assert(finite(p));assert(p.x>=hand.x&&p.x<=surface.x);
 }
 assert(waterHitValid(surface,surface,80,30));
 assert(!waterHitValid(surface,Point{0,0,0},80,30));
 assert(!waterHitValid(surface,Point{surface.x,90,surface.z},80,30));
 assert(!waterHitValid(surface,Point{surface.x+1,75,surface.z},80,30));
 // All slopes: exact one-pixel coverage, endpoints and no gaps between adjacent pixels.
 for(int endX=-10;endX<=10;endX++)for(int endY=-10;endY<=10;endY++){
  std::set<std::pair<int,int>> pixels;
  solidLine(0,0,endX,endY,false,[&](int x,int y,int w,int h){
   assert(w==1||h==1);
   for(int ix=x;ix<x+w;ix++)for(int iy=y;iy<y+h;iy++)assert(pixels.insert({ix,iy}).second);
  });
  int length=std::max(std::abs(endX),std::abs(endY));
  assert(int(pixels.size())==length+1&&pixels.count({0,0})&&pixels.count({endX,endY}));
  for(auto pixel:pixels){
   assert(std::abs(endX*pixel.second-endY*pixel.first)<=length*.5f+.01f);
   if(length){int neighbors=0;for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)if((x||y)&&pixels.count({pixel.first+x,pixel.second+y}))++neighbors;assert(neighbors>0);}
  }
 }
 puts("PASS: solid one-pixel line at 441 slopes; cast endpoints, arc, invalid water hits; negative resource hashes, key edges, early action, 3.5-second hook; 500 seeded catches; catch, missed bite, broken line, slack line, cancel, zero-delta pause");
}
