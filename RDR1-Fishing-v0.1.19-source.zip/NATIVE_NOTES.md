# Native-call evidence (RDR.exe supplied by user)

Executable SHA256: 22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e.
Static analysis only; no claim of runtime validation for the new calls.

- `SET_OBJECT_POSITION`, hash C5D796F8: handler VA 0x14022F920 reads the object
  handle at argument slot 0, packed XY at slot 1, and Z at slot 2. The SDK signature
  and our existing packing agree; motion failure must be diagnosed through the
  boolean return and `GET_OBJECT_POSITION`, rather than assuming a packing defect.
- `SET_OBJECT_ORIENTATION`, hash C8A4EE74: handler VA 0x1402308D0 reads the same
  packed vector pattern and applies a degrees-to-radians conversion before dispatch.
- `FIND_WATER_INTERSECTION`, hash 4F193BE4: registration points to VA 0x1402965D0.
  It reads two packed vectors from argument slots 0/1 and 2/3, then vector output
  pointers from slots 4 and 5. It invokes the intersection routine at 0x140295DC0
  with the water collision mask 0x400000 and writes a boolean result. The adapter
  supplies two initialized, aligned vector outputs and two trailing zero arguments
  for the SDK's placeholder arity. Output position is validated before use.
- `WORLD_TO_SCREEN`, hash BAA72911: supplied by RedHook v0.8, not base game.
  Handler VA 0x180024780 in supplied RedHook.dll reads a position pointer and two
  float output pointers. It returns false for points outside the view; successful
  outputs are normalized screen coordinates. Used only for visual markers.
- `GET_OBJECT_NAMED_BONE_POSITION`, hash 30516389, and `GET_OBJECT_FROM_ACTOR`,
  hash 4A2063EC: typed signatures from the supplied SDK. Bone names are probed
  and validated by proximity; a body-relative fallback is used when unavailable.

No unknown animator or lasso task parameters were guessed in this release.
Player animation and WAS/WAT playback remain unfinished.

## v0.1.13 attachment and cast direction

- GET_CAMERA_CHANNEL_DIRECTION (6ED00237), handler 0x1403AAEF0:
  output vector pointer at slot 0, channel at slot 1; channel zero supported.
  Returns negated camera backward basis, the actual forward view direction.
- GET_HEADING uses atan2(actor +Z basis X, actor +Z basis Z) at 0x140AD4AB0.
  Old -sin(heading) reflected X incorrectly. The cast now uses the view vector
  directly, and yaw reconstruction uses atan2(X,Z).
- ATTACH_OBJECTS (E1421B42), handler 0x140230E80 and helper 0x1402DA4D0:
  child object, parent object, parent bone name, offset XY, offset Z,
  rotation XY (degrees), rotation Z, integer flags. 8 slots, not SDK's 10 ints.
  Parent bone resolved by helper 0x1402F2400. Child is object whose attachment
  field gets assigned at 0x1402DA8AA.
- SET_ATTACHMENT_IGNORE_ROTATION (A870B28E) writes attachment byte +0x62.
  Update 0x1402DAA5C copies existing child basis and applies only translation
  when this flag is set. This retains procedural rod rotation while binding
  the pivot to the animated hand. No finger/arm animation is claimed.
- Cleanup removes only this plugin's saved attachment before deleting the rod.

Static disassembly evidence only; in-game validation remains necessary.

## v0.1.14 live actor bone discovery

The user's 0.1.13 log contains repeated Hand bone not found and no created rod
attachment. Do not interpret that run as successful attachment validation.

GET_OBJECT_FROM_ACTOR at 0x14022BA90 is identity, returning the actor handle.
GET_OBJECT_NAMED_BONE_POSITION at 0x140230A90 resolves the handle through
RVA 0x2C36778 (16-byte records with generation at +8) and calls the object's
vtable +0x100 getter with true. Returned pose +8 is the skeleton descriptor.
Helper 0x1402D9D10 obtains the bone count at descriptor +0x30 (uint16),
and compares C-string names at the first pointer in each 0x110-byte descriptor
record through descriptor +0. This exact read-only path is used to enumerate
actual actor bone names instead of assuming animation semantic labels match.

Private offsets are gated by the supplied executable's PE timestamp 6711591D,
SizeOfImage 5A5DD600, AMD64 PE32+, and two handler fingerprints. Pointer reads
use ReadProcessMemory; counts and string lengths are bounded. The one pose
getter call has the same ABI and argument as the existing native. There are no
writes or patches to game memory. This is static ABI evidence, not a game run.

## v0.1.15 wrist_r and camera independence

The user's v0.1.14 log confirms successful live skeleton enumeration, including
wrist_r, wristroll_r and wrist_r_Attachment. Our name filter rejected wrist_r.
Use wrist_r first via the existing named-bone native and native attachment.
The classifier accepts wrist_r but rejects wristroll_r and wrist_r_Attachment.
Rod yaw now uses actor heading, not saved camera/cast direction; idle props and
fallback hand/tip positions use actor coordinates. Camera direction is sampled
only for enabling/actual cast targeting and never drives held rod yaw.
The native attachment retains procedural world rotation while following wrist
translation. Finger grip and bone-relative rod rotation are not implemented.

## v0.1.16 non-colliding held rod

User log: wrist_r resolves, attachment valid=1, Rod hand check coordinates match.
Fishing then ends with Stopped: player moved. User observes rod pushes John.

SET_OBJECT_COLLIDE_WITH_WORLD (601FC9F4), handler 0x1402331F0, reads object
slot 0 and boolean slot 1. False sets bit 0x2 in prop flags +0x1C.
SET_OBJECT_COLLIDE_WITH_MOVABLES (05D69EA6), handler 0x140233230, same ABI;
false sets bit 0x4. Both resolve the prop through helper 0x1402201D0.
Set both false immediately after spawning the rod, before any ScriptWait,
and reapply after attachment initialization. Scope is the rod object only.
Do not disable actor collision or remove the existing movement cancellation.
No in-game collision-free result is claimed until user validation.

## v0.1.17 fish orientation regression

User confirms v0.1.16 rod is attached to hand without collision, but fish is
again tail-first. Reverse only fish yaw by 180 degrees: cast bearing -90
instead of +90. Keep wrist_r, rod collision flags and camera casting untouched.
Do not treat Linux tests as in-game validation of this direction.

## v0.1.18 cast animation evidence and limits

User confirmed v0.1.17 fish retrieval/orientation works; preserve that baseline.
Supplied act.rpf SHA256:
e4e9f8f7cf4f4eafa79271476d47572c2fa9e30bcf566f4846b23d713670c955.
RPF6: 1035 entries, encrypted TOC; parsed per Magic-RDR commit
bc2b939b5f53de81450391fe834d2e35f97a982a. default_character.wat is resource
entry 13 at archive offset 0x22A000, compressed entry size 567576 bytes.
The resource's Zstandard payload decodes to 3186688 bytes, SHA256:
1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1.
ASCII clips nor_lso_stn_mid_trw_pre occur at 0x23F690, 0x23FB58;
nor_lso_stn_mid_trw_mid at 0x23DEE8, 0x23DF78 and other references.
Normal standing clips selected; horse and crouch variants deliberately omitted.
No game archive, animation binary or encryption material is shipped in the mod.

TASK_PLAY_ANIM (5AB552C6), handler 0x140C1AB30:
slot0 actor, slot1 const char* clip (<64 bytes); slots2/3/4 float;
slot5 int (MOV, not MOVSS, at 0x140C1ABEA); slots6/7 boolean;
slot8 float (MOVSS 0x140C1ABDD). SDK misdeclares slots5/8.
Task fields +4C/+50/+54/+58/+5C/+5D/+48 flow through 0x140B3B450
to 0x140CDE6F0. The clip lookup at 0x140CE7AF0 uses the actor's animation
component and actual clip name. Use existing loaded player animation data;
do not replace the player's default action tree or grant/equip a real lasso.
IS_ACTOR_ANIM_PLAYING (1ADE21EB) queries the selected clip by actor/name.
TASK_CLEAR (16876A25) releases the short requested task at Cast exit or cleanup,
including when a missing clip leaves the request pending.

Initial scalar values are .1, .1, 0, integer layer 0, false, false, float 1.
Scalar types/data flow are verified; visual meanings/tuning and playback are
not established by static inspection alone. Stage at 0 and .35s, cleanup on
Cast exit (1.1s) / F6 / player unavailable. Do not claim animation works from
request logs; look for Cast animation PLAYING. Tests cover one-shot staging,
cancellation, reset and real Game transitions; they do not execute RDR natives.

## v0.1.19 native action-tree cast route

User's v0.1.18 log: two cast attempts, TASK_PLAY_ANIM requests issued,
no PLAYING confirmation for either clip. This proves non-playback, not why the
queue/clip path failed. Replace that route with explicit existing action nodes.

Recovered root from WAT +8 -> 0xA7070; node parent +4, children pointer +8,
child count uint16 +0xC, local name JOAAT hash +0x20. Traverse actual links:
default_character_Main BD701184 (root 0xA7070)
Gunplay 18E67533 (0xB4340)
THROWING 38D89C16 (0x11AEC0)
Lasso 2A083060 (0xA91C0)
LassoNor 29483E1E (0xA92C0)
ThrowStand 46160C03 (0xA9340)
ThrowMid 044EFD54 (0xA9540).
LassoNor selects normal standing, rather than LassoCrouch (6D8A9E41),
LassoAim (7A7EA5CC), Gunplay_AI (F6AD55F0), horse or cover branches.
Animation expression 0x19E5A0 references nor_lso_stn_mid_trw_pre and attaches
to ThrowStand; expression 0x92B48 references nor_lso_stn_mid_trw_mid and
attaches to ThrowMid. Parent-child hierarchy is verified from the shipped
source header constants by tools/verify_cast_action_tree.py on decompressed WAT.

SET_ACTION_NODE_FOR_ACTOR 5A795F3A -> handler 0x140CE0CE0 -> helper
0x140CDFA20. Actor and string, returns boolean. Helper prepends Global\%s,
so pass default_character_Main\Gunplay\THROWING\Lasso\LassoNor\ThrowStand
WITHOUT an additional Global prefix. Parser 0x14058FA70 accepts both slash
and backslash (delimiter bytes at VA 0x141CBF0E0 are "\\/\0").
IS_ACTOR_PLAYING_NODE_IN_TREE 4E0300E2 -> helper 0x140CDF940 looks up same
path and walks active node's parent links. This confirms activation separately
from IS_ACTOR_ANIM_PLAYING clip playback. RESET_ACTIONTREE_FOR_ACTOR
07EC142B -> 0x140CE0D70 restores actor default processing. Call only if our
node override was accepted, on Cast exit or cleanup. No TASK_CLEAR is used.

Timing remains initial integration tuning. Direct action nodes have not been
run in the game here; neither accepted nor Linux tests establish visible motion.
