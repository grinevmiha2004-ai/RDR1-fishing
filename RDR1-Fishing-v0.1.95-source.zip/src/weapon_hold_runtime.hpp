#pragma once
#include "fish_scale_runtime.hpp"
#include "weapon_hold.hpp"
namespace weapons {
inline bool flags(int actor,uint8_t& value){
 const auto base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
 static int profile=-1;if(profile<0)profile=fishscale::supported(base)?1:0;
 if(!profile)return false;
 uintptr_t table=0,wrapper=0,ped=0,controller=0;int entity=0;uint16_t generation=0;
 if(!rig::read(base+0x2c36778,table)||!table)return false;
 const auto lookup=[&](int handle,uintptr_t& pointer){
  uintptr_t entry=table+uintptr_t(uint32_t(handle)&0xffff)*16;
  return handle!=-1&&rig::read(entry+8,generation)&&generation==uint16_t(uint32_t(handle)>>16)&&
         rig::read(entry,pointer)&&pointer;
 };
 return lookup(actor,wrapper)&&rig::read(wrapper+0xb0,entity)&&
        rig::read(base+0x2c36768,table)&&table&&lookup(entity,ped)&&
        rig::read(ped+0x70,controller)&&controller&&rig::read(controller+0x48c,value);
}
inline void start(int actor){rh::invoke<0x7957CA4F,int>(actor,1,0);}
inline void end(int actor){rh::invoke<0x231E7034,int>(actor);}
}
