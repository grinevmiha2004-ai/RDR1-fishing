#pragma once
#include <cstdint>
namespace fishing {
// Force-holster is a pair of bits, not a counter. Do not clear an existing lock.
struct WeaponHold {
 int actor=0;bool owned=false;
 template<class End> void release(End end){
  if(owned&&actor)end(actor);
  actor=0;owned=false;
 }
 template<class Read,class Start,class End> bool update(int current,Read read,Start start,End end){
  if(actor!=current)release(end);
  if(!current)return false;
  actor=current;uint8_t flags=0;
  if(!read(current,flags))return false;
  if(flags&0x20)return true;
  if(!owned&&(flags&0x40))return false; // Preserve somebody else's force mode.
  start(current);owned=true;
  return read(current,flags)&&(flags&0x20);
 }
};
}
