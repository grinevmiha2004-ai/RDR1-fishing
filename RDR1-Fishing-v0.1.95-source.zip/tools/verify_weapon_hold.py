"""Static verification of force-holster native flags/argument dispatch in RDR.exe.
No runtime game validation. Usage: python3 tools/verify_weapon_hold.py RDR.exe
"""
from pathlib import Path
import struct,sys
b=Path(sys.argv[1]).read_bytes();nt=struct.unpack_from('<I',b,0x3c)[0]
n=struct.unpack_from('<H',b,nt+6)[0];opt=struct.unpack_from('<H',b,nt+20)[0]
def at(rva,size):
 for i in range(n):
  _,start,length,raw=struct.unpack_from('<4I',b,nt+24+opt+i*40+8)
  if start<=rva and rva+size<=start+length:return b[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
assert at(0xb06d10,3)==bytes.fromhex('488bd1')
assert 0xb06d1a+struct.unpack('<i',at(0xb06d16,4))[0]==0xb067b0
assert 0xb06d2a+struct.unpack('<i',at(0xb06d26,4))[0]==0xb068a0
start=at(0xb067b0,227);end=at(0xb068a0,27)
assert bytes.fromhex('83ca20') in start or bytes.fromhex('80ca20') in start
assert bytes.fromhex('88938c040000') in start
assert bytes.fromhex('80a08c0400009f') in end
assert 0x284c50+struct.unpack('<i',at(0x284c4c,4))[0]==0x2c36778
assert 0x284c7e+struct.unpack('<i',at(0x284c7a,4))[0]==0x2c36768
print('PASS: force-holster start/end callbacks and flags; distinct actor/entity handle tables')
