#pragma once
#include <cstddef>
namespace fishing {
// Exact spellings from user-supplied RDR1 vfx.rpf, vfx/rdr2_core.fxlist.
// 'rdr2_core' is this RDR1 asset's original name, not an RDR2 effect list.
inline constexpr const char* splashEffects[]={
 "ped_water_thrash", "ped_water_wade", "ped_water_entry", "bullet_water",
 "amb_splash", "amb_water_splash", "amb_water_rocksplash",
 "amb_water_rocksplash_2", "anim_water_toss", "wagon_water_wade"
};
struct SplashTest {
 int selected=0;
 bool automatic=true,wasPulling=false;
 float cooldown=0;
 void select(int index){if(index>=0&&index<10)selected=index;}
 bool update(bool fighting,bool pulling,float dt){
  cooldown=dt>0?(cooldown>dt?cooldown-dt:0):cooldown;
  bool edge=fighting&&pulling&&!wasPulling;
  wasPulling=fighting&&pulling;
  return dt>0&&automatic&&edge&&cooldown<=0;
 }
 void manual(){cooldown=3.5f;}
 void reset(){wasPulling=false;cooldown=0;}
};
}
