#pragma once
#include "visuals.hpp"
namespace fishing {
// GET_HEADING and SET_ACTOR_HEADING both use degrees; +Z=0, +X=90.
struct CastTurn {
 enum class Result {Ready,Turning,Failed};
 bool pending=false;
 float target=0,elapsed=0;
 bool begin(Point direction){
  Point flat;
  reset();if(!horizontalDirection(direction,flat))return false;
  target=std::atan2(flat.x,flat.z)*57.295779513f;pending=true;return true;
 }
 Result update(float current,float dt,float& next){
  next=current;
  if(!pending)return Result::Ready;
  if(!std::isfinite(current)||!std::isfinite(dt)){reset();return Result::Failed;}
  float delta=std::remainder(target-current,360.f);
  // Read back alignment on a following frame before starting the animation.
  if(std::abs(delta)<=.5f){pending=false;return Result::Ready;}
  float step=std::clamp(dt,0.f,.1f);elapsed+=step;
  if(elapsed>1.25f){reset();return Result::Failed;}
  next=std::remainder(current+std::clamp(delta,-360.f*step,360.f*step),360.f);
  return Result::Turning;
 }
 void reset(){pending=false;target=0;elapsed=0;}
};
}
