#pragma once
namespace fishing {
// Indices refer to the user-confirmed v0.1.83 two-page keyboard layout.
struct ItemSequence {
 enum class Kind {None,Equip,Stow,Keep,Recover};
 Kind kind=Kind::None;int clips[2]{},count=0,step=0;
 bool event=false;
 bool active()const{return kind!=Kind::None;}
 void reset(){*this={};}
 void begin(Kind next,float weight=0){
  reset();kind=next;count=1;
  if(next==Kind::Equip){clips[0]=19;clips[1]=13;count=2;}
  else if(next==Kind::Stow)clips[0]=8;
  else if(next==Kind::Keep)clips[0]=weight<1?2:weight<=5?3:5;
  else if(next==Kind::Recover)clips[0]=19;
 }
 int index()const{return clips[step];}
 bool next(){if(step+1<count){++step;return true;}return false;}
 bool eventDue(float phase){
  if(event||phase<0||phase>1)return false;
  bool due=kind==Kind::Equip?(step==1&&phase>=.45f):phase>=.65f;
  if(due)event=true;
  return due;
 }
};
}
