#pragma once
#include <cstddef>
#include <cstdint>
namespace fishing {
// Input layout read by native49053A94/E33910: gain is relative dB,
// not master/session/speaker volume. All other fields preserve default options.
struct ReelMenuParams {
 float gainDb=0;
 uint16_t pitch=0,padding=0;
 uint32_t option8=0,optionC=0,option10=0,option14=0;
 uint8_t option18=0;uint8_t tail[3]{};
};
static_assert(sizeof(ReelMenuParams)==28&&offsetof(ReelMenuParams,option18)==24);
}
