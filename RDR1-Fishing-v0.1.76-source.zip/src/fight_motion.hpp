#pragma once
#include "visuals.hpp"
namespace fishing {
struct FightMotion {
 float blend=0,rodPitch=0,rodRoll=0,fishRoll=0,side=0,vertical=0;
 void reset(){*this={};}
 void update(bool fighting,bool pulling,float dt,float time){
  if(!fighting){reset();return;}
  if(!std::isfinite(dt)||dt<=0||!std::isfinite(time))return;
  float step=std::clamp(dt,0.f,.1f)/(pulling?.18f:.28f);
  blend=std::clamp(blend+(pulling?step:-step),0.f,1.f);
  rodPitch=blend*(6.f*std::sin(time*8.f)+2.f*std::sin(time*17.f));
  rodRoll=blend*6.f*std::sin(time*9.f);
  fishRoll=10.f*std::sin(time*10.f)+blend*18.f*std::sin(time*17.f);
  side=blend*(.10f*std::sin(time*12.f)+.04f*std::sin(time*23.f));
  vertical=blend*.08f*std::sin(time*15.f);
 }
};
}
