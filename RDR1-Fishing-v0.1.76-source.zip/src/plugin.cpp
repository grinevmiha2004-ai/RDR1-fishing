#include "redhook.hpp"
#include "reel_audio.hpp"
#include "reel_audio_runtime.hpp"
#include "reel_menu_audio.hpp"
#include "cast_sound.hpp"
#include "water_audio.hpp"
#include "water_audio_runtime.hpp"
#include "reel_audio_gate.hpp"
#include "fishing.hpp"
#include "visuals.hpp"
#include "line_raster.hpp"
#include "hand_bone.hpp"
#include "rig_names.hpp"
#include "fish_scale_runtime.hpp"
#include "fish_hang.hpp"
#include "fight_motion.hpp"
#include "cast_animation.hpp"
#include "cast_controls.hpp"
#include "cast_preparation.hpp"
#include "cast_animset.hpp"
#include "cast_playback.hpp"
#include "cast_turn.hpp"
#include "cast_charge.hpp"
#include "tackle_motion.hpp"
#include "rod_cone.hpp"
#include "rod_grip.hpp"
#include "tackle_camera.hpp"
#include "spin_additive.hpp"
#include "fight_pose.hpp"
#include "animset_binding.hpp"
#include <cstdio>
#include <cmath>
#include <string>
#include <cstdarg>

static HMODULE module;
static std::string iniPath,logPath;
static fishing::Game game;
static unsigned savedCatches;
static int toggleKey=VK_F6,actionKey='E',reelKey='R',easeKey='Q';
static fishing::Button toggleButton,actionButton;
static std::string toggleName="F6",actionName="E",reelName="R",easeName="Q";
static const char* stateName(fishing::Phase p){
 static const char* names[]={"Off","Ready","Cast","Wait","Bite","Fight","Caught","Lost"};return names[int(p)];
}
static std::string keyName(int key){
 char name[80]{};LONG scan=LONG(MapVirtualKeyA(key,MAPVK_VK_TO_VSC)<<16);
 if(GetKeyNameTextA(scan,name,sizeof(name)))return name;
 return "key "+std::to_string(key);
}
static int readKey(const char* name,int fallback){
 int key=int(GetPrivateProfileIntA("Keys",name,fallback,iniPath.c_str()));
 // F8 and F9 are reserved by the user's installed mods.
 return key>0&&key<256&&key!=VK_F8&&key!=VK_F9?key:fallback;
}
static bool visuals=true;
static bool hudEnabled=true;
static float hudTextHeight=.018f;
static float waterOffset=-.65f,castDistance=9;
static rh::Vec origin,forward,waterTarget,bobberPosition,lineTip,hookPosition;
static fishing::TackleMotion tackleMotion;
static fishing::RodCone rodCone;
static fishing::RodGripPose rodGripPose;
static fishing::TackleCamera tackleCamera;
static bool autoWater=true,requireWater=true,showLine=true;
static float noticeTime=0,visualLogTime=0;
static const char* notice="";
static const char* handBone=nullptr;
static std::string rigHandBone;
static bool rigNamesLogged=false;
static bool hasWaterTarget=false;
static int rodAttachment=0;
static float rodAttachRetry=0;
static fishing::CastAnimation castAnimation;
static bool castAnimationEnabled=true,castClipConfirmed=false;
static int castAnimationActor=0;
static fishing::CastPreparation castPreparation;
static fishing::CastClipProgress castProgress;
static bool castFlightReleased=true;
static fishing::CastTurn castTurn;
static fishing::CastCharge castCharge;
static fishing::FightPose castSpin;
static spinlayer::Session spinLayer;
static bool spinSetRequested=false;
static fishing::FightPose fightPose;
static bool fightPoseEnabled=true,fightSetRequested=false,waitSetRequested=false;
static bool poseIsFight=false;
static fishing::FightFrameTransition fightFrameTransition;
static constexpr const char* waitPoseClip="nor_lso_pul_stn";
static float fightSampleAge=0;
static constexpr const char* castAnimSet="lso";
static bool castSetRequested=false,castSetOwned=false,castTaskIssued=false;
static uintptr_t castSetResource=0;
static const char* ownedAnimSet=nullptr;
static uintptr_t sessionBaseResource=0;
static fishing::CastControls castControls;
static float castClipAge=0,castSampleAge=0;
static const char* castClip=nullptr;
static fishing::Point geom(rh::Vec p){return {p.x,p.y,p.z};}
static rh::Vec vector(fishing::Point p){return {p.x,p.y,p.z};}
struct Prop {const char* name;int asset=-1,object=0;bool done=false;};
static Prop props[]={{"p_gen_fishingpole01x"},{"p_gen_fishingbobber01x"},{"p_gen_fishinghook01x"}};
// Mesh inspection confirmed fish01 is sliced; fish02 is the intact fish.
static std::string fishModel;
static int fishAsset=-1,fishObject=0;
static float fishScaleLogTime=0;
static fishing::ReelAudio reelAudio;
static fishing::ReelMenuAudio reelMenuAudio;
static fishing::FightMotion fightMotion;
static float audioTestLogAge=0;
static fishing::GameReelAudio gameReelAudio;
static bool reelAudioFailureLogged=false;
static fishing::CastSound castSound;
static fishing::WaterAudio waterAudio;
static fishing::GameWaterAudio gameWaterAudio;
static fishing::WaterTriggers waterTriggers;
static bool fishRequestPending=false,fishLoaded=false,fishSpawnAttempted=false;
static float fishLoadTime=0;
static rh::Vec fishMouthOffset{};
static void log(const char* format,...);
static void stopCastAnimation(bool resetPlan=true){
 spinLayer.stop(castAnimationActor);
 if(castSetOwned&&ownedAnimSet&&castAnimationActor&&rh::validActor(castAnimationActor)){
  castset::Snapshot current;const char* reason=nullptr;
  bool read=castset::snapshot(castAnimationActor,current,reason);
  bool baseSession=sessionBaseResource!=0;
  bool ours=read&&(baseSession?
   fishing::matchesBaseSession(sessionBaseResource,current.baseResource,current.resource,current.locked):
   current.resource==castSetResource);
  if(ours&&(baseSession||rh::invoke<0x31F5F57D,bool>(castAnimationActor,ownedAnimSet))){
   if(castTaskIssued)rh::invoke<0x16876A25>(castAnimationActor);
   // Flag 1 avoids the reset native's full animator reset branch.
   if(!baseSession)rh::invoke<0x7A6C5C2F>(castAnimationActor,1);
   log("Cast animset released: set=%s clipMatched=%d timeAdvanced=%d",ownedAnimSet,int(castClipConfirmed),int(castProgress.advanced));
  }else log("Cast animset ownership changed; actor state left to current owner");
 }
 // Restore our control bit even if the actor became unavailable.
 if(castControls.restore([](bool enabled){rh::invoke<0xD17AFCD8>(0,enabled,0,0);}))
  log("Cast player control restore requested");
 castAnimationActor=0;castClip=nullptr;castClipConfirmed=false;
 castSetOwned=false;castSetResource=0;ownedAnimSet=nullptr;sessionBaseResource=0;castTaskIssued=false;castClipAge=0;castSampleAge=0;castProgress.reset();
 castAnimation.reset();castTurn.reset();castSpin.reset();
 if(resetPlan)castPreparation.reset();else castPreparation.complete();
}
static void requestCastAnimSet(){
 if(!castAnimationEnabled||castSetRequested)return;
 rh::invoke<0x2988B3FC>(castAnimSet,0);castSetRequested=true;
 if(!spinSetRequested){rh::invoke<0x2988B3FC>(fishing::castSpinSet,0);spinSetRequested=true;}
 log("Cast animset requested: set=%s (verified in animationres.rpf)",castAnimSet);
}
static void requestFightAnimSet(){
 if(!fightPoseEnabled)return;
 if(!waitSetRequested){rh::invoke<0x2988B3FC>("gent",0);waitSetRequested=true;}
 if(fightSetRequested)return;
 rh::invoke<0x2988B3FC>(fishing::fightAnimSet,0);fightSetRequested=true;
 log("Fight animset requested: set=%s",fishing::fightAnimSet);
}
static bool bindCastAnimSet(int actor,const char* animSet=castAnimSet,bool allowBase=false,bool ownControls=true){
 castset::Snapshot before;const char* reason=nullptr;
 if(!castset::snapshot(actor,before,reason)){
  log("Cast animation skipped: %s",reason);return false;
 }
 // Never replace a pre-existing script override, even one using the same set.
 if(before.resource||before.locked){log("Cast animation skipped: existing actor animset override");return false;}
 bool accepted=rh::invoke<0x39C1E1C0,bool>(actor,animSet,0);
 bool attached=rh::invoke<0x31F5F57D,bool>(actor,animSet);
 castset::Snapshot after;
 bool read=castset::snapshot(actor,after,reason);
 auto binding=read?fishing::classifyAnimBinding(accepted,attached,allowBase,after.resource,after.locked,before.baseResource,after.baseResource):fishing::AnimBinding::Rejected;
 if(binding==fishing::AnimBinding::Rejected){
  if(accepted&&attached)rh::invoke<0x7A6C5C2F>(actor,1);
  log("Cast animset bind failed: accepted=%d attached=%d",int(accepted),int(attached));return false;
 }
 castAnimationActor=actor;castSetOwned=true;castSetResource=after.resource;ownedAnimSet=animSet;
 sessionBaseResource=binding==fishing::AnimBinding::Base?after.baseResource:0;
 if(ownControls)castControls.acquire([](){return rh::invoke<0x9613C2D0,bool>(0);},
                      [](bool enabled){rh::invoke<0xD17AFCD8>(0,enabled,0,0);});
 log("Cast animset bound: set=%s controlOwned=%d mode=%s",animSet,int(castControls.owned),sessionBaseResource?"native-base":"override");
 return true;
}
static void updateCastAnimation(int actor,float dt){
 if(!castAnimationEnabled)return;
 if(castCharge.active&&castCharge.released){
  // Release our spin override, then use the confirmed normal throw controller.
  stopCastAnimation();castCharge.reset();
  castTurn.begin(geom(forward));
  log("Cast charge released: starting normal throw toward camera target captured on release");
 }
 bool casting=game.phase==fishing::Phase::Cast;
 bool allowed=casting||game.phase==fishing::Phase::Wait;
 if(!allowed){if(castSetOwned)stopCastAnimation();else castPreparation.reset();return;}
 requestCastAnimSet();
 const char* animationSet=castCharge.active?fishing::castSpinSet:castAnimSet;
 bool loaded=rh::invoke<0x4FFF397D,bool>(animationSet);
 auto prepared=castPreparation.update(casting,allowed,loaded,dt,[&](){return bindCastAnimSet(actor,animationSet,false,!castCharge.active);});
 using Prep=fishing::CastPreparation::Result;
 if(prepared==Prep::Timeout){castFlightReleased=!castCharge.active;log("Cast animation skipped: lso animset load timeout");return;}
 if(prepared==Prep::Rejected){castFlightReleased=!castCharge.active;return;}
 if(castPreparation.stage!=fishing::CastPreparation::Stage::Ready)return;
 castset::Snapshot current;const char* reason=nullptr;
 if(actor!=castAnimationActor||!castset::snapshot(actor,current,reason)||current.resource!=castSetResource){
  log("Cast animation stopped: actor or animset ownership changed");castFlightReleased=!castCharge.active;stopCastAnimation(false);return;
 }
 if(castTurn.pending){
  float heading=rh::invoke<0x42DE39F0,float>(actor),next=heading;
  auto facing=castTurn.update(heading,dt,next);
  if(facing==fishing::CastTurn::Result::Failed){
   log("Cast facing failed: heading unavailable or turn did not converge");
   castFlightReleased=!castCharge.active;stopCastAnimation(false);return;
  }
  if(facing==fishing::CastTurn::Result::Turning){
   if(dt>0)rh::invoke<0xECE8520B>(actor,next,false);
   return;
  }
  log("Cast facing aligned: heading=%.2f target=%.2f",heading,castTurn.target);
 }
 if(castCharge.active){
  bool playing=rh::invoke<0x1ADE21EB,bool>(actor,fishing::castSpinBase);
  float time=rh::invoke<0x8609F5E1,float>(actor,fishing::castSpinBase);
  auto command=castSpin.update(true,true,dt,playing,time,[](){return true;});
  using C=fishing::FightPose::Command;
  if(command==C::Request||command==C::Retry){
   if(command==C::Retry&&castTaskIssued)rh::invoke<0x16876A25>(actor);
   fishing::requestCastClip([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,fishing::castSpinBase);
   castTaskIssued=true;log("Cast spin base requested: clip=%s retry=%d",fishing::castSpinBase,int(command==C::Retry));
  }
  if(command==C::Release){log("Cast spin unavailable; waiting for key release");stopCastAnimation(false);return;}
  if(castSpin.stage==fishing::FightPose::Stage::Holding&&!spinLayer.attempted){
   bool attached=spinLayer.start(actor,fishing::castSpinClip);
   log("Additive spin start: attached=%d occupied=%u capacity=%u reason=%s",int(attached),spinLayer.occupied,spinLayer.capacity,spinLayer.reason);
  }
  castSampleAge+=dt;
  if(castSampleAge>=.5f){float additiveTime=-1;bool attached=spinLayer.matched(actor,additiveTime);
   log("Additive spin sample: basePlaying=%d basePhase=%.4f layerAttached=%d layerPhase=%.4f",int(playing),time,int(attached),additiveTime);castSampleAge=0;}
  return;
 }
 bool playing=castClip&&rh::invoke<0x1ADE21EB,bool>(actor,castClip);
 float observedTime=castClip?rh::invoke<0x8609F5E1,float>(actor,castClip):-1.f;
 auto command=castAnimation.update(casting||prepared==Prep::Start,allowed,dt,playing,observedTime);
 using Command=fishing::CastAnimCommand;
 if(command==Command::Stop){stopCastAnimation(false);return;}
 if(command==Command::Launch){
  castFlightReleased=true;game.elapsed=0;tackleMotion.beginFlight();
  log("Cast flight launched after clip advancement: seconds=%.3f clipTime=%.4f",game.castSeconds,observedTime);
 }
 if(command==Command::EndHold){
  if(!castFlightReleased){castFlightReleased=true;game.elapsed=0;}
  log("Cast hold ended: reason=%s maxTime=%.4f age=%.3f",fishing::castEndName(castAnimation.end),castAnimation.maxTime,castClipAge);
  if(castTaskIssued){rh::invoke<0x16876A25>(actor);castTaskIssued=false;}
 }
 if(command==Command::Request||command==Command::Retry){
  // A retry is allowed once, only before any match/advancement starts the flight.
  if(command==Command::Retry){
   if(castTaskIssued)rh::invoke<0x16876A25>(actor);
   log("Cast clip startup retry: no active clip after initial request");
  }
  castClip=fishing::castReleaseClip;
  castClipConfirmed=false;castClipAge=0;castSampleAge=0;castProgress.reset();
  fishing::requestCastClip([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,castClip);
  castTaskIssued=true;
  log("Cast clip requested: set=%s clip=%s rate=%.1f loop=1 timer=%.1f gamePhase=%s",castAnimSet,castClip,fishing::castPlaybackRate,fishing::castTaskTimer,stateName(game.phase));
 }
 if(!castClip)return;
 castClipAge+=dt;castSampleAge+=dt;
 playing=rh::invoke<0x1ADE21EB,bool>(actor,castClip);
 float clipTime=rh::invoke<0x8609F5E1,float>(actor,castClip);
 if(playing&&!castClipConfirmed){castClipConfirmed=true;log("Cast clip MATCHED: clip=%s",castClip);}
 if(castProgress.observe(playing,clipTime))log("Cast animation ADVANCING: clip=%s clipTime=%.4f",castClip,clipTime);
 if(castSampleAge>=.1f){
  log("Cast clip sample: clip=%s playing=%d age=%.3f clipTime=%.4f setAttached=%d gamePhase=%s",castClip,int(playing),castClipAge,clipTime,int(rh::invoke<0x31F5F57D,bool>(actor,castAnimSet)),stateName(game.phase));
  castSampleAge=0;
 }
}
static void updateFightPose(int actor,float dt){
 using Pose=fishing::FightPose;
 bool fighting=game.phase==fishing::Phase::Fight;
 bool waiting=game.phase==fishing::Phase::Wait||game.phase==fishing::Phase::Bite;
 bool wanted=fightPoseEnabled&&(fighting||waiting);
 // Allow the confirmed cast hold/blend-out to finish before taking its session.
 if(wanted&&waiting&&castSetOwned&&!fightPose.owned)return;
 if(wanted&&fightPose.stage!=Pose::Stage::Idle&&poseIsFight!=fighting){
  // A base gent session has no override to remove. Preserve its active task
  // while binding lso_base, allowing TASK_PLAY_ANIM to crossfade from it.
  if(!sessionBaseResource)stopCastAnimation();
  fightPose.reset();fightFrameTransition.reset();fightSampleAge=0;
 }
 const char* poseClip=fighting?fishing::fightHoldClip:waitPoseClip;
 const char* poseSet=fighting?fishing::fightAnimSet:"gent";
 // Release the previous phase's animation before acquiring a new session.
 if(wanted&&fightPose.stage==Pose::Stage::Idle){
  if(!sessionBaseResource)stopCastAnimation();
  poseIsFight=fighting;fightFrameTransition.reset();fightSampleAge=0;
  log("Fight pose preparing: clip=%s",poseClip);
 }
 if(wanted&&fightPose.owned){
  castset::Snapshot current;const char* reason=nullptr;
  bool read=castset::snapshot(actor,current,reason);
  bool ours=read&&(sessionBaseResource?
   fishing::matchesBaseSession(sessionBaseResource,current.baseResource,current.resource,current.locked):
   current.resource==castSetResource);
  if(actor!=castAnimationActor||!ours){
   log("Fight pose stopped: actor or animset ownership changed");
   stopCastAnimation();fightPose.owned=false;fightPose.stage=Pose::Stage::Failed;return;
  }
 }
 if(wanted)requestFightAnimSet();
 bool loaded=wanted&&rh::invoke<0x4FFF397D,bool>(poseSet);
 bool playing=fightPose.owned&&rh::invoke<0x1ADE21EB,bool>(actor,poseClip);
 float time=fightPose.owned?rh::invoke<0x8609F5E1,float>(actor,poseClip):-1.f;
 auto before=fightPose.stage;
 auto command=fightPose.update(wanted,loaded,dt,playing,time,[&](){return bindCastAnimSet(actor,poseSet,true,false);});
 if((fightPose.stage==Pose::Stage::Failed||(!wanted&&before!=Pose::Stage::Idle))&&castSetOwned&&command!=Pose::Command::Release){
  stopCastAnimation();
 }
 if(command==Pose::Command::Release){
  log("Fight pose released: phase=%s previousStage=%d",stateName(game.phase),int(before));
  stopCastAnimation();return;
 }
 if(command==Pose::Command::Request||command==Pose::Command::Retry){
  if(command==Pose::Command::Retry&&castTaskIssued)rh::invoke<0x16876A25>(actor);
  if(fighting)fishing::requestFightClip([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor);
  else rh::invoke<0x5AB552C6>(actor,poseClip,.45f,fishing::castBlendOut,1.f,0,true,false,-1.f);
  castTaskIssued=true;
  log("Fight pose %s: clip=%s rate=1 loop=1 timer=-1 phase=%s blend=%.2f",command==Pose::Command::Retry?"startup retry":"requested",poseClip,stateName(game.phase),fighting?.65:.45);
 }
 if(before!=Pose::Stage::Holding&&fightPose.stage==Pose::Stage::Holding)
  log("Fight pose ADVANCING: clip=%s clipTime=%.4f",poseClip,time);
 if(before!=Pose::Stage::Failed&&fightPose.stage==Pose::Stage::Failed)
  log("Fight pose unavailable: startup/streaming failed; fishing continues");
 if(fighting&&fightPose.stage==Pose::Stage::Holding&&playing&&dt>0){
  bool wasHeld=fightFrameTransition.held;
  float heldPhase=fightFrameTransition.sample(time,dt);
  if(!wasHeld&&fightFrameTransition.held)log("Confirmed pose held: clip=%s phase=%.4f observed=%.4f",poseClip,heldPhase,time);
  if(heldPhase>=0&&!rh::invoke<0x8626C1A0,bool>(actor,heldPhase)){
   log("Fight pose seek failed; pose session ended");
   stopCastAnimation();fightPose.owned=false;fightPose.stage=Pose::Stage::Failed;return;
  }
 }
 if(fightPose.owned){
  fightSampleAge+=dt;
  if(fightSampleAge>=1.f){log("Fight pose sample: playing=%d clipTime=%.4f phase=%s",int(playing),time,stateName(game.phase));fightSampleAge=0;}
 }
}
static bool fishVisiblePhase(){
 using fishing::Phase;
 return game.phase==Phase::Bite||game.phase==Phase::Fight||game.phase==Phase::Caught;
}
static void removeFish(){
 if(rh::validObject(fishObject)){rh::invoke<0x21144994>(fishObject);log("Hooked fish removed: object=%d",fishObject);}
 fishObject=0;fishSpawnAttempted=false;
}
static int layout=0;static float loadTime=0;
static void log(const char* format,...) {
 char buf[1024];va_list a;va_start(a,format);vsnprintf(buf,sizeof(buf),format,a);va_end(a);
 rh::print(1,"[Fishing] %s",buf);
 if(FILE* f=fopen(logPath.c_str(),"a")){fprintf(f,"[%llu ms] %s\n",static_cast<unsigned long long>(GetTickCount64()),buf);fclose(f);}
}
static void save(){char b[32];snprintf(b,sizeof(b),"%u",game.catches);if(!WritePrivateProfileStringA("Progress","Catches",b,iniPath.c_str()))log("Cannot save catches (Win32 %lu)",GetLastError());savedCatches=game.catches;}
static void cleanup(){
 reelAudio.stop(gameReelAudio);reelMenuAudio.reset();fightMotion.reset();castSound.reset(gameReelAudio);waterAudio.stop(gameWaterAudio);waterTriggers.reset();reelAudioFailureLogged=false;
 castCharge.reset();rodCone.reset();rodGripPose.reset();tackleMotion.reset();
 tackleCamera.clear([](int camera,int object){if(rh::validObject(camera))rh::invoke<0x781D5599>(camera,object);});
 fightPose.reset();fightFrameTransition.reset();fightSampleAge=0;
 stopCastAnimation();
 if(castSetRequested){rh::invoke<0xD04A817A>(castAnimSet);castSetRequested=false;}
 if(spinSetRequested){rh::invoke<0xD04A817A>(fishing::castSpinSet);spinSetRequested=false;}
 if(fightSetRequested){rh::invoke<0xD04A817A>(fishing::fightAnimSet);fightSetRequested=false;}
 if(waitSetRequested){rh::invoke<0xD04A817A>("gent");waitSetRequested=false;}
 if(rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment))rh::invoke<0xE894DC13>(rodAttachment);
 rodAttachment=0;rodAttachRetry=0;
 removeFish();
 if(fishing::validAsset(fishAsset))rh::invoke<0xA8D12960>(fishAsset);
 fishAsset=-1;fishLoaded=false;fishRequestPending=false;fishLoadTime=0;
 for(auto& p:props){if(rh::validObject(p.object))rh::invoke<0x21144994>(p.object);p.object=0;if(fishing::validAsset(p.asset))rh::invoke<0xA8D12960>(p.asset);p.asset=-1;p.done=false;}
 if(layout&&rh::validObject(layout))rh::invoke<0x21144994>(layout);
 layout=0;hasWaterTarget=false;handBone=nullptr;rigHandBone.clear();rigNamesLogged=false;
}
static void requestProps(){
 if(!visuals)return;
 layout=rh::invoke<0x6CA53214,int>("RDR1Fishing");loadTime=0;
 for(auto& p:props){std::string path="$/fragments/";path+=p.name;rh::invoke<0x9AA02DA7,int>(path.c_str(),0);p.asset=rh::invoke<0x6005B514,int>(path.c_str(),0);log("Request %s: asset=%d",path.c_str(),p.asset);if(fishing::validAsset(p.asset))rh::invoke<0x38DC1F50,bool>(p.asset,true);else p.done=true;}
 if(!fishModel.empty()){
  std::string path="$/fragments/"+fishModel;
  rh::invoke<0x9AA02DA7,int>(path.c_str(),0);fishAsset=rh::invoke<0x6005B514,int>(path.c_str(),0);
  fishRequestPending=fishing::validAsset(fishAsset);fishLoadTime=0;
  if(fishRequestPending)rh::invoke<0x38DC1F50,bool>(fishAsset,true);
  log("Fish request %s: asset=%d pending=%d",path.c_str(),fishAsset,int(fishRequestPending));
 }else log("Fish rendering disabled: no installed fish model configured in [Fish] Model");
}
static rh::Vec point(float distance,float height,float side=0){return {origin.x+forward.x*distance+forward.z*side,origin.y+height,origin.z+forward.z*distance-forward.x*side};}
static rh::Vec actorForward(int actor){
 float heading=rh::invoke<0x42DE39F0,float>(actor)*.01745329252f;
 return {std::sin(heading),0,std::cos(heading)};
}
static rh::Vec actorPoint(int actor,float distance,float height,float side=0){
 auto body=rh::position(actor);auto facing=actorForward(actor);
 return {body.x+facing.x*distance+facing.z*side,body.y+height,body.z+facing.z*distance-facing.x*side};
}
static bool updateCastDirection(){
 // RDR.exe 0x1403AAEF0: output vector pointer first, camera channel second.
 // Channel 0 is the rendered view; the handler returns its forward direction.
 alignas(16) rh::Vec direction{};
 if(!rh::invoke<0x6ED00237,bool>(&direction,0))return false;
 fishing::Point flat{};
 if(!fishing::horizontalDirection(geom(direction),flat))return false;
 forward=vector(flat);return true;
}
static bool handPositionValid(rh::Vec p,int actor){
 auto body=rh::position(actor);
 float dx=p.x-body.x,dy=p.y-body.y,dz=p.z-body.z;
 return fishing::finite(geom(p))&&dx*dx+dy*dy+dz*dz<9;
}
static void findHandBone(int actor){
 int object=rh::invoke<0x4A2063EC,int>(actor);
 // Confirmed by the user's Rampage inspection AND the v0.1.14 actor bone log.
 alignas(16) rh::Vec wrist{};
 bool wristFound=rh::invoke<0x30516389,bool>(object,"wrist_r",&wrist);
 if(wristFound&&handPositionValid(wrist,actor)){
  handBone="wrist_r";rigNamesLogged=true;
  log("Hand bone found: wrist_r position=(%.3f %.3f %.3f)",wrist.x,wrist.y,wrist.z);return;
 }
 if(!rigNamesLogged)log("Confirmed wrist lookup: wrist_r result=%d position=(%.3f %.3f %.3f)",int(wristFound),wrist.x,wrist.y,wrist.z);
 // Resolve the actual name in this loaded model, preserving exact case.
 std::vector<std::string> names;const char* reason="";
 if(rig::names(object,names,reason)){
  if(!rigNamesLogged){
   log("Actor skeleton: %u named bones",unsigned(names.size()));
   for(const auto& name:names)log("Actor bone: %s",name.c_str());
  }
  for(const auto& name:names){
   if(!fishing::rightHandBoneName(name))continue;
   alignas(16) rh::Vec p{};
   bool ok=rh::invoke<0x30516389,bool>(object,name.c_str(),&p);
   if(!rigNamesLogged)log("Right-hand candidate: %s result=%d position=(%.3f %.3f %.3f)",name.c_str(),int(ok),p.x,p.y,p.z);
   if(ok&&handPositionValid(p,actor)){
    rigHandBone=name;handBone=rigHandBone.c_str();rigNamesLogged=true;
    log("Hand bone resolved from actor skeleton: %s",handBone);return;
   }
  }
 }else if(!rigNamesLogged)log("Actor skeleton enumeration unavailable: %s",reason);
 // Compatibility fallback for models/builds whose descriptor cannot be enumerated.
 for(const char* name:{"wrist_r","SKEL_R_Hand","skel_r_hand","R_Hand","r_hand","hand_r","Hand_R","Hand_Right","RightHand","RHand","rhand","Bip01 R Hand"}){
  alignas(16) rh::Vec p{};
  bool ok=rh::invoke<0x30516389,bool>(object,name,&p);
  if(!rigNamesLogged)log("Hand lookup: %s result=%d position=(%.3f %.3f %.3f)",name,int(ok),p.x,p.y,p.z);
  if(ok&&handPositionValid(p,actor)){
   handBone=name;rigNamesLogged=true;log("Hand bone found: %s",name);return;
  }
 }
 if(!rigNamesLogged)log("Hand not resolved; attachment pending (retry every second)");
 rigNamesLogged=true;
}
static rh::Vec handPosition(int actor){
 rh::Vec p{};
 if(handBone){
  int object=rh::invoke<0x4A2063EC,int>(actor);
  if(rh::invoke<0x30516389,bool>(object,handBone,&p)&&handPositionValid(p,actor))return p;
 }
 return actorPoint(actor,.35f,1.0f,.3f);
}
static void disablePropCollisions(int rod){
 if(!rh::validObject(rod))return;
 // These tackle props are visual only. RDR.exe handlers 0x1402331F0 / 0x140233230:
 // false sets the no-world/no-movables collision flags on this prop only.
 rh::invoke<0x601FC9F4>(rod,false);
 rh::invoke<0x05D69EA6>(rod,false);
}
static void disableRodCollisions(){disablePropCollisions(props[0].object);}
static bool attachRod(float dt,int actor){
 if(rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment))return true;
 rodAttachment=0;rodAttachRetry-=dt;
 if(rodAttachRetry>0||!rh::validObject(props[0].object))return false;
 rodAttachRetry=1.f;
 if(!handBone)findHandBone(actor);
 if(!handBone)return false;
 int parent=rh::invoke<0x4A2063EC,int>(actor);
 if(!rh::validObject(parent))return false;
 // RDR.exe 0x140230E80: child, parent, parent bone, packed offset,
 // offset Z, packed rotation, rotation Z, flags (8 native slots).
 rodAttachment=rh::invoke<0xE1421B42,int>(props[0].object,parent,handBone,
     rh::XY{0,0},0.f,rh::XY{0,0},0.f,0);
 bool attached=rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment);
 if(attached){
  // 0x1402DAA5C: preserve child rotation while the engine updates hand translation.
  rh::invoke<0xA870B28E>(rodAttachment,true);
  // Reapply after attachment initialization, before yielding to the physics frame.
  disableRodCollisions();
 }
 log("Rod attachment: bone=%s child=%d parent=%d attachment=%d valid=%d",
     handBone,props[0].object,parent,rodAttachment,int(attached));
 return attached;
}
static bool findWater(rh::Vec candidate,rh::Vec& hit){
 // RDR.exe 1.0.40 handler 0x1402965D0: two packed input vectors,
 // then two vector output pointers. The SDK's eight-int placeholder is incomplete.
 alignas(16) rh::Vec intersection{},normal{};
 float top=origin.y+8, bottom=origin.y-40;
 bool ok=rh::invoke<0x4F193BE4,bool>(rh::XY{candidate.x,top},candidate.z,rh::XY{candidate.x,bottom},candidate.z,&intersection,&normal,0,0);
 if(ok&&fishing::waterHitValid(geom(candidate),geom(intersection),top,bottom)){
  hit=intersection;log("Water hit at %.3f %.3f %.3f",hit.x,hit.y,hit.z);return true;
 }
 log("No water intersection at %.3f %.3f (result=%d xyz=%.3f %.3f %.3f)",candidate.x,candidate.z,int(ok),intersection.x,intersection.y,intersection.z);
 return false;
}
static bool prepareCast(int actor){
 origin=rh::position(actor);hasWaterTarget=false;
 if(!updateCastDirection()){
  notice="Cannot read camera direction.\nLook toward the water and try again.";noticeTime=4;
  log("Cast refused: camera direction unavailable or vertical");return false;
 }
 log("Cast direction from camera: %.4f %.4f %.4f",forward.x,forward.y,forward.z);
 if(autoWater){
  // Prefer requested distance; shorten until we find a water surface ahead.
  for(float distance=castDistance;distance>=2.9f;distance-=2){
   auto candidate=point(distance,0);
   if(findWater(candidate,waterTarget)){hasWaterTarget=true;break;}
  }
 }
 if(!hasWaterTarget){
  if(requireWater&&autoWater){notice="No water ahead.\nFace the water and press your cast key.";noticeTime=4;log("Cast refused: no verified water surface ahead");return false;}
  waterTarget=point(castDistance,waterOffset);hasWaterTarget=true;
  log("Manual water target: %.3f %.3f %.3f",waterTarget.x,waterTarget.y,waterTarget.z);
 }
 // Keep the model pivot slightly above water so the float remains visible.
 waterTarget.y+=.08f;
 game.castSeconds=fishing::castFlightSeconds(std::hypot(waterTarget.x-origin.x,waterTarget.z-origin.z),castAnimationEnabled);
 castTurn.reset();
 if(castAnimationEnabled){
  if(!castTurn.begin(geom(forward))){log("Cast refused: invalid facing direction");return false;}
  log("Cast facing target: heading=%.2f from release camera direction",castTurn.target);
 }
 noticeTime=0;castFlightReleased=!castAnimationEnabled;tackleMotion.prepare();
 log("Cast target: %.3f %.3f %.3f (player %.3f %.3f %.3f)",waterTarget.x,waterTarget.y,waterTarget.z,origin.x,origin.y,origin.z);
 return true;
}
static bool project(rh::Vec p,float& x,float& y){
 if(!rh::invoke<0xBAA72911,bool>(&p,&x,&y))return false;
 return std::isfinite(x)&&std::isfinite(y)&&x>=0&&x<=1&&y>=0&&y<=1;
}
static void drawRig(){
 using fishing::Phase;
 bool out=game.phase!=Phase::Off;
 if(!out||!tackleMotion.valid)return;
 if(showLine){
  RECT viewport{};
  if(!GetClientRect(GetForegroundWindow(),&viewport))return;
  int width=int(viewport.right-viewport.left),height=int(viewport.bottom-viewport.top);
  if(width<1||height<1)return;
  float invWidth=1.f/width,invHeight=1.f/height;
  bool previousValid=false,connected=false;int previousX=0,previousY=0;
  for(int i=0;i<=64;i++){
   float t=i/64.f;
   float sag=tackleMotion.whirling?.025f:std::min(.18f,std::hypot(lineTip.x-bobberPosition.x,lineTip.z-bobberPosition.z)*.03f);
   auto p=fishing::tackleLine(geom(lineTip),geom(bobberPosition),geom(hookPosition),t,sag);
   float x=0,y=0;
   if(!project(vector(p),x,y)){previousValid=false;connected=false;continue;}
   int px=std::clamp(int(std::lround(x*(width-1))),0,width-1);
   int py=std::clamp(int(std::lround(y*(height-1))),0,height-1);
   if(previousValid){
    fishing::solidLine(previousX,previousY,px,py,connected,[&](int left,int top,int w,int h){
     rh::drawRect((left+w*.5f)*invWidth,(top+h*.5f)*invHeight,w*invWidth,h*invHeight,220,225,215,190);
    });
    connected=true;
   }
   previousX=px;previousY=py;previousValid=true;
  }
 }
}
static void updateFish(float dt,rh::Vec hook){
 if(fishRequestPending){
  fishLoadTime+=dt;
  if(rh::invoke<0xD7F80035,bool>(fishAsset)){fishRequestPending=false;fishLoaded=true;log("Fish asset loaded: %s",fishModel.c_str());}
  else if(fishLoadTime>5){fishRequestPending=false;log("Fish asset unavailable: %s (no substitute model created)",fishModel.c_str());}
 }
 if(!fishVisiblePhase()){removeFish();return;}
 if(!fishLoaded)return;
 float fishYaw=std::atan2(forward.x,forward.z)*57.295779513f-90.f;
 float flutter=fishMouthOffset.x==0&&fishMouthOffset.y==0&&fishMouthOffset.z==0?
  (game.phase==fishing::Phase::Fight?fightMotion.fishRoll:10.f*std::sin(game.elapsed*10)):0.f;
 auto mouth=fishMouthOffset;
 if(game.phase==fishing::Phase::Caught){
  auto hang=fishing::fishHang(fishYaw,geom(mouth),game.elapsed);
  fishYaw=hang.yaw;flutter=hang.roll;mouth=vector(hang.mouth);
 }
 rh::Vec position{hook.x-mouth.x,hook.y-mouth.y,hook.z-mouth.z};
 if(!fishSpawnAttempted){
  fishSpawnAttempted=true;std::string path="$/fragments/"+fishModel;
  fishObject=rh::invoke<0xE351587D,int>(layout,"FishingHookedFish",path.c_str(),rh::XY{position.x,position.y},position.z,rh::XY{0,0},0.f,true);
  log("Fish spawn in %s: model=%s object=%d valid=%d",stateName(game.phase),fishModel.c_str(),fishObject,int(rh::validObject(fishObject)));
 }
 if(rh::validObject(fishObject)){
  float fishScale=fishing::fishScaleForWeight(game.weight);
  rh::move(fishObject,position);
  // Swimming yaw remains unchanged; only Caught blends to head-up hanging.
  bool rotated=rh::invoke<0xC8A4EE74,bool>(fishObject,rh::XY{0,fishYaw},flutter);
  fishScaleLogTime+=dt;
  if(rotated){
   disablePropCollisions(fishObject);
   const char* reason=nullptr;float observed=-1;
   bool applied=fishscale::apply(fishObject,fishScale,geom(mouth),reason,observed);
   if(!applied){rh::move(fishObject,position);rh::invoke<0xC8A4EE74,bool>(fishObject,rh::XY{0,fishYaw},flutter);}
   if(fishScaleLogTime>=2){fishScaleLogTime=0;log("Fish scale: object=%d weight=%.2fkg category=%s requested=%.2f observed=%.3f applied=%d reason=%s",fishObject,game.weight,game.weight<1?"small":game.weight<=5?"normal":"large",fishScale,observed,int(applied),reason);}
  }
 }
}
static void updateProps(float dt,int actor){
 if(!visuals||!layout)return;
 loadTime+=dt;
 for(auto& p:props){if(p.done)continue;
  if(fishing::validAsset(p.asset)&&rh::invoke<0xD7F80035,bool>(p.asset)){
   auto at=actorPoint(actor,.4f,1);std::string path="$/fragments/";path+=p.name;
   p.object=rh::invoke<0xE351587D,int>(layout,p.name,path.c_str(),rh::XY{at.x,at.y},at.z,rh::XY{0,0},0.f,true);p.done=true;
   disablePropCollisions(p.object);
   if(&p==&props[0]&&rh::validObject(p.object)){
    disableRodCollisions();
    log("Rod collision disabled: object=%d world=0 movables=0",p.object);
   }
   log("Created %s: object=%d valid=%d",p.name,p.object,int(rh::validObject(p.object)));
  }else if(loadTime>5){p.done=true;log("Model unavailable: %s; continuing gameplay without it",p.name);}
 }
 int camera=rh::invoke<0x6B7677BF,int>();
 if(!rh::validObject(camera))camera=0;
 std::array<int,3> cameraProps{};
 for(unsigned i=0;i<cameraProps.size();++i)if(rh::validObject(props[i].object))cameraProps[i]=props[i].object;
 tackleCamera.sync(camera,cameraProps,
  [](int cam,int object,int flags){rh::invoke<0x5BBFA4D7>(cam,object,flags);},
  [](int cam,int object){if(rh::validObject(cam))rh::invoke<0x781D5599>(cam,object);});
 auto hand=handPosition(actor);
 // Procedural rod motion; body animation is not fabricated from unknown lasso clip names.
 float pitch=-12.f;
 if(game.phase==fishing::Phase::Cast){
  if(castFlightReleased)pitch=-55+90*std::clamp(game.elapsed/game.castSeconds,0.f,1.f);
  else pitch=-12-43*std::clamp(castProgress.last,0.f,1.f);
 }
 else if(game.phase==fishing::Phase::Wait&&castAnimation.stage==fishing::CastAnimation::Stage::BlendOut)
  pitch=35-47*std::clamp(castAnimation.elapsed/fishing::castBlendOut,0.f,1.f);
 else if(game.phase==fishing::Phase::Bite)pitch=-28+8*std::sin(game.elapsed*12);
 else if(game.phase==fishing::Phase::Fight)pitch=-20-game.tension*22+4*std::sin(game.elapsed*5)+fightMotion.rodPitch;
 bool rodAttached=attachRod(dt,actor);
 bool rodMoved=rodAttached;
 if(!rodAttached&&rh::validObject(props[0].object))
  rodMoved=rh::invoke<0xC5D796F8,bool>(props[0].object,rh::XY{hand.x,hand.y},hand.z);
 float spinPhase=-1;
 bool nativeSpin=castCharge.active&&!castCharge.released&&spinLayer.matched(actor,spinPhase);
 bool windingDown=tackleMotion.whirling&&(!castCharge.active||castCharge.released);
 bool spinning=game.phase==fishing::Phase::Cast&&!castFlightReleased&&(nativeSpin||windingDown);
 auto poleRotation=rodCone.rotation(spinning,dt,tackleMotion.angle,pitch,rh::invoke<0x42DE39F0,float>(actor));
 if(game.phase==fishing::Phase::Fight)poleRotation.z+=fightMotion.rodRoll;
 if(rh::validObject(props[0].object))rh::invoke<0xC8A4EE74,bool>(props[0].object,rh::XY{poleRotation.x,poleRotation.y},poleRotation.z);
 auto gripPose=fishing::GripPose::Neutral;
 if(game.phase==fishing::Phase::Ready)gripPose=fishing::GripPose::Ready;
 else if(game.phase==fishing::Phase::Wait||game.phase==fishing::Phase::Bite)gripPose=fishing::GripPose::Waiting;
 else if(game.phase==fishing::Phase::Fight)gripPose=fishing::GripPose::Fighting;
 auto gripDelta=rodGripPose.update(gripPose,dt,geom(actorForward(actor)));
 // Offset the grip in the current wrist frame; do not move the actor or reattach each frame.
 if(rodAttached){
  rh::Vec axes[3]{},tip{},base{};
  int parent=rh::invoke<0x4A2063EC,int>(actor);
  if(rig::basis(parent,handBone,axes)&&rh::invoke<0x30516389,bool>(props[0].object,"joint5",&tip)&&
     rh::invoke<0x31201B4C,bool>(props[0].object,&base)){
   fishing::Point basis[3]={geom(axes[0]),geom(axes[1]),geom(axes[2])},offset{};
   auto world=fishing::gripWorld({tip.x-base.x,tip.y-base.y,tip.z-base.z},geom(actorForward(actor)));
   world.x+=gripDelta.x;world.y+=gripDelta.y;world.z+=gripDelta.z;
   if(fishing::gripLocal(world,basis,offset)){
    rh::invoke<0xD4A54348>(rodAttachment,rh::XY{offset.x,offset.y},offset.z);
    static int loggedGrip=0;static auto loggedPose=fishing::GripPose::Neutral;
    if(loggedGrip!=rodAttachment||loggedPose!=gripPose){
     loggedGrip=rodAttachment;loggedPose=gripPose;
     auto correction=fishing::gripCorrection(gripPose);
     log("Rod grip profile: pose=%d right=%.3f vertical=%.3f blendSeconds=0.65",int(gripPose),correction.x,correction.y);
     log("Rod grip: attachment=%d shaftShift=-0.120 palmShift=0.025 sideShift=0.020 local=(%.4f %.4f %.4f)",rodAttachment,offset.x,offset.y,offset.z);
    }
   }
  }
 }
 auto rodFacing=actorForward(actor);
 lineTip={hand.x+rodFacing.x*1.7f,hand.y+1,hand.z+rodFacing.z*1.7f};
 // Use the actual rod tip when this model exposes its named terminal bone.
 if(rh::validObject(props[0].object)){
  rh::Vec tip{};
  if(rh::invoke<0x30516389,bool>(props[0].object,"joint5",&tip)&&fishing::finite(geom(tip))){
   float dx=tip.x-hand.x,dy=tip.y-hand.y,dz=tip.z-hand.z;
   if(dx*dx+dy*dy+dz*dz<100)lineTip=tip;
  }
 }
 using fishing::Phase;
 bool cast=game.phase==Phase::Cast;
 bool out=(cast&&castFlightReleased)||game.phase==Phase::Wait||game.phase==Phase::Bite||game.phase==Phase::Fight;
 if(out&&hasWaterTarget){
  if(cast)tackleMotion.fly(geom(lineTip),geom(waterTarget),game.elapsed/game.castSeconds,game.castSeconds,dt);
  else {
   auto at=waterTarget;
   if(game.phase==Phase::Fight){
    auto closePoint=point(2,0);closePoint.y=waterTarget.y;
    at=vector(fishing::mix(geom(waterTarget),geom(closePoint),game.progress));
    at.x+=forward.z*fightMotion.side;at.z-=forward.x*fightMotion.side;
    at.y+=.025f*std::sin(game.elapsed*8)+fightMotion.vertical;
   }else if(game.phase==Phase::Bite)at.y+=.06f*std::sin(game.elapsed*18);
   else at.y+=.018f*std::sin(game.elapsed*3);
   auto hook=at;hook.y-=.3f;tackleMotion.commit(geom(at),geom(hook),dt);
  }
 }else if(spinning)tackleMotion.whirl(geom(lineTip),geom(forward),dt,spinPhase,fishing::subtract(geom(lineTip),geom(hand)));
 else tackleMotion.stow(geom(lineTip),dt);
 bobberPosition=vector(tackleMotion.bobber);hookPosition=vector(tackleMotion.hook);
 bool bobberMoved=rh::validObject(props[1].object)&&rh::invoke<0xC5D796F8,bool>(props[1].object,rh::XY{bobberPosition.x,bobberPosition.y},bobberPosition.z);
 auto hook=hookPosition;rh::move(props[2].object,hook);
 updateFish(dt,hook);
 drawRig();
 visualLogTime+=dt;
 if(visualLogTime>=2){
  visualLogTime=0;rh::Vec actual{};
  if(rh::validObject(props[1].object))rh::invoke<0x31201B4C,bool>(props[1].object,&actual);
  if(handBone){
   rh::Vec rod{};bool readRod=rh::invoke<0x31201B4C,bool>(props[0].object,&rod);
   log("Rod hand check: bone=%s attached=%d read=%d hand=(%.3f %.3f %.3f) rod=(%.3f %.3f %.3f)",handBone,int(rodAttached),int(readRod),hand.x,hand.y,hand.z,rod.x,rod.y,rod.z);
  }
  log("Rig %s: moveRod=%d moveFloat=%d desired=(%.3f %.3f %.3f) actual=(%.3f %.3f %.3f)",stateName(game.phase),int(rodMoved),int(bobberMoved),bobberPosition.x,bobberPosition.y,bobberPosition.z,actual.x,actual.y,actual.z);
  if(rh::validObject(fishObject)){rh::Vec fishAt{};rh::invoke<0x31201B4C,bool>(fishObject,&fishAt);log("Fish follows hook: object=%d hook=(%.3f %.3f %.3f) fish=(%.3f %.3f %.3f)",fishObject,hook.x,hook.y,hook.z,fishAt.x,fishAt.y,fishAt.z);}
 }
}
static void hud(){
 if(!hudEnabled)return;
 using fishing::Phase;
 // RedHook queues draw calls; storage must remain valid after this function returns.
 static char buf[1024];char detail[512]{};
 switch(game.phase){
 case Phase::Ready:snprintf(detail,sizeof(detail),"%s: CAST | %s: stop\nLook toward the water with the camera",actionName.c_str(),toggleName.c_str());break;
 case Phase::Cast:snprintf(detail,sizeof(detail),castCharge.active&&!castCharge.released?"Hold %s: spin and aim with camera | Release: cast":"Casting...",actionName.c_str());break;
 case Phase::Wait:snprintf(detail,sizeof(detail),"Waiting for a bite: %.0f s\nWait for BITE, then press %s",std::ceil(std::max(0.f,game.wait-game.elapsed)),actionName.c_str());break;
 case Phase::Bite:snprintf(detail,sizeof(detail),"BITE! Press %s NOW! %.1f s",actionName.c_str(),std::max(0.f,game.biteWindow-game.elapsed));break;
 case Phase::Fight:snprintf(detail,sizeof(detail),"Hold %s: reel | Hold %s: ease\nTension: %d%% | Reeled: %d%%\nFish pulls: %s",reelName.c_str(),easeName.c_str(),int(game.tension*100),int(game.progress*100),(int(game.elapsed/1.6f)%3)!=2?"YES":"NO");break;
 case Phase::Caught:snprintf(detail,sizeof(detail),"CAUGHT! %.2f kg | %s: next cast",game.weight,actionName.c_str());break;
 case Phase::Lost:snprintf(detail,sizeof(detail),"Fish escaped / line lost. %s: try again",actionName.c_str());break;
 default:return;
 }
 if(noticeTime>0)snprintf(detail,sizeof(detail),"%s",notice);
 snprintf(buf,sizeof(buf),"FISHING v0.1.76 | Total catches: %u\n%s",game.catches,detail);
 // HUD text has no panel background; keep the tension gauge only.
 // Eight black copies form a one-pixel outline around every glyph, including diagonals.
 // Use client pixels, since RedHook text coordinates are normalized.
 RECT viewport{};
 float outlineX=1.f/1920.f,outlineY=1.f/1080.f;
 if(GetClientRect(GetForegroundWindow(),&viewport)&&viewport.right>viewport.left&&viewport.bottom>viewport.top){
  outlineX=1.f/(viewport.right-viewport.left);outlineY=1.f/(viewport.bottom-viewport.top);
 }
 for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){
  if(dx||dy)rh::drawText(buf,.035f+dx*outlineX,.25f+dy*outlineY,0,hudTextHeight,0,0,0,255,0);
 }
 rh::drawText(buf,.035f,.25f,0,hudTextHeight,255,255,255,255,0);
 if(game.phase==Phase::Fight){
  rh::drawRect(.24f,.345f,.41f,.008f,60,60,60,255);
  float width=.41f*std::clamp(game.tension,0.f,1.f);
  rh::drawRect(.035f+width*.5f,.345f,width,.008f,game.tension>.8f?255:80,game.tension>.8f?60:220,60,255);
 }
}
static void script(){
 char path[MAX_PATH];GetModuleFileNameA(module,path,MAX_PATH);std::string root=path;root=root.substr(0,root.find_last_of("\\/")+1);iniPath=root+"Fishing.ini";logPath=root+"Fishing.log";
 castAnimationEnabled=GetPrivateProfileIntA("Animation","Cast",1,iniPath.c_str())!=0;
 fightPoseEnabled=GetPrivateProfileIntA("Animation","Fight",1,iniPath.c_str())!=0;
 hudEnabled=GetPrivateProfileIntA("HUD","Enabled",1,iniPath.c_str())!=0;
 hudTextHeight=std::clamp(GetPrivateProfileIntA("HUD","TextHeightPermille",18,iniPath.c_str()),12u,24u)/1000.f;
 char fishName[160]{};
 GetPrivateProfileStringA("Fish","Model","p_gen_fish02x",fishName,sizeof(fishName),iniPath.c_str());
 fishModel=fishName;
 if(fishModel=="p_gen_fish01x"){fishModel="p_gen_fish02x";log("Replaced sliced fish01 with intact fish02");}
 if(!GetPrivateProfileIntA("Fish","Enabled",1,iniPath.c_str()))fishModel.clear();
 // Resource names only: do not accept paths or a local WFT masquerading as an installed asset.
 if(fishModel.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")!=std::string::npos)fishModel.clear();
 fishMouthOffset={std::clamp(int(GetPrivateProfileIntA("Fish","MouthOffsetXcm",0,iniPath.c_str())),-500,500)/100.f,std::clamp(int(GetPrivateProfileIntA("Fish","MouthOffsetYcm",0,iniPath.c_str())),-500,500)/100.f,std::clamp(int(GetPrivateProfileIntA("Fish","MouthOffsetZcm",0,iniPath.c_str())),-500,500)/100.f};
 visuals=GetPrivateProfileIntA("Fishing","Visuals",1,iniPath.c_str())!=0;
 waterOffset=std::clamp(int(GetPrivateProfileIntA("Fishing","WaterOffsetCm",-65,iniPath.c_str()))/100.f,-5.f,2.f);
 autoWater=GetPrivateProfileIntA("Fishing","AutoWater",1,iniPath.c_str())!=0;
 requireWater=GetPrivateProfileIntA("Fishing","RequireWater",1,iniPath.c_str())!=0;
 showLine=GetPrivateProfileIntA("HUD","ShowLine",1,iniPath.c_str())!=0;
 castDistance=std::clamp(GetPrivateProfileIntA("Fishing","CastDistance",9,iniPath.c_str())*1.f,3.f,20.f);
 toggleKey=readKey("Toggle",VK_F6);actionKey=readKey("Action",'E');reelKey=readKey("Reel",'R');easeKey=readKey("Ease",'Q');
 if(toggleKey==actionKey||toggleKey==reelKey||toggleKey==easeKey||actionKey==reelKey||actionKey==easeKey||reelKey==easeKey){toggleKey=VK_F6;actionKey='E';reelKey='R';easeKey='Q';log("Duplicate bindings: restored F6/E/R/Q");}
 toggleName=keyName(toggleKey);actionName=keyName(actionKey);reelName=keyName(reelKey);easeName=keyName(easeKey);
 game.biteWindow=std::clamp(GetPrivateProfileIntA("Fishing","BiteWindowSeconds",6,iniPath.c_str())*1.f,3.f,20.f);
 game.catches=GetPrivateProfileIntA("Progress","Catches",0,iniPath.c_str());savedCatches=game.catches;game.seed=GetTickCount();
 log("v0.1.76 loaded. Toggle=%s action=%s reel=%s ease=%s visuals=%d biteWindow=%.1f",toggleName.c_str(),actionName.c_str(),reelName.c_str(),easeName.c_str(),int(visuals),game.biteWindow);
 log("HUD enabled=%d textHeight=%.3f (fraction of screen height)",int(hudEnabled),hudTextHeight);
 log("Fish model=%s (pivot anchor; mouth alignment unverified)",fishModel.empty()?"disabled":fishModel.c_str());
 reelAudio.seed=uint32_t(GetTickCount64())^GetCurrentProcessId()^0x9e3779b9u;
 waterAudio.seed=uint32_t(GetTickCount64())^0x6a09e667u;
 reelAudio.fixed=-1;
 log("Reel: MENU_INITPARAMS fixed relative gain0dB; game/system/speaker volume unchanged");
 for(const auto& clip:fishing::reelClips)log("Reel clip: sample=0x%08X event=%s",unsigned(clip.sample),clip.event);
 float previous=rh::invoke<0x5842B9D1,float>();
 rh::help("Fishing v0.1.76 loaded. Stand on shore. Default toggle: F6.");
 while(true){
  rh::wait(0);
  float now=rh::invoke<0x5842B9D1,float>();float dt=std::clamp(now-previous,0.f,.1f);previous=now;
  DWORD foregroundPid=0;
  GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);
  bool toggleEdge=toggleButton.sample((GetAsyncKeyState(toggleKey)&0x8000)!=0);
  bool actionDown=(GetAsyncKeyState(actionKey)&0x8000)!=0;
  bool actionEdge=actionButton.sample(actionDown);
  if(foregroundPid!=GetCurrentProcessId()||rh::invoke<0x57246C02,bool>()){reelAudio.stop(gameReelAudio);reelMenuAudio.reset();castSound.update(0,gameReelAudio);waterAudio.stop(gameWaterAudio);continue;}
  int a=rh::player();bool alive=rh::validActor(a)&&!rh::invoke<0x0D798FFE,bool>(a);
  if(game.phase!=fishing::Phase::Off&&(!alive||!rh::invoke<0x63D6551C,bool>(a))){cleanup();game.enter(fishing::Phase::Off);log("Stopped: player unavailable or not on foot");}
  if(toggleEdge){
   if(game.phase!=fishing::Phase::Off){cleanup();game.enter(fishing::Phase::Off);rh::help("Fishing stopped. Safe to unload Fishing.red.");log("Stopped by player");}
   else if(alive&&rh::invoke<0x63D6551C,bool>(a)){
    origin=rh::position(a);float h=rh::invoke<0x42DE39F0,float>(a)*.01745329252f;forward={std::sin(h),0,std::cos(h)};updateCastDirection();game.enter(fishing::Phase::Ready);findHandBone(a);requestProps();requestCastAnimSet();requestFightAnimSet();log("Enabled at %.3f %.3f %.3f heading %.3f",origin.x,origin.y,origin.z,h);
   }
  }
  if(game.phase==fishing::Phase::Off){reelAudio.stop(gameReelAudio);reelMenuAudio.reset();castSound.update(0,gameReelAudio);waterAudio.stop(gameWaterAudio);continue;}
  auto pos=rh::position(a);float dx=pos.x-origin.x,dz=pos.z-origin.z;
  if(dx*dx+dz*dz>4){cleanup();game.enter(fishing::Phase::Off);rh::help("Fishing stopped: moved away from casting spot.");log("Stopped: player moved");continue;}
  noticeTime=std::max(0.f,noticeTime-dt);
  auto old=game.phase;
  if(actionEdge&&old==fishing::Phase::Ready){
   castSound.reset(gameReelAudio);
   origin=rh::position(a);hasWaterTarget=false;castTurn.reset();tackleMotion.prepare();
   castCharge.begin();castFlightReleased=false;noticeTime=0;
   log("Cast charge begun: free camera while holding %s; capture target on release",actionName.c_str());
  }
  if(castCharge.active){
   bool releaseEdge=castCharge.observe(actionDown);
   if(!castCharge.released)updateCastDirection(); // live view bearing, no committed water target
   if(releaseEdge){
    if(!prepareCast(a)){
     stopCastAnimation();castCharge.reset();castFlightReleased=false;hasWaterTarget=false;
     game.enter(fishing::Phase::Ready);actionEdge=false;
     log("Cast release cancelled: no valid camera/water target; returned to Ready");
    }else if(!castAnimationEnabled){
     castCharge.reset();castFlightReleased=true;game.elapsed=0;tackleMotion.beginFlight();
    }
   }
  }
  if(actionEdge)log("Action pressed in %s at %.2f s%s",stateName(old),game.elapsed,old==fishing::Phase::Wait?" (waiting for bite; ignored)":"");
  bool reeling=(GetAsyncKeyState(reelKey)&0x8000)!=0;
  bool easing=(GetAsyncKeyState(easeKey)&0x8000)!=0;
  game.update(fishing::castGameStep(old==fishing::Phase::Cast,castFlightReleased,dt),{actionEdge,reeling,easing});
  fightMotion.update(game.phase==fishing::Phase::Fight,fishing::fishPulling(game.elapsed),dt,game.elapsed);
  auto waterCue=waterTriggers.update(game.phase,castFlightReleased,game.elapsed);
  if(waterCue!=fishing::WaterCue::None){
   gameWaterAudio.position=waterCue==fishing::WaterCue::Landing?geom(waterTarget):
    waterCue==fishing::WaterCue::Caught||!hasWaterTarget?geom(rh::position(a)):geom(bobberPosition);
   bool requested=waterAudio.play(waterCue,gameWaterAudio);
   log("Water sound: situation=%d sample=0x%08X channel=%d gainDb=%.1f requested=%d reason=%s",int(waterCue),unsigned(waterAudio.lastSample),waterAudio.sound[int(waterCue)],fishing::waterGainDb(waterAudio.lastSample),int(requested),gameWaterAudio.reason);
  }
  uint64_t reelPlaysBefore=reelMenuAudio.playCount;
  bool reelWanted=fishing::reelSoundWanted(game.phase==fishing::Phase::Fight,reeling,easing,true,false);
  reelMenuAudio.updateWithPick(reelWanted,dt,[](){return reelAudio.choose();},gameReelAudio);
  if(reelMenuAudio.playCount!=reelPlaysBefore)
   log("Reel click: sample=0x%08X mode=MENU_INITPARAMS gainDb=0",unsigned(fishing::reelClips[reelAudio.selected].sample));
  audioTestLogAge+=dt;
  if(audioTestLogAge>=.5f&&game.phase==fishing::Phase::Fight){
   audioTestLogAge=0;
   log("Audio coexistence: mode=MENU_INITPARAMS R=%d Q=%d wanted=%d struggleID=%d",int(reeling),int(easing),int(reelWanted),waterAudio.sound[1]);
  }
  if(old!=game.phase){
   if(game.phase==fishing::Phase::Cast){
    fishScaleLogTime=2;
    log("Fish roll: weight=%.2fkg category=%s scale=%.1fx",game.weight,game.weight<1?"small":game.weight<=5?"normal":"large",fishing::fishScaleForWeight(game.weight));
   }
   log("State %s -> %s (wait=%.2f tension=%.2f progress=%.2f)",stateName(old),stateName(game.phase),game.wait,game.tension,game.progress);
   if(game.phase==fishing::Phase::Bite)log("BITE: press %s within %.1f seconds",actionName.c_str(),game.biteWindow);
   if(old==fishing::Phase::Bite&&game.phase==fishing::Phase::Lost)log("Missed bite: no new Action press during bite window");
  }
  if(game.catches!=savedCatches)save();
  if(!fightPose.owned&&(fightPose.stage==fishing::FightPose::Stage::Idle||!fightPoseEnabled))updateCastAnimation(a,dt);
  updateFightPose(a,dt);
  if(game.phase==fishing::Phase::Cast&&castFlightReleased&&!castSound.played){
   bool started=castSound.launch(gameReelAudio);
   log("Cast throw sound: event=%s requested=%d",fishing::castWhooshEvent,int(started));
  }
  castSound.update(dt,gameReelAudio);
  waterAudio.update(dt,gameWaterAudio);
  updateProps(dt,a);hud();
 }
}
BOOL WINAPI DllMain(HMODULE m,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH){module=m;DisableThreadLibraryCalls(m);if(!rh::bind())return FALSE;rh::reg(m,script);}
 else if(reason==DLL_PROCESS_DETACH&&rh::unreg)rh::unreg(m);
 return TRUE;
}
