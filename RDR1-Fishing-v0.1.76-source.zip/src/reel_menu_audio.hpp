#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace fishing {
// Native one-shot menu path, independent of persistent IDs/HAS_SOUND_FINISHED.
struct ReelMenuAudio {
 bool active=false;float elapsed=0;uint64_t playCount=0;
 void reset(){active=false;elapsed=0;}
 void prime(){active=true;elapsed=0;}
 bool due(bool wanted,float dt){
  if(!wanted||!std::isfinite(dt)||dt<=0){reset();return false;}
  if(active){elapsed+=std::min(dt,.1f);if(elapsed<.16f)return false;}
  prime();return true;
 }
 template<class Pick,class Audio> void updateWithPick(bool wanted,float dt,Pick pick,Audio& audio){
  if(due(wanted,dt)){audio.oneShot(pick());++playCount;}
 }
 template<class Audio> void update(bool wanted,float dt,const char* event,Audio& audio){
  if(due(wanted,dt)){audio.oneShot(event);++playCount;}
 }
};
}
