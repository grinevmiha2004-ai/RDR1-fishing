#pragma once
#include "redhook.hpp"
#include "reel_menu_params.hpp"
namespace fishing {
struct GameReelAudio {
 void oneShot(const char* event){
  ReelMenuParams params{};
  rh::invoke<0x49053A94>(event,&params);
 }
 int allocate(){return rh::invoke<0x6AE0AD56,int>();}
 void play(int id,const char* event){rh::invoke<0xB157BBB4>(id,event);}
 bool finished(int id){return rh::invoke<0xE85AEC2E,bool>(id);}
 void stop(int id){rh::invoke<0xCD7F4030>(id);}
 void release(int id){rh::invoke<0x9C080899>(id);}
};
}
