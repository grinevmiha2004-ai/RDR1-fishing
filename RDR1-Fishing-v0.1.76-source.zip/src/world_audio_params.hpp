#pragma once
#include <array>
#include <cstdint>
#include <cstring>
#include "visuals.hpp"
namespace fishing {
// Exact112-byte parameter layout used by RDR.exe E33D40 (positional owned sound).
struct alignas(16) WorldAudioParams {
 std::array<unsigned char,112> bytes{};
 template<class T> void put(size_t offset,T value){std::memcpy(bytes.data()+offset,&value,sizeof(value));}
 WorldAudioParams(const Point* position,float gainDb){
  put(0,gainDb);put(4,uint32_t(0xffff0000));put(8,1.f);
  put(0x20,position);put(0x60,int32_t(-1));
  put(0x64,23900.f);put(0x68,-20.f);put(0x6c,uint32_t(0x200000ff));
 }
};
inline float waterGainDb(uint32_t sample){return sample==0x008CE18D?-6.f:0.f;}
}
