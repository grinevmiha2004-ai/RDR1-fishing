"""Check provided EXE's explicit MENU gain ABI (no game execution).
Usage: python3 tools/verify_menu_gain.py RDR.exe
"""
from pathlib import Path
import hashlib,struct,sys
b=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(b).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
nt=struct.unpack_from('<I',b,0x3c)[0];n=struct.unpack_from('<H',b,nt+6)[0];opt=struct.unpack_from('<H',b,nt+20)[0]
def at(rva,size):
 for i in range(n):
  _,start,length,raw=struct.unpack_from('<4I',b,nt+24+opt+i*40+8)
  if start<=rva and rva+size<=start+length:return b[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
assert at(0xe33943,7)==bytes.fromhex('488b48084c8b00') # input params pointer slot1, event string slot0
assert at(0xe3395b,4)==bytes.fromhex('f30f1001') # explicit relative gain float0
assert at(0xe33972,6)==bytes.fromhex('f30f11442420') # passed to engine audio init block
assert at(0xe338a0,4)==bytes.fromhex('f30f5cc2') # ordinary MENU subtracts1 from contextual scalar
assert at(0xe338da,6)==bytes.fromhex('f30f11442420') # ordinary MENU passes context-derived gain
assert struct.unpack('<f',at(0x1d628dc,4))[0]==45
print('PASS: explicit MENU gain ABI differs from ordinary context-derived gain path')
