"""Check provided EXE's owned positional audio ABI (no game execution).
Usage: python3 tools/verify_world_audio.py RDR.exe
"""
from pathlib import Path
import hashlib,struct,sys
b=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(b).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
nt=struct.unpack_from('<I',b,0x3c)[0];n=struct.unpack_from('<H',b,nt+6)[0];opt=struct.unpack_from('<H',b,nt+20)[0]
def at(rva,size):
 for i in range(n):
  _,start,length,raw=struct.unpack_from('<4I',b,nt+24+opt+i*40+8)
  if start<=rva and rva+size<=start+length:return b[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
import re
header=(Path(__file__).resolve().parents[1]/'src/water_audio_runtime.hpp').read_text()
checks=re.findall(r'matches\(base\+0x([0-9a-f]+),std::array<unsigned char,(\d+)>\{([^}]+)\}',header)
assert len(checks)==3
for offset,length,values in checks:
 expected=bytes(int(x,16) for x in values.split(','))
 assert len(expected)==int(length) and at(int(offset,16),len(expected))==expected
assert at(0xe33e04,4)==bytes.fromhex('48894507') # position pointer in native112byte block at+20
assert at(0xe3395b,4)==bytes.fromhex('f30f1001') # native INITPARAMS reads gain float at0
assert struct.unpack('<f',at(0x1d62460,4))[0]==1
assert struct.unpack('<f',at(0x1d62c24,4))[0]==23900
assert struct.unpack('<f',at(0x1d62f28,4))[0]==-20
print('PASS: world audio function fingerprints, position/gain fields and default constants')
