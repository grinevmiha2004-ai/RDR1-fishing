# Lasso clip audit for 0.1.26

Inputs: supplied animationres.rpf, decompressed lso.was and default_character.wat.
Exact input fingerprints are checked by tools/audit_lasso_clips.py.
No game animation data is shipped with the mod.

| API clip suffix (prefix nor_lso_) | Authored WAT assignment | Decision |
| --- | --- | --- |
| stn_mid_trw_pre | ThrowStand 0xA9340, track 0x19E5A0 | Removed from runtime per user request |
| stn_mid_trw_mid | ThrowMid 0xA9540, track 0x92B48 | Only active cast clip |
| stn_mid_trw_suc | Outcome node 0xAD380, track 0x9904C | Not substituted for forward throw |
| stn_mid_trw_fal | Outcome node 0xABD00, track 0x94F24 | Not substituted for forward throw |
| stn_aup_mid_trw_pre | Alternate standing branch, node 0xACC80/0xAB9C0 | Still a preparation; not substituted |
| stn_aup_mid_trw_fal | Outcome node 0xABC00 | Not substituted |
| run_mid_trw_pre/mid/fal | Moving branches, including 0xB5F80/0xB6000/0xAC100 | Not substituted for standing cast |
| wlk_mid_trw | String found in WAS; no selected WAT task reference in this audit | Not substituted based on a name alone |

The authored assignments plus the user's observations identify which currently
played parts to keep/remove. They do not amount to rendering every alternative
clip or proving that a lasso pose is the final desired fishing pose.
The main clip's observed native duration is approximately 1.07 seconds at rate 1.
The latest uploaded log includes previous 0.1.24 runs followed by 0.1.25 runs;
only the latter are evidence about 0.1.25 timing. Typical main samples reach
0.96-0.99 then disappear. One latest-session main request never starts.

0.1.26 emits a single Release command immediately when preparation/binding is
ready. There is no Windup stage or command. Historical clip constants remain in
the header solely for the older static WAT hierarchy checker; the compiled DLL
is checked to contain no pre clip string.
Completion diagnosis uses maximum observed normalized time. Only loss after
>=0.95 counts as Completed; earlier loss is Interrupted; no match is Missing;
a persistent match beyond the guard limit is Watchdog. This makes a naturally
short clip distinguishable from plugin cancellation or a failed request.

Run the read-only audit:

```sh
python3 tools/audit_lasso_clips.py /path/to/decompressed/lso.was /path/to/decompressed/default_character.wat
```
