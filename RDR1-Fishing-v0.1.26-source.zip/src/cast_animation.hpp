#pragma once
#include <algorithm>
#include "cast_playback.hpp"
namespace fishing {
// Historical catalog references for static WAT verification only; windup is never requested.
inline constexpr const char* castWindupClip="nor_lso_stn_mid_trw_pre";
inline constexpr const char* castWindupNode="default_character_Main\\Gunplay\\THROWING\\Lasso\\LassoNor\\ThrowStand";
inline constexpr const char* castReleaseClip="nor_lso_stn_mid_trw_mid";
inline constexpr const char* castReleaseNode="default_character_Main\\Gunplay\\THROWING\\Lasso\\LassoNor\\ThrowStand\\ThrowMid";
inline float castGameStep(bool casting,bool flightReleased,float dt){return casting&&!flightReleased?0.f:dt;}
enum class CastAnimCommand {None,Release,Stop};
enum class CastEnd {None,Completed,Missing,Interrupted,Watchdog,Cancelled};
inline const char* castEndName(CastEnd reason){
 switch(reason){
 case CastEnd::Completed:return "completed";
 case CastEnd::Missing:return "not_started";
 case CastEnd::Interrupted:return "interrupted";
 case CastEnd::Watchdog:return "watchdog";
 case CastEnd::Cancelled:return "cancelled";
 default:return "none";
 }
}
struct CastAnimation {
 enum class Stage {Idle,Release,BlendOut,Finished};
 Stage stage=Stage::Idle;
 CastEnd end=CastEnd::None;
 float elapsed=0,maxTime=-1;
 bool seenPlaying=false;
 CastAnimCommand update(bool casting,bool allowed,float dt,bool playing,float time){
  if(!allowed){
   bool active=stage==Stage::Release||stage==Stage::BlendOut;
   reset();end=CastEnd::Cancelled;return active?CastAnimCommand::Stop:CastAnimCommand::None;
  }
  if(stage==Stage::Finished){if(!casting)reset();return CastAnimCommand::None;}
  if(stage==Stage::Idle){
   if(!casting)return CastAnimCommand::None;
   stage=Stage::Release;elapsed=0;seenPlaying=false;maxTime=-1;end=CastEnd::None;
   return CastAnimCommand::Release;
  }
  elapsed+=std::clamp(dt,0.f,.1f);
  if(stage==Stage::BlendOut){
   if(elapsed<castBlendOut)return CastAnimCommand::None;
   stage=Stage::Finished;return CastAnimCommand::Stop;
  }
  if(playing){seenPlaying=true;if(std::isfinite(time)&&time>=0)maxTime=std::max(maxTime,time);}
  if(seenPlaying&&!playing&&elapsed>=.05f)end=maxTime>=.95f?CastEnd::Completed:CastEnd::Interrupted;
  else if(!seenPlaying&&elapsed>=1.f)end=CastEnd::Missing;
  else if(elapsed>=1.8f)end=CastEnd::Watchdog;
  if(end==CastEnd::None)return CastAnimCommand::None;
  stage=Stage::BlendOut;elapsed=0;return CastAnimCommand::None;
 }
 void reset(){stage=Stage::Idle;end=CastEnd::None;elapsed=0;maxTime=-1;seenPlaying=false;}
};
}
