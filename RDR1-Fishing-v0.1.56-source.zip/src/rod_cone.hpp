#pragma once
#include "visuals.hpp"
namespace fishing {
struct RodCone {
 float blend=0;
 void reset(){blend=0;}
 Point rotation(bool spinning,float dt,float angle,float normalPitch,float heading){
  constexpr float rad=.01745329252f,deg=57.295779513f;
  float step=std::isfinite(dt)?std::clamp(dt,0.f,.1f)/.35f:0.f;
  blend=std::clamp(blend+(spinning?step:-step),0.f,1.f);
  float tiltedPitch=normalPitch-8.f;
  if(blend==0)return {tiltedPitch,heading,0};
  // Rotate the inclined shaft ABOUT WORLD UP, rather than wobbling around
  // a fixed forward lean. Its tip sweeps a horizontal circle about the grip.
  float radius=std::sin(40.f*rad),height=std::cos(40.f*rad);
  float x=-radius*std::sin(angle)*blend;
  float z=std::sin(tiltedPitch*rad)*(1-blend)-radius*std::cos(angle)*blend;
  float y=std::cos(tiltedPitch*rad)*(1-blend)+height*blend;
  float horizontal=std::hypot(x,z);
  // Interpolate shaft directions, not wrapped yaw angles, during entry/exit.
  float yaw=horizontal>.000001f?std::atan2(-x,-z)*deg:0.f;
  return {-std::atan2(horizontal,y)*deg,heading+yaw,0};
 }
};
}
