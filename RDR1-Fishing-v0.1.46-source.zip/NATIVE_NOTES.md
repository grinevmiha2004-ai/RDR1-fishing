# Native-call evidence (RDR.exe supplied by user)

Executable SHA256: 22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e.
Static analysis only; no claim of runtime validation for the new calls.

- `SET_OBJECT_POSITION`, hash C5D796F8: handler VA 0x14022F920 reads the object
  handle at argument slot 0, packed XY at slot 1, and Z at slot 2. The SDK signature
  and our existing packing agree; motion failure must be diagnosed through the
  boolean return and `GET_OBJECT_POSITION`, rather than assuming a packing defect.
- `SET_OBJECT_ORIENTATION`, hash C8A4EE74: handler VA 0x1402308D0 reads the same
  packed vector pattern and applies a degrees-to-radians conversion before dispatch.
- `FIND_WATER_INTERSECTION`, hash 4F193BE4: registration points to VA 0x1402965D0.
  It reads two packed vectors from argument slots 0/1 and 2/3, then vector output
  pointers from slots 4 and 5. It invokes the intersection routine at 0x140295DC0
  with the water collision mask 0x400000 and writes a boolean result. The adapter
  supplies two initialized, aligned vector outputs and two trailing zero arguments
  for the SDK's placeholder arity. Output position is validated before use.
- `WORLD_TO_SCREEN`, hash BAA72911: supplied by RedHook v0.8, not base game.
  Handler VA 0x180024780 in supplied RedHook.dll reads a position pointer and two
  float output pointers. It returns false for points outside the view; successful
  outputs are normalized screen coordinates. Used only for visual markers.
- `GET_OBJECT_NAMED_BONE_POSITION`, hash 30516389, and `GET_OBJECT_FROM_ACTOR`,
  hash 4A2063EC: typed signatures from the supplied SDK. Bone names are probed
  and validated by proximity; a body-relative fallback is used when unavailable.

No unknown animator or lasso task parameters were guessed in this release.
Player animation and WAS/WAT playback remain unfinished.

## v0.1.13 attachment and cast direction

- GET_CAMERA_CHANNEL_DIRECTION (6ED00237), handler 0x1403AAEF0:
  output vector pointer at slot 0, channel at slot 1; channel zero supported.
  Returns negated camera backward basis, the actual forward view direction.
- GET_HEADING uses atan2(actor +Z basis X, actor +Z basis Z) at 0x140AD4AB0.
  Old -sin(heading) reflected X incorrectly. The cast now uses the view vector
  directly, and yaw reconstruction uses atan2(X,Z).
- ATTACH_OBJECTS (E1421B42), handler 0x140230E80 and helper 0x1402DA4D0:
  child object, parent object, parent bone name, offset XY, offset Z,
  rotation XY (degrees), rotation Z, integer flags. 8 slots, not SDK's 10 ints.
  Parent bone resolved by helper 0x1402F2400. Child is object whose attachment
  field gets assigned at 0x1402DA8AA.
- SET_ATTACHMENT_IGNORE_ROTATION (A870B28E) writes attachment byte +0x62.
  Update 0x1402DAA5C copies existing child basis and applies only translation
  when this flag is set. This retains procedural rod rotation while binding
  the pivot to the animated hand. No finger/arm animation is claimed.
- Cleanup removes only this plugin's saved attachment before deleting the rod.

Static disassembly evidence only; in-game validation remains necessary.

## v0.1.14 live actor bone discovery

The user's 0.1.13 log contains repeated Hand bone not found and no created rod
attachment. Do not interpret that run as successful attachment validation.

GET_OBJECT_FROM_ACTOR at 0x14022BA90 is identity, returning the actor handle.
GET_OBJECT_NAMED_BONE_POSITION at 0x140230A90 resolves the handle through
RVA 0x2C36778 (16-byte records with generation at +8) and calls the object's
vtable +0x100 getter with true. Returned pose +8 is the skeleton descriptor.
Helper 0x1402D9D10 obtains the bone count at descriptor +0x30 (uint16),
and compares C-string names at the first pointer in each 0x110-byte descriptor
record through descriptor +0. This exact read-only path is used to enumerate
actual actor bone names instead of assuming animation semantic labels match.

Private offsets are gated by the supplied executable's PE timestamp 6711591D,
SizeOfImage 5A5DD600, AMD64 PE32+, and two handler fingerprints. Pointer reads
use ReadProcessMemory; counts and string lengths are bounded. The one pose
getter call has the same ABI and argument as the existing native. There are no
writes or patches to game memory. This is static ABI evidence, not a game run.

## v0.1.15 wrist_r and camera independence

The user's v0.1.14 log confirms successful live skeleton enumeration, including
wrist_r, wristroll_r and wrist_r_Attachment. Our name filter rejected wrist_r.
Use wrist_r first via the existing named-bone native and native attachment.
The classifier accepts wrist_r but rejects wristroll_r and wrist_r_Attachment.
Rod yaw now uses actor heading, not saved camera/cast direction; idle props and
fallback hand/tip positions use actor coordinates. Camera direction is sampled
only for enabling/actual cast targeting and never drives held rod yaw.
The native attachment retains procedural world rotation while following wrist
translation. Finger grip and bone-relative rod rotation are not implemented.

## v0.1.16 non-colliding held rod

User log: wrist_r resolves, attachment valid=1, Rod hand check coordinates match.
Fishing then ends with Stopped: player moved. User observes rod pushes John.

SET_OBJECT_COLLIDE_WITH_WORLD (601FC9F4), handler 0x1402331F0, reads object
slot 0 and boolean slot 1. False sets bit 0x2 in prop flags +0x1C.
SET_OBJECT_COLLIDE_WITH_MOVABLES (05D69EA6), handler 0x140233230, same ABI;
false sets bit 0x4. Both resolve the prop through helper 0x1402201D0.
Set both false immediately after spawning the rod, before any ScriptWait,
and reapply after attachment initialization. Scope is the rod object only.
Do not disable actor collision or remove the existing movement cancellation.
No in-game collision-free result is claimed until user validation.

## v0.1.17 fish orientation regression

User confirms v0.1.16 rod is attached to hand without collision, but fish is
again tail-first. Reverse only fish yaw by 180 degrees: cast bearing -90
instead of +90. Keep wrist_r, rod collision flags and camera casting untouched.
Do not treat Linux tests as in-game validation of this direction.

## v0.1.18 cast animation evidence and limits

User confirmed v0.1.17 fish retrieval/orientation works; preserve that baseline.
Supplied act.rpf SHA256:
e4e9f8f7cf4f4eafa79271476d47572c2fa9e30bcf566f4846b23d713670c955.
RPF6: 1035 entries, encrypted TOC; parsed per Magic-RDR commit
bc2b939b5f53de81450391fe834d2e35f97a982a. default_character.wat is resource
entry 13 at archive offset 0x22A000, compressed entry size 567576 bytes.
The resource's Zstandard payload decodes to 3186688 bytes, SHA256:
1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1.
ASCII clips nor_lso_stn_mid_trw_pre occur at 0x23F690, 0x23FB58;
nor_lso_stn_mid_trw_mid at 0x23DEE8, 0x23DF78 and other references.
Normal standing clips selected; horse and crouch variants deliberately omitted.
No game archive, animation binary or encryption material is shipped in the mod.

TASK_PLAY_ANIM (5AB552C6), handler 0x140C1AB30:
slot0 actor, slot1 const char* clip (<64 bytes); slots2/3/4 float;
slot5 int (MOV, not MOVSS, at 0x140C1ABEA); slots6/7 boolean;
slot8 float (MOVSS 0x140C1ABDD). SDK misdeclares slots5/8.
Task fields +4C/+50/+54/+58/+5C/+5D/+48 flow through 0x140B3B450
to 0x140CDE6F0. The clip lookup at 0x140CE7AF0 uses the actor's animation
component and actual clip name. Use existing loaded player animation data;
do not replace the player's default action tree or grant/equip a real lasso.
IS_ACTOR_ANIM_PLAYING (1ADE21EB) queries the selected clip by actor/name.
TASK_CLEAR (16876A25) releases the short requested task at Cast exit or cleanup,
including when a missing clip leaves the request pending.

Initial scalar values are .1, .1, 0, integer layer 0, false, false, float 1.
Scalar types/data flow are verified; visual meanings/tuning and playback are
not established by static inspection alone. Stage at 0 and .35s, cleanup on
Cast exit (1.1s) / F6 / player unavailable. Do not claim animation works from
request logs; look for Cast animation PLAYING. Tests cover one-shot staging,
cancellation, reset and real Game transitions; they do not execute RDR natives.

## v0.1.19 native action-tree cast route

User's v0.1.18 log: two cast attempts, TASK_PLAY_ANIM requests issued,
no PLAYING confirmation for either clip. This proves non-playback, not why the
queue/clip path failed. Replace that route with explicit existing action nodes.

Recovered root from WAT +8 -> 0xA7070; node parent +4, children pointer +8,
child count uint16 +0xC, local name JOAAT hash +0x20. Traverse actual links:
default_character_Main BD701184 (root 0xA7070)
Gunplay 18E67533 (0xB4340)
THROWING 38D89C16 (0x11AEC0)
Lasso 2A083060 (0xA91C0)
LassoNor 29483E1E (0xA92C0)
ThrowStand 46160C03 (0xA9340)
ThrowMid 044EFD54 (0xA9540).
LassoNor selects normal standing, rather than LassoCrouch (6D8A9E41),
LassoAim (7A7EA5CC), Gunplay_AI (F6AD55F0), horse or cover branches.
Animation expression 0x19E5A0 references nor_lso_stn_mid_trw_pre and attaches
to ThrowStand; expression 0x92B48 references nor_lso_stn_mid_trw_mid and
attaches to ThrowMid. Parent-child hierarchy is verified from the shipped
source header constants by tools/verify_cast_action_tree.py on decompressed WAT.

SET_ACTION_NODE_FOR_ACTOR 5A795F3A -> handler 0x140CE0CE0 -> helper
0x140CDFA20. Actor and string, returns boolean. Helper prepends Global\%s,
so pass default_character_Main\Gunplay\THROWING\Lasso\LassoNor\ThrowStand
WITHOUT an additional Global prefix. Parser 0x14058FA70 accepts both slash
and backslash (delimiter bytes at VA 0x141CBF0E0 are "\\/\0").
IS_ACTOR_PLAYING_NODE_IN_TREE 4E0300E2 -> helper 0x140CDF940 looks up same
path and walks active node's parent links. This confirms activation separately
from IS_ACTOR_ANIM_PLAYING clip playback. RESET_ACTIONTREE_FOR_ACTOR
07EC142B -> 0x140CE0D70 restores actor default processing. Call only if our
node override was accepted, on Cast exit or cleanup. No TASK_CLEAR is used.

Timing remains initial integration tuning. Direct action nodes have not been
run in the game here; neither accepted nor Linux tests establish visible motion.

## v0.1.22 return to observed v0.1.19 node route

0.1.21 log: loaded=0 for both names, never bound/activated a node. Do not treat
that as evidence against the action-node route: it did not execute at all.
User reports a brief visible twitch in 0.1.19. Return to that exact verified
WAT path without separate animset requests or private direct-play calls.

Hypothesis tested: ordinary player control interrupts the scripted node.
IS_PLAYER_CONTROLLABLE 9613C2D0 -> 0x140AD7100 inspects the player's control
mask and state. SET_PLAYER_CONTROL D17AFCD8 -> 0x140AD6F60 reads enable at
slot1 and integer flags at slots2/3. With 0,0 it sets/clears only the script bit
(bit0 of controller +0x104), preserving other disable mask bits. Use
(0,false,0,0) only if initially controllable; matching true restores that bit.
Restoration is outside actor-valid checks, so death/cancellation cannot skip it.
F6 uses GetAsyncKeyState independently. Player controls remain disabled only
for this bounded sequence; closing the game before replacing/unloading the
plugin remains required. Other mods/scripts changing control concurrently
cannot be distinguished by this native bit alone.

Retain completion-feedback state machine from 0.1.20, not the early hard
.35/1.1 cutoffs of 0.1.19. At most 3.2s total with confirmed looping clips;
1.8s total for entirely unconfirmed clips. F6/death/movement cancel immediately.
Log live node activity/time every .1s and on changes, not just first ACTIVE.
Do not force-restart a node every frame, which would itself prevent progress.
Portable tests verify control ownership/restoration and bounded animation flow.
Visible playback still requires game validation; ordinary-control interruption
remains a hypothesis until new runtime samples confirm it.

## v0.1.23 verified lso set and standalone scripted playback

User-supplied animationres.rpf SHA256:
b4baf2dc9f28efa31f293983d1101fa00d33e29690b7f2b3c7a5dacb681e9dd7.
RPF6 has 1345 WAS resources. Entry 452 lso.was contains both standing cast clips.
Its decompressed payload is 598016 bytes, SHA256
7975b6f7294d192f2ecdea03b78d5293ac25566717b06fd762cbdb57da84075f.
Header name lso.ast at +0x38; clip strings at 0x6EB90 (pre), 0x6E9D8 (mid);
JOAAT hashes F6A844F3 and CC863451 are present in the resource.
Entry 1117 lso_base.was does not contain either literal cast clip.
No WAS/WAT, game EXE, archive key, or other game asset is redistributed.

ThrowMid WAT 0xA9540 has transition track 0x1C3420 to root 0xA7070.
Condition array 0x2ED420: NOT operand 1 at 0x1B1FFC, then WeaponAnimSet
type 224, enum 8 LASSO, flags 0 at 0x305FC0. Other exits use LassoState
(type 137): ATTACHED/TUG_WAR and FAIL_ATTACH/UNATTACHED.
Registry 0x140592B00 installs 12 base conditions; 0x140CA2D90 adds game conditions.
Game index 212 + 12 = WeaponAnimSet 224; index 125 + 12 = LassoState 137.
Weapon enum strings at VA 0x142293360, LASSO at index 8.
Evaluator 0x140D98420 checks actual current weapon type, not requested clip name.
This is a static immediate-exit mechanism; no claim of observing the exact taken
branch in the user's live run is made. Do not force-restart these nodes.

REQUEST_ANIM_SET (2988B3FC): const char* name, integer flag; handler 0x140CE0600.
HAS_ANIM_SET_LOADED (4FFF397D): name; handler 0x140CE0640 checks loaded resource.
SET_ANIM_SET_FOR_ACTOR (39C1E1C0): actor handle, const char* name, integer flag.
Handler 0x140CE06C0 resolves the actor, resource, then calls 0x140CE8D30.
Flag 0 respects an existing script lock at animation component +0xC6A.
The public API stores the override at +0x9A8 and sets the lock.
ACTOR_HAS_ANIM_SET (31F5F57D), handler 0x140CE0160, compares the current
override resource's name against the argument.
RESET_ANIM_SET_FOR_ACTOR (7A6C5C2F), handler 0x140CE0800, clears +0x9A8
and +0xC6A and refreshes the normal action tree. Flag 1 avoids the full
animator-reset branch selected by flag 0; it still restores normal tree processing.
REMOVE_ANIM_SET (D04A817A): name, balances the plugin streaming request on F6/cleanup.

Ownership reads only: wrapper table at module+0x2C36778 -> wrapper+b0 internal
actor handle -> table module+0x2C36768 -> actor+0x38 animation component.
Read +0x9A8 and +0xC6A only, through ReadProcessMemory, with handle generations,
PE profile and ACTOR_HAS_ANIM_SET instruction fingerprint checks.
Do not overwrite any pre-existing override. Remember our resource identity;
cleanup only clears our task/override if identity still matches and native
ACTOR_HAS_ANIM_SET confirms lso. No engine-memory patches or private engine calls.

TASK_PLAY_ANIM parameters keep the already verified ABI from 0.1.18:
(actor, clip, float .1, float .1, float 0, int 0, bool false, bool false, float 1).
This time clip resolution can search the attached, verified lso set through
0x140CE7AF0, instead of relying on the actor having it from a weapon.
The native's queued task is cleared with TASK_CLEAR (16876A25) during owned
cleanup. Actor controls are scoped as before.
Tests cover delayed streaming across Cast->Wait, cancellation before binding,
binding rejection without repeated retry, bounded timeouts and paused time,
in addition to previous animation and gameplay tests.
Static validation and compilation do not establish visible animation success.

## v0.1.24 zero-rate regression in TASK_PLAY_ANIM

User's v0.1.23 Fishing.log: 139 samples, 111 with playing=1 and clipTime=0.0000;
28 with playing=0 and clipTime=-1. No sample has positive clip time.
setAttached=1 and successful bind prove lso was attached; these observations
do not prove visible animation.

The v0.1.23 scalar values were wrong, despite their ABI types being correct.
Zero-based native slot 4 is a playback-rate multiplier, not an unused scalar:
0x140C1ABF5 loads [native args+0x20] into xmm7; 0x140C1AC58 stores xmm7 to
queued task+0x54. Task update 0x140B3B493 loads task+0x54; 0x140B3B4AE
passes it in stack slot +0x28 to 0x140CDE6F0. That function's prologue
relocates it to rsp+0x108. 0x140CDEAA9 loads it, then 0x140CDEAB2
multiplies by actor animation component+0xA10. 0x140CDEBB3 stores the
result in the scripted clip playback state+0x48. Therefore the supplied zero
zeroes the playback-rate field. Native clip-time query uses state+0x38 divided
by duration at 0x140CEFD9A..0x140CEFDA2. Zero playback rate explains the log's
stationary time even when the selected clip matches.

Native slot 8 is separate: task+0x48 -> caller stack+0x48 -> callee rsp+0x128
-> actor animation component+0xA94 at 0x140CDED3D..0x140CDED56.
The update at 0x140CEFB95 tests this timer against zero; when positive it
subtracts actor frame time at 0x140CEFBB1 and triggers completion once elapsed.
Negative disables this optional timer, as in the engine's own -1 initialization.
Use slot4=float 1, slot8=float -1. Integer layer and boolean arguments retain
the already verified types. No repeated native requests or forced clock writes.

Named, typed requestCastClip helper is shared by plugin and portable tests.
Tests capture the actual submitted arguments and reject a zero rate/wrong ABI;
progress detection is checked against the user's repeated-zero sample pattern.
Diagnostics now say MATCHED for pointer/name selection; ADVANCING requires
an increase between two valid native time readings. This is stronger evidence
than playing=1, but still does not prove the visible pose without a game run.
No changes to rig, collisions, camera direction, fish yaw, input bindings or INI.

## v0.1.25 synchronization and native exit blending

User's v0.1.24 log includes 14 casts. Main standing throw advances in 13,
with most complete attempts ending at sampled normalized time 0.975–0.988
then normal cleanup around 1.86–1.92 seconds after E. Windup is absent in
6 attempts, falling back after 0.8 seconds; successful windup lasts about
0.83 seconds. Main clip lasts about 1.07 seconds. One movement cancellation
interrupts an early attempt; another F6 stop interrupts release at ~0.69.
These intentional cancellations must not be counted as successful completions.

Old projectile flight starts at E and game Cast ends at 1.1 seconds.
Animation release instead starts at 0.8–0.84 seconds. This is a verified
synchronization defect, not evidence of a universally interrupted clip.
Now game Cast time and projectile remain held until the Release command.
The existing 1.1-second trajectory runs from that command; forward remains
the camera snapshot from E. Failure/rejection releases the fallback flight.

Separate the public actor-set bind and first TASK_PLAY_ANIM submission by
one engine frame. This removes same-frame ordering, a candidate cause of
missing first clip. No live evidence yet proves this eliminates that failure.
No repeated per-frame clip requests and no forced clock writes.

The native request's exit blend argument is now 0.25 instead of 0.1.
After Release completes, the portable plan waits for that blend period before
resetting its owned actor-set override. A naturally ended clip with observed
progress >=0.95 does not get a second TASK_CLEAR during cleanup.
Watchdog or cancellation still clears our task immediately when required.
Rod pitch interpolates over that same exit period; no attachment/collision,
fish yaw, camera, control binding or INI changes.

Regression tests exercise observed windup-present and windup-missing paths
against the actual Game and animation plan: no game Cast elapsed time before
Release, then 1.1 seconds to landing, then completed native fade before cleanup.
Binding readiness is one frame after successful actor-set binding.
New in-game visual validation remains necessary.

## v0.1.26 single-clip selection and explicit end reasons

Re-audited all throw-name strings in lso.was and their task references in
default_character.wat. tools/audit_lasso_clips.py records exact node/track
assignments; LASSO_CLIPS.md documents the selection and visual limits.
Only nor_lso_stn_mid_trw_mid is requested. The user explicitly rejected the
preparation motion; remove Windup state/command rather than shortening or
speeding it. No alternative walking/running or success/failure pose is guessed.
The historical pre constant is only input to static hierarchy verification and
is not emitted into the optimized DLL.

The uploaded log contains sessions from 0.1.24 and 0.1.25. In latest-version
runs, main normally reaches ~0.988 and then becomes unmatched; it is not
universally cut off early. One main request is missing entirely.
New controller tracks max native normalized time and distinguishes completed
(>=0.95 then unmatched), interrupted, missing, watchdog, and cancellation.
Only natural completion skips TASK_CLEAR; non-natural termination still cleans
our task. No new native hashes, private engine calls or memory writes added.
Rate, disabled seconds timer, owned-set checks and cancellable fade remain.
Portable tests replay natural ~1.07s progress plus missing, early-loss and
looping sequences. They verify one Release command with no former windup
delay, flight/landing synchronization and cancellable exit blending.

## v0.1.27 loop override and flight-owned hold

The user clarified that the desired second phase holds arms forward until
projectile landing. One-shot playback returning after ~1.07s is the wrong
lifecycle even when the clip reaches its authored end.

Native zero-based slot 6 is the loop override. TASK_PLAY_ANIM captures it as
byte task+0x5C; task update passes it at caller stack+0x38. Callee
0x140CDE6F0 prologue maps this to rsp+0x118. At 0x140CDEC8A the byte is
loaded and stored to playback state+0x59, with +0x58 forced to 1.
Completion logic 0x140CEF6B2 checks +0x58; if set, uses +0x59 instead of
the clip default at resource+0x30, and a true value bypasses natural-end
completion. The real native request now passes boolean true in slot 6.
No phase locking, forced time writes, private engine calls or frame-by-frame
TASK_PLAY_ANIM resubmission are introduced.

Lifecycle: Request -> AwaitStart -> native time >0.001 -> Launch -> Holding
while Game remains in Cast -> EndHold on landing -> cancellable native fade
-> release owned actor override. Loop wrap is valid progress, not completion.
TASK_CLEAR is issued once at EndHold, then the set remains during fade.
A six-second hold watchdog exceeds the maximum four-second flight.

Startup reliability: one retry after 0.25s only when native matching is false,
before flight launch. It clears only the pending owned task and resubmits once.
A matched zero-time clip is never restarted. One-second startup deadline
fails into ordinary projectile flight and cleans the owned animation state.
This is bounded recovery, not proof of the original intermittent failure's cause.

Game.castSeconds defaults to the old 1.1 seconds. For animated casting,
prepareCast sets it to clamp(actual XZ distance / 5, 1.1, 4). Both visual arc
and procedural rod pitch use this same duration, and Wait begins at its end.
All catch/bite/reeling mechanics and INI schema remain unchanged.
Tests cover absent/matched-zero startup, one retry only, active-loop wrap,
3/9/20m landing synchronization, cancellation at every stage and watchdog.
No current in-game evidence is claimed for this release.

## v0.1.28 face fixed camera cast direction before animation

User confirms v0.1.27 is the desired animation/hold behavior. Preserve that
controller, playback flags, retry policy and flight timing unchanged.
Remaining defect: animation follows actor yaw, projectile follows the saved
camera forward, so a side-looking camera produces a sideways cast.

SET_ACTOR_HEADING ECE8520B handler VA 0x140AD6950 reads actor, float degrees
from slot 1 at 0x140AD69B4, and boolean/int flag slot 2 at 0x140AD69BA.
It converts degrees to radians at 0x140AD69BE, then calls 0x140AD4B10.
The helper builds a yaw matrix and copies the actor's existing XYZ from its
current transform at 0x140AD4BC3..0x140AD4BE1 before applying the transform.
GET_HEADING uses atan2(actor +Z basis X, actor +Z basis Z), as verified earlier.
Target = atan2(savedForward.x, savedForward.z)*57.295779513; no reflected X.
Native is invoked with flag false; no unverified flag semantics are assumed.

CastTurn starts only after a valid camera/water target was accepted. The
owned set is bound and scoped player controls acquired as in v0.1.27.
Before any clip request, approach target through shortest signed remainder
at <=360 degrees per game second. Read back heading on a later frame and
start animation only within 0.5 degrees. Pause consumes no turn time.
A 1.25-second convergence guard exits to ordinary flight rather than hanging.
No camera resampling during this operation. No continued heading writes once
aligned. Actor facing is intentionally not restored to the pre-cast heading.
F6/death/transport cleanup resets pending turn and existing scoped resources.

Tests cover cardinal/pitched/diagonal views and starting headings including
179/-179/359 degrees, shortest seam crossing, fixed-target capture, bounded
turn steps, clip-start gating, paused time, blocked turn timeout and cancel.
No new private offsets or direct engine calls are introduced.
This validates logic/ABI, not a live visual turn in RDR.


## v0.1.29 correct visible front offset

The user's live v0.1.28 test reports John facing the camera, opposite the
saved camera cast ray. The previous assumption that native transform +Z
was John's visible front was wrong. Native get/set consistency alone did
not establish visible facing. Apply +180 degrees only to CastTurn's target;
leave camera direction, actorForward, rod geometry and fish yaw unchanged.
Tests now compare visible front (-sin heading, 0, -cos heading) with the
saved ray in all quadrants, based on that runtime observation. This is a
regression check of the corrected model, not a new visual game test.


## v0.1.30 Fight-only lasso capture stance candidate

Baseline v0.1.29 is user-confirmed; retain its archives and immutable tag.
Choose nor_lso_stn_mid_trw_suc from the same lso set. Real WAT node 0xAD380
has animation track 0x9904C naming this clip, and child 0xAD440 owns separate
pull-in/yank/tug actions. Thus this is the capture-success parent animation,
not a hogtie/victim clip. That assignment is static evidence, not proof of
the desired visible two-hand fishing pose. verify_fight_resources.py checks
exact asset hashes, clip key/hash and these authored relationships.

FightPose runs only after the Bite->Fight transition, throughout R/Q/release.
It borrows the existing lso binding/ownership and scoped controls only after
releasing the cast session. The cast controller is not updated during Fight;
its headers and camera/fish math remain byte-identical to v0.1.29.
TASK_PLAY_ANIM uses the verified existing ABI, speed 1, loop true, timer -1.
There is one task request, one missing-only startup retry at 0.25s, a 1s
startup deadline, and no restarts after any observed clip match. Two different
native clip-time observations establish the ADVANCING log. Loop wraps do
not restart the task. A missing running clip for 0.25s ends the pose session.
No real target, lasso weapon, tying task, transition nodes or bone writes
are invoked. End Fight/F6/death/transport/move-away all release our task/set
and restore only our owned player control bit. Existing actor overrides
are rejected rather than replaced; ownership changes stop our session.
Animation.Fight defaults to 1 when absent; Fight=0 disables this experiment
without changing the working cast. Portable tests cover long looped fights,
startup failures, frozen clock, interruption, cancellation and idempotent release.
The pose's visual fit is unverified until a real RDR run by the user.


## v0.1.31 stationary hold instead of capture pull-back

User rejects v0.1.30 as a backward pulling movement. Uploaded Fishing.log
SHA256: 2693bc4939ecc165cc2d04dc7af7d05440ff06687aaa699a5d620b57b5f280dd. It records successful matching/time advancement
and repeated normalized-time wraps through Fight, ending cleanly on Lost.
This rules out a missing/aborted clip for that test; it does not establish
pose geometry independently of the user's observation.

Inspecting only animation tracks 28/35 missed locomotion task type 77.
WAT hold-state node 0xAD440 (child of success node 0xAD380) has eight task-77
tracks at 0x4C24C, 0x4C188, 0x4C0C4, 0x4BE8C, 0x4BB7C, 0x4B9F4,
0x4B930 and 0x45E8C. Each has nor_lso_pul_stn at +0xA4, then distinct
nor_lso_pul_wlk_XXX and nor_lso_pul_run_XXX pointers at +0xA8/+0xAC.
Thus the stationary base is nor_lso_pul_stn, not the parent success clip.
A read-only scan/decompression of all WAS entries in animationres.rpf found
this clip's name in gent.was only (not lso, lso_base or pull_leash).
Exact gent.was SHA256 93df0fc0d395980051606b5e496abd0ddae1ae97c300e2910d3d156123b772b7,
size 7258112, set header gent.ast. Short name key 0xF12ADCB8 also present.
verify_fight_resources.py verifies hashes and all eight stationary slots.

Preload gent independently at F6, stream-check and bind it only for Fight.
Generalize the existing binding helper to accept a set name (default lso
for the unchanged cast path). Track ownedAnimSet alongside the resource
pointer so stop/reset checks and logs use the actual current set; release
both streaming requests only on fishing cleanup. Existing script overrides
are still rejected, and ownership loss never resets the other owner's set.
Fight startup/loop/retry/cancel policy is unchanged from v0.1.30. The rejected
clip is absent from runtime code. Cast controller/turn/math remain unchanged.
Do not infer the exact two-hand visible pose from these static assignments;
user game testing is still needed. Baseline tag/archives 0.1.29 stay intact.


## v0.1.32 native base-set shortcut blocked by plugin check

User's 0.1.31 log shows two Fight attempts, both accepted=1 attached=0,
then plugin failure before TASK_PLAY_ANIM. This is not clip rejection.
In SET_ANIM_SET_FOR_ACTOR helper 0x140CE8D30, compare with override at
+0x9A8 happens at 0x140CE8D53. If different, 0x140CE8D70 compares requested
resource with base set +0xB18 and jumps directly to true return 0x140CE8D63
when equal. That branch neither writes override nor sets lock +0xC6A.
Override store only happens later at 0x140CE8DC5. ACTOR_HAS_ANIM_SET reads
override +0x9A8 exclusively. Thus requesting an already-base gent returns
true while ACTOR_HAS_ANIM_SET remains false. v0.1.31 wrongly rejected this.

Extend the existing profile-checked read-only snapshot by base resource
+0xB18. Base-mode acceptance requires native success, attached=false, no
override or lock before/after, and the same nonzero base identity before
and after. Only Fight opts into this path. Cast still requires an owned
locked override. No memory writes, lock forcing or private calls added.
During a base-mode Fight, monitor base identity and reject new overrides
or script locks. On exit clear our issued animation task only; do not call
RESET_ANIM_SET_FOR_ACTOR on the native base. Restore only owned controls.
Override sessions keep the previous cleanup. The clip and playback policy
are unchanged. Tests reproduce accepted=1/attached=0 and reject failed calls,
changed/missing base, competing overrides/locks, and base-mode for Cast.
EXE verification checks the base-compare/true-return/store instruction bytes.
No claim of live playback or visible two-hand fit is made by these tests.


## v0.1.33 stationary frame from backward-left lasso locomotion

User confirms v0.1.32 playback works; the previous pose holds loop and coil
in separate hands. User identifies backward-left dragging as the desired
closely spaced hands, and asks to keep John stationary.

WAT task-77 track 0x4C188 has standing nor_lso_pul_stn at +0xA4,
walking nor_lso_pul_wlk_225 at +0xA8 and running counterpart at +0xAC.
Unlike the stationary clip, directional aliases are in lso_base, not gent.
All-WAS text searches miss this because the alias ordering differs from the
source name. Search runtime key 0xE8323B4F; lso_base.was hash
8421b46d94cb22cfca7e3bac3fd0737dbd4a68551029881fa73399de53d48185,
size 1064960. Entry at 0x100E58 points to resource 0xBDFC0, whose name
pointer at +8 resolves to Human\Gent\gent_nor_lso_225_pul_wlk.
The resource verifier checks both the key-to-source mapping and WAT track.

Use the confirmed TASK_PLAY_ANIM ABI with task-local rate 0 deliberately,
loop true and timer -1. The previous zero-rate cast failure established that
this holds the initial frame rather than advancing. Here a static frame is
intentional to avoid walking feet/root progression. No global animator
speed or coordinate natives are modified; cast stays rate 1. The exact
zero frame's hand/rod and foot alignment is a visual experiment, not proven
by the clip label or a successful native call. No attempt to restart tasks
per frame or manipulate the root is introduced.

FightPose opts into staticPose=true: two valid playing/time observations
establish Holding even with unchanged time. Existing moving-mode advancement
checks are retained and tested. Log MATCHED instead of ADVANCING for this
experiment. Existing bounded loading/startup, missing-only retry, ownership
checks, base/override handling and cancellation remain. Tests exercise the
actual typed task request, zero float rate, clip key, frozen-time hold for
100 seconds with no replay, and release. Baseline 0.1.29 retained.


## v0.1.34 normal evaluation before frame seeking

User reports invisible pose in 0.1.33; log matches the clip continuously
with clipTime=0.0000. That establishes an active frozen task, not visible
pose evaluation. Start with verified rate 1 and require time advancement.
Only in Holding, with matching clip, verified ownership and positive dt,
invoke SET_ACTOR_ANIM_CURRENT_TIME(actor, .25f). Handler 0x140CE0130 wraps
0x140CDF150 through 0x1402846A0. The wrapper loads float slot 1 at
0x14028470C; the implementation seeks the current custom task, and helper
0x140CD8D47 multiplies requested phase by clip duration (normalized time).
Never pass a string or integer in slot 1 despite SDK guessed signature.
Do not call the seek on cast tasks or after ownership loss. Failure ends
our pose session. No task replay/global speed/actor coordinates added.
Game visual verification remains necessary.


## v0.1.35 Wait/Bite stance, Fight crossfade, free camera controls

Wait/Bite use confirmed v0.1.32 gent / nor_lso_pul_stn after existing cast
hold/blend-out finishes. Ready stays unposed. At Fight reset only the pose
controller; when gent is the native base, retain its running task and bind
lso_base without TASK_CLEAR, then request target clip with 0.65s blend-in.
The target frame remains 0.25 as in v0.1.34. Initial Wait uses 0.45s blend.
If gent was an override, release our override before changing sets; visual
continuity of that fallback is unverified. Preload both sets at enable and
balance both requests at cleanup. Failure/cancellation during handoff also
cleans any retained base task. Never modify a competing override.

Binding now takes ownControls=true by default (unchanged cast). Post-cast
poses explicitly pass false: no SET_PLAYER_CONTROL disable for Wait/Bite/
Fight. This removes the plugin's camera-blocking cause, but live interaction
of player input and the animation remains untested. Do not reissue interrupted
poses every frame to fight ordinary controls. Main-loop scheduling prevents
cast cleanup from clearing an owned post-cast pose. All portable existing
lifecycle tests pass, plus actual target request checks 0.65 blend and rate1.
Game verification is still needed for crossfade appearance and camera.


## v0.1.36 straight-back clip and continuous seek phase

User clarifies straight backward dragging of a tied actor, not diagonal.
Use nor_lso_pul_wlk_180, runtime key 0x00E30FE3 at WAS 0x101240,
resource 0xBD200 whose +8 points to Human\Gent\gent_nor_lso_180_pul_wlk.
WAT hold task77 track 0x4C24C +0xA8 selects this key. Fingerprinted lso_base
asset is unchanged. This is authored directional evidence; visible fit still
needs user verification, including whether it matches the tied-target case.

0.1.35 log shows startup at normalized .0236 followed by steady .2617,
consistent with our immediate seek to .25 plus one engine frame. This is a
potential source of a visual snap, not proof of a particular blend bug.
Replace immediate seek with FightFrameTransition: capture observed phase,
then smoothstep from it to .25 over .8 game seconds. First seek equals
observed time; subsequent target increments are continuous and bounded.
Native task blend .65, Wait/Bite clip and free controls remain unchanged.
This is native blending plus gradual seek, not a newly recovered dedicated
transition clip. Do not claim reproduction of the full gameplay transition
without game testing. Tests cover initial continuity, monotonic smooth phase,
final hold, session reset and paused time. Baseline retained.


## v0.1.41 integrate user-selected diagnostic clip

User explicitly confirms key3 of v0.1.40 as the desired clip. Immutable
picker mapping: nor_lso_pul_wlk_000 from lso_base. Log SHA256
034a1a4f67ddcd9be908552517f86f801eb8de6448bf6f9b21b59728f41cfda6
records key3 selection and P freeze phase .2366, followed by continuous
matched samples around .2469 (one frame after seek). Clip identity is user-
confirmed; that freeze phase is recorded evidence, not a separate explicit
user endorsement of a final automatic transition.

Start from the normal v0.1.36 controller, not from diagnostic game-pause
logic. Change clip to selected 000 and target phase to recorded .2366.
Retain existing .65 blend and .8 smooth phase easing. Restore ordinary
Fight dt, tension, R/Q, catch/loss and HUD; no picker bindings or pause.
Wait/Bite stance and free post-cast controls preserved. Cast untouched.
Key 2BE2A272 at WAS101060 maps to actual gent_nor_lso_000_pul_wlk;
WAT direction track 4BB7C. Static mapping verified. Do not infer screen-
space direction from 000/180 suffix: the user's visual choice is decisive.
Baseline0.1.29 remains the primary rollback point; integrated release needs
its own user game validation. Preserve diagnostic0.1.40 for comparisons.


## v0.1.42 modest later stop on confirmed clip

User clarifies .2366 was an incidental diagnostic stop, not an endorsed
final pose, and explicitly asks to move the stop slightly later without
further calibration. Keep confirmed key3 clip nor_lso_pul_wlk_000; change
held normalized phase from .2366 to .35. Preserve .8s ease/.65s blend and
all ordinary fishing logic. Target .35 is a requested empirical adjustment,
not visually verified. Tests retain phase continuity and bounded steps.
Baseline unchanged.


## v0.1.43 one more second of real motion before capture

User explicitly asks another whole second before stopping. Do not merely
slow easing to the same .35 phase. Replace fixed-phase easing with normal
native playback for1.8 seconds after verified advancement (prior .8+1.0).
No seek during that window; after it capture observed normalized phase and
hold it with existing matched/owned task guards. The cyclic clip may wrap;
this is a real time delay, not an assertion of a particular final hand pose.
Keep positive playback rate, clip3, .65 blend and free post-cast controls.
Tests cover exact delay, pause, phase capture across wraps and reset.
Live pose still needs verification. Baseline unchanged.


## v0.1.45 explicitly confirmed final diagnostic stop

User calls the newest uploaded log's last stop correct. Last frozen=1
entry at 8704250ms is clip nor_lso_pul_wlk_000, phase .5238, followed by
F6 at8724390ms. Earlier stops .1285/.2155/.6569/.1904 are superseded.
Normal build uses the exact .5238 phase. Let rate1 task play naturally;
track successive observed normalized phases and seek only on target crossing.
Then hold .5238. No arbitrary elapsed timer or forced phase easing. Handle
loop wrap if the first observed time is already past target. Keep startup
advancement/ownership guards, normal game dt and cancellation. Log first hold.
Tests cover crossing, no early seek, exact hold, pause, invalid time and wrap.
User confirmed diagnostic pose; integrated transition still needs game test.
Baseline0.1.29 remains primary rollback point.


## v0.1.46 hold-to-spin release-to-cast experiment

User promotes v0.1.45 to primary baseline. Immutable baseline-v0.1.45 tag
points to6ce9e22; hashes stored in WORKING_BASELINE.md. Preserve .5238 Fight
pose, free post-cast controls and Wait stance. Never overwrite baseline ZIPs.

Spin candidate nor_lso_stn_aup_swing, alias in lso_base at0x102204, resolves
to Human\Gent\gent_nor_lso_stn_aup_swing__SUBTRACT. Real WAT standing
swing nodes AAC00/AB000/AB300 use tracks9404C/94428 naming it. AUP swing
is distinct from throw-pre. Its subtractive nature is a real limitation:
a direct task's visible correctness is not established by compilation or
name/hash verification. No invented layer values/private writes introduced.

CastCharge begins only after successful camera/water validation on Ready E.
Game stays Cast but flight dt is gated to0 while held. Direction is immutable
from first press. Existing turn and scoped controls run before spin startup.
Preload lso_base separately, bind it during charge; use bounded FightPose
startup/missing-only retry but unlimited matched loop duration. Streaming,
turn or ownership failure does not release flight while key remains held.
Release is latched across loading/turn. At release clear our spin task/set,
restore owned controls, reinitialize the confirmed lso cast path with saved
forward and re-read actor heading. If still holding after a failed spin,
wait for release, do not retry every frame. Animation disabled uses release
gate directly. F6/death/move/transport cleanup resets charge and spin request.

During charge only, set existing attachment preserve-rotation flag false so
rod follows wrist rotation; omit procedural world rotation then. Restore
true and existing rod rotation after release. No offsets/collisions/fish math
changed. Hand-axis visual alignment still needs a user test. Tests cover
long hold/no flight, latched release, early release, cancellation and actual
typed positive-rate loop request. Post-cast header/controllers unchanged.
