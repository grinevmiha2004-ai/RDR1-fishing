#pragma once
#include <algorithm>
#include <cmath>
namespace fishing {
inline int fishSalePrice(float weight){
 if(!std::isfinite(weight)||weight<.4f||weight>10.f)return 0;
 // Weights have two decimal places. Round cents first to make .95 ties stable.
 return (int(std::lround(weight*100.f))+5)/10;
}
inline float releasedHonor(float before){return std::clamp(before+5.f,-5000.f,5000.f);}
struct CatchReward {
 bool paid=false;
 void reset(){paid=false;}
 template<class Apply> bool commit(Apply apply){
  if(paid)return true;
  if(!apply())return false;
  paid=true;return true;
 }
};
}
