#pragma once
#include "cast_charge.hpp"
namespace fishing {
enum class CastInput {None,Begin,Confirm,Cancel};
inline CastInput castInput(bool ready,const CastCharge& charge,bool spinDown,bool spinEdge,bool castEdge){
 if(ready)return (castEdge||spinEdge)?CastInput::Begin:CastInput::None;
 if(!charge.active||charge.released)return CastInput::None;
 if(castEdge)return CastInput::Confirm;
 return spinDown?CastInput::None:CastInput::Cancel;
}
}
