#pragma once
#include "reel_audio.hpp"
namespace fishing {
// Previously excluded forward-reel clips are used ONLY for paying line out.
inline constexpr std::array<ReelClip,2> payoutClips={{{"HUD_MENU_MENU_060308_DPAD_02",0x0FEF10E1},
 {"HUD_MENU_MENU_060308_NAV_01",0x0B2CA65B}}};
struct PayoutPick {
 uint32_t seed=0xc2b2ae35;int selected=0;
 const char* choose(){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;selected=int(seed%2);return payoutClips[selected].event;}
};
}
