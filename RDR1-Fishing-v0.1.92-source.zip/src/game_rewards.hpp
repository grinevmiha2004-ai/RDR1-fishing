#pragma once
#include "redhook.hpp"
#include "fish_scale_runtime.hpp"
#include "catch_reward.hpp"
namespace rewards {
struct Snapshot {uintptr_t cashAddress=0,honorAddress=0;float cash=0,honor=0;};
inline const char* reason="not checked";
inline bool writable(uintptr_t address){
 MEMORY_BASIC_INFORMATION page{};
 if(!VirtualQuery(reinterpret_cast<void*>(address),&page,sizeof(page))||page.State!=MEM_COMMIT||
    (page.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
 DWORD access=page.Protect&0xff;
 return (access==PAGE_READWRITE||access==PAGE_WRITECOPY||access==PAGE_EXECUTE_READWRITE||access==PAGE_EXECUTE_WRITECOPY)&&
 address+sizeof(float)<=reinterpret_cast<uintptr_t>(page.BaseAddress)+page.RegionSize;
}
inline bool inspect(Snapshot& state){
 uintptr_t base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
 static int supported=-1;if(supported<0)supported=fishscale::supported(base)?1:0;
 if(!supported){reason="unsupported RDR.exe profile";return false;}
 if(!fishscale::matches(base+0xad7380,std::array<unsigned char,9>{0x48,0x8b,0x41,0x10,0xf3,0x0f,0x10,0x40,0x08})){
  reason="honor handler fingerprint mismatch";return false;
 }
 uintptr_t globals=rh::globalPtr();int count=0;
 if(!globals||!rig::read(globals+54086u*4,count)||count<4||count>100000){reason="stat table unavailable";return false;}
 state.cashAddress=globals+54088u*4;state.honorAddress=globals+54090u*4;
 if(!rig::read(state.cashAddress,state.cash)||!rig::read(state.honorAddress,state.honor)||
    !std::isfinite(state.cash)||state.cash<0||state.cash>100000000||
    !std::isfinite(state.honor)||state.honor < -5000||state.honor>5000||
    !writable(state.cashAddress)||!writable(state.honorAddress)){
  reason="invalid or unwritable game stats";return false;
 }
 // Independently check the persistent honor slot against the native's actor cache.
 uintptr_t actorState=0;unsigned char ready=0;float cached=0;
 if(!rig::read(base+0x22cbf00,actorState)||!actorState||!rig::read(actorState+0x5e9,ready)||!ready||
    !rig::read(actorState+0x434,cached)||!std::isfinite(cached)||std::abs(cached-state.honor)>.05f){
  reason="honor table/cache mismatch or player not ready";return false;
 }
 reason="game stats verified";return true;
}
inline bool write(uintptr_t address,float value){
 SIZE_T bytes=0;float actual=0;
 if(!writable(address)||!WriteProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(address),&value,sizeof(value),&bytes)||bytes!=sizeof(value)){
  reason="stat write failed";return false;
 }
 if(!rig::read(address,actual)||actual!=value){reason="stat readback failed";return false;}
 return true;
}
inline bool apply(bool release,int price,float& before,float& after){
 Snapshot state;if(!inspect(state))return false;
 before=release?state.honor:state.cash;
 after=release?fishing::releasedHonor(before):before+price;
 if(!std::isfinite(after)||(!release&&(price<=0||after>100000000))){reason="invalid reward amount";return false;}
 if(!write(release?state.honorAddress:state.cashAddress,after))return false;
 if(release){
  // Actual signature verified in RDR.exe: player slot, raw honor. SDK omits slot.
  rh::invoke<0x4D918005>(0,after);
 }else{
  rh::invoke<0xF71BD93A>("nMoneyText","Dmoney_amount",int(after));
  rh::invoke<0x51948EA6>("sn_mny",int(std::lround(before)),price,7.5f,0.f,"HUD_MENU_MESSAGE_BOX_ALERT_MASTER");
 }
 reason="persistent stat updated and read back";return true;
}
}
