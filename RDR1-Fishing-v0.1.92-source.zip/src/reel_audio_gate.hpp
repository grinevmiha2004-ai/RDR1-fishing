#pragma once
namespace fishing {
inline bool reelSoundWanted(bool activePhase,bool reel,bool ease,bool focused,bool paused){
 return activePhase&&reel&&!ease&&focused&&!paused;
}
}
