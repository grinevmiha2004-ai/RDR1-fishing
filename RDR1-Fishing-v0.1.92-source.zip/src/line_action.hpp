#pragma once
#include "fishing.hpp"
#include "visuals.hpp"
namespace fishing {
struct LineAction {
 enum class Kind {None,Retrieve,Hook};
 Kind kind=Kind::None;bool committed=false;float phase=0;
 Point bobber{},hook{};
 bool active()const{return kind!=Kind::None;}
 void reset(){*this={};}
 static bool canRetrieve(Phase phase){return phase==Phase::Wait||phase==Phase::Bite||phase==Phase::Fight;}
 bool handoffDue(float observed)const{return kind==Kind::Hook&&std::isfinite(observed)&&observed>=.72f&&observed<=1.f;}
 int clipIndex()const{return kind==Kind::Retrieve?3:4;}
 void begin(Kind next,Point b={},Point h={}){reset();kind=next;bobber=b;hook=h;}
 bool observe(float observed){
  if(observed<0||observed>1||!std::isfinite(observed))return false;
  phase=observed;
  if(kind==Kind::Retrieve&&!committed&&phase>=.25f){committed=true;return true;}
  return false;
 }
 float fraction()const{float t=std::clamp((phase-.25f)/.60f,0.f,1.f);return t*t*(3-2*t);}
 Point retract(Point from,Point to)const{float t=fraction();Point p=mix(from,to,t);p.y+=.6f*std::sin(3.14159265359f*t);return p;}
};
}
