#pragma once
#include "visuals.hpp"
namespace fishing {
inline constexpr const char* releaseAnimSet="dyn";
inline constexpr const char* releaseClip="nor_dyn_stn_for_mid_und_trw";
// Retry only a missing startup. Never restart a clip that was observed playing.
struct ReleaseStartup {
 enum class Command {None,Retry,Failed};
 int requests=1;bool matched=false;float age=0;
 void reset(){*this={};}
 Command update(bool playing,float dt){
  if(dt<=0)return Command::None;
  matched=matched||playing;
  if(matched)return Command::None;
  age+=dt;
  if(requests<3&&age>=.35f){++requests;age=0;return Command::Retry;}
  if(requests==3&&age>=.75f)return Command::Failed;
  return Command::None;
 }
};
inline float releasedFishYaw(Point towardWater){return std::atan2(towardWater.x,towardWater.z)*57.295779513f+90.f;}
struct FishRelease {
 enum class Stage {Idle,Loading,Bound,Hand,Flight,Landed};
 Stage stage=Stage::Idle;
 Point start{},target{},caught{};
 float age=0,flight=0,duration=1,phase=.48f;
 bool seen=false;
 bool active()const{return stage!=Stage::Idle;}
 void reset(){*this={};}
 void begin(Point from,Point to){reset();stage=Stage::Loading;caught=from;target=to;}
 bool launch(float observed,Point hand){
  if(stage!=Stage::Hand||!std::isfinite(observed)||observed<phase||observed>1.f)return false;
  start=hand;flight=0;duration=std::clamp(std::hypot(target.x-start.x,target.z-start.z)/7.f,.65f,1.5f);
  stage=Stage::Flight;return true;
 }
 bool fly(float dt){
  if(stage!=Stage::Flight||dt<=0)return false;
  flight=std::min(duration,flight+dt);
  if(flight>=duration){stage=Stage::Landed;return true;}
  return false;
 }
 Point position()const{
  float t=std::clamp(flight/duration,0.f,1.f);auto p=mix(start,target,t);
  p.y+=4.f*1.2f*t*(1.f-t);return p;
 }
};
}
