#pragma once
namespace fishing {
struct RecastCandidate {const char* set;const char* clip;const char* label;};
inline constexpr RecastCandidate recastCandidates[]={
 {"lso","nor_lso_stn_pulin","Standing pull-in / retrieve"},
 {"lso","nor_lso_stn_mid_trw_fal","Standing throw: failed outcome"},
 {"lso","nor_lso_stn_aup_mid_trw_fal","Standing high throw: failed outcome"},
 {"lso","nor_lso_stn_mid_trw_suc","Standing throw: caught outcome"},
 {"gent","lso_stn_tug","Standing tug: short"},
 {"gent","nor_lso_tug_stn","Standing tug: long"},
 {"gent","nor_lso_pul_stn","Standing pull: full clip"},
 {"gent","nor_lso_for_tug_wlk","Tug moving forward"},
 {"gent","nor_lso_bck_tug_wlk","Tug moving backward"},
 {"lso_base","nor_lso_pul_wlk_000","Ground-target pull: full clip"}
};
}
