from pathlib import Path
import re,struct,sys
r=Path(__file__).resolve().parent.parent
items=re.findall(r'\{"([a-z0-9_]+)","([a-z0-9_]+)",', (r/'src/recast_preview.hpp').read_text())
assert len(items)==10

def h(s):
 v=0
 for c in s.encode():v=(v+c)&0xffffffff;v=(v+(v<<10))&0xffffffff;v^=v>>6
 v=(v+(v<<3))&0xffffffff;v^=v>>11;return (v+(v<<15))&0xffffffff
for name,clip in items:
 b=(Path(sys.argv[1])/(name+'.was')).read_bytes();start=0;found=False
 expected='gent_'+clip if clip!='nor_lso_pul_wlk_000' else 'gent_nor_lso_000_pul_wlk'
 while (a:=b.find(struct.pack('<I',h(clip)),start))>=0:
  start=a+4;p=struct.unpack_from('<I',b,a+4)[0]&0xfffffff
  if p+12>=len(b):continue
  n=struct.unpack_from('<I',b,p+8)[0]&0xfffffff
  if n>=len(b):continue
  source=b[n:b.find(b'\0',n)].decode(errors='replace')
  if source.lower().startswith('human\\gent\\') and source.lower().endswith(expected):found=True;break
 assert found,(name,clip)
 print(name,clip,'->',source)
print('PASS: 10 real pull-in/tug/throw-outcome runtime mappings')
