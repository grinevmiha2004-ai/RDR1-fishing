"""Verify actual honor native ABI and fishing input action names in supplied EXE.
Static analysis only; this does not verify live stat writes or save persistence.
Usage: python3 tools/verify_rewards.py RDR.exe
"""
from pathlib import Path
import struct,sys
b=Path(sys.argv[1]).read_bytes()
nt=struct.unpack_from('<I',b,0x3c)[0]
n=struct.unpack_from('<H',b,nt+6)[0]
opt=struct.unpack_from('<H',b,nt+20)[0]
def at(rva,size):
 for i in range(n):
  _,start,length,raw=struct.unpack_from('<4I',b,nt+24+opt+i*40+8)
  if start<=rva and rva+size<=start+length:return b[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
code=at(0xad7380,39)
assert code[:9]==bytes.fromhex('488b4110f30f104008') # slot 1 float
assert code[9:12]==bytes.fromhex('488b05')
assert 0xad7390+struct.unpack_from('<i',code,12)[0]==0x22cbf00
assert bytes.fromhex('80b8e905000000') in code # readiness byte
assert bytes.fromhex('f30f118034040000') in code # cached raw honor
for name in (b'FIRE',b'TARGET',b'JUMP',b'SPRINT'):
 assert b'\x00'+name+b'\x00' in b[0x1c5f600:0x1c60000],name
print('PASS: honor slot1 FLOAT ABI, player cache pointer/readiness/offset and four game input action names')
