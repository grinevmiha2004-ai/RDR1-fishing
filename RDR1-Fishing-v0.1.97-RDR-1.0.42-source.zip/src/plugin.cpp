#include "redhook.hpp"
#include "reel_audio.hpp"
#include "reel_audio_runtime.hpp"
#include "reel_menu_audio.hpp"
#include "payout_audio.hpp"
#include "cast_sound.hpp"
#include "water_audio.hpp"
#include "water_audio_runtime.hpp"
#include "reel_audio_gate.hpp"
#include "fishing.hpp"
#include "visuals.hpp"
#include "line_raster.hpp"
#include "hand_bone.hpp"
#include "rig_names.hpp"
#include "fish_scale_runtime.hpp"
#include "fish_hang.hpp"
#include "fight_motion.hpp"
#include "splash.hpp"
#include "throw_preview.hpp"
#include "fish_release.hpp"
#include "item_preview.hpp"
#include "item_sequence.hpp"
#include "recast_preview.hpp"
#include "line_action.hpp"
#include "cast_animation.hpp"
#include "cast_controls.hpp"
#include "cast_preparation.hpp"
#include "cast_animset.hpp"
#include "cast_playback.hpp"
#include "cast_turn.hpp"
#include "cast_charge.hpp"
#include "cast_input.hpp"
#include "game_rewards.hpp"
#include "weapon_hold_runtime.hpp"
#include "ui_language.hpp"
#include "unicode_text.hpp"
#include "tackle_motion.hpp"
#include "rod_cone.hpp"
#include "rod_grip.hpp"
#include "tackle_camera.hpp"
#include "spin_additive.hpp"
#include "fight_pose.hpp"
#include "animset_binding.hpp"
#include <cstdio>
#include <cmath>
#include <string>
#include <cstdarg>

static HMODULE module;
static std::string iniPath,logPath;
static fishing::Game game;
static unsigned savedCatches;
static int toggleKey=VK_F6,actionKey=VK_LBUTTON,reelKey=VK_SPACE,easeKey=VK_SHIFT;
static int spinKey=VK_RBUTTON,hookKey=VK_LBUTTON,retrieveKey='E',keepKey='E',releaseKey='F';
static fishing::Button toggleButton,actionButton,spinButton,keepButton,hookButton;
static fishing::CatchReward catchReward;
static bool inputsBlocked=false;
static fishing::WeaponHold weaponHold;
static void blockFishingInputs(bool block){
 if(!block)weaponHold.release(weapons::end);
 if(inputsBlocked==block)return;
 for(const char* name:{"FIRE","TARGET","JUMP","SPRINT"})rh::actionDisable(name,block);
 inputsBlocked=block;
}
static std::string toggleName="F6",actionName="LMB",reelName="SPACE",easeName="SHIFT";
static const char* stateName(fishing::Phase p){
 static const char* names[]={"Off","Ready","Cast","Wait","Bite","Fight","Caught","Lost"};return names[int(p)];
}
static std::string keyName(int key){
 switch(key){case VK_LBUTTON:return "LMB";case VK_RBUTTON:return "RMB";
 case VK_MBUTTON:return "MMB";case VK_XBUTTON1:return "Mouse4";case VK_XBUTTON2:return "Mouse5";
 case VK_SPACE:return "Space";case VK_SHIFT:case VK_LSHIFT:case VK_RSHIFT:return "Shift";
 case VK_CONTROL:case VK_LCONTROL:case VK_RCONTROL:return "Ctrl";
 case VK_MENU:case VK_LMENU:case VK_RMENU:return "Alt";}

 wchar_t name[80]{};LONG scan=LONG(MapVirtualKeyA(key,MAPVK_VK_TO_VSC)<<16);
 if(GetKeyNameTextW(scan,name,80)){
  char utf8[256]{};if(WideCharToMultiByte(CP_UTF8,0,name,-1,utf8,sizeof(utf8),nullptr,nullptr))return utf8;
 }
 return "key "+std::to_string(key);
}
static int readKey(const char* name,int fallback){
 int key=int(GetPrivateProfileIntA("Keys",name,fallback,iniPath.c_str()));
 // F8 and F9 are reserved by the user's installed mods.
 return key>0&&key<256&&key!=VK_F8&&key!=VK_F9?key:fallback;
}
static bool visuals=true;
static bool hudEnabled=true;
static fishing::Language language=fishing::Language::English;
static textui::UnicodeText unicodeText;
static float lostNoticeTime=0;
static float hudTextHeight=.022f;
static float waterOffset=-.65f,castDistance=10,castRequestedDistance=10;
static rh::Vec origin,forward,waterTarget,bobberPosition,lineTip,hookPosition;
static fishing::TackleMotion tackleMotion;
static fishing::RodCone rodCone;
static fishing::RodGripPose rodGripPose;
static fishing::TackleCamera tackleCamera;
static bool autoWater=true,requireWater=true,showLine=true;
static float noticeTime=0,visualLogTime=0;
static const char* notice="";
static const char* handBone=nullptr;
static std::string rigHandBone;
static bool rigNamesLogged=false;
static bool hasWaterTarget=false;
static int rodAttachment=0;
static float rodAttachRetry=0;
static fishing::CastAnimation castAnimation;
static bool castAnimationEnabled=true,castClipConfirmed=false;
static int castAnimationActor=0;
static fishing::CastPreparation castPreparation;
static fishing::CastClipProgress castProgress;
static bool castFlightReleased=true;
static fishing::CastTurn castTurn;
static fishing::CastCharge castCharge;
static fishing::FightPose castSpin;
static spinlayer::Session spinLayer;
static bool spinSetRequested=false;
static fishing::FightPose fightPose;
static bool fightPoseEnabled=true,fightSetRequested=false,waitSetRequested=false;
static bool poseIsFight=false;
static fishing::FightFrameTransition fightFrameTransition;
static constexpr const char* waitPoseClip="nor_lso_pul_stn";
static float fightSampleAge=0;
static constexpr const char* castAnimSet="lso";
static bool castSetRequested=false,castSetOwned=false,castTaskIssued=false;
static uintptr_t castSetResource=0;
static const char* ownedAnimSet=nullptr;
static uintptr_t sessionBaseResource=0;
static fishing::CastControls castControls;
static float castClipAge=0,castSampleAge=0;
static const char* castClip=nullptr;
static fishing::Point geom(rh::Vec p){return {p.x,p.y,p.z};}
static rh::Vec vector(fishing::Point p){return {p.x,p.y,p.z};}
struct Prop {const char* name;int asset=-1,object=0;bool done=false;};
static Prop props[]={{"p_gen_fishingpole01x"},{"p_gen_fishingbobber01x"},{"p_gen_fishinghook01x"}};
// Mesh inspection confirmed fish01 is sliced; fish02 is the intact fish.
static std::string fishModel;
static int fishAsset=-1,fishObject=0;
static float fishScaleLogTime=0;
static fishing::ReelAudio reelAudio;
static fishing::ReelMenuAudio reelMenuAudio;
static fishing::ReelMenuAudio payoutMenuAudio;
static fishing::PayoutPick payoutPick;
static fishing::FightMotion fightMotion;
static fishing::StruggleSplash struggleSplash;
static fishing::FishRelease fishRelease;
static fishing::ReleaseStartup itemPreviewStartup;
static fishing::ItemSequence itemSequence;
static fishing::ReleaseStartup recastStartup;
static fishing::Button retrieveButton;
static fishing::LineAction lineAction;
static bool hookFightFastBlend=false;
static int recastIndex=-1,recastStage=0;
static bool recastActive=false,recastRequested[10]{};
static float recastAge=0,recastGap=0,recastLogAge=0;
static bool rodVisible=false,catchResolved=false;
static int itemPreviewSelected=-1,itemPreviewStage=0;
static bool itemPreviewActive=false;
static bool itemPreviewRequested[fishing::itemPreviewCount]{};
static float itemPreviewAge=0,itemPreviewGap=0,itemPreviewLogAge=0;
static fishing::ReleaseStartup releaseStartup;
static float releaseQueryGap=0,releaseLogAge=0;
static fishing::Button releaseButton;
static bool releaseSetRequested=false;
static const char* releaseSavedBone=nullptr;
static bool releaseAnimationDone=false;
static int splashLayout=0,splashEmitter=0;
static float splashLife=0;
static bool releaseSplashTail=false;
static unsigned splashSerial=0;
static float audioTestLogAge=0;
static fishing::GameReelAudio gameReelAudio;
static bool reelAudioFailureLogged=false;
static fishing::CastSound castSound;
static fishing::WaterAudio waterAudio;
static fishing::GameWaterAudio gameWaterAudio;
static fishing::WaterTriggers waterTriggers;
static bool fishRequestPending=false,fishLoaded=false,fishSpawnAttempted=false;
static float fishLoadTime=0;
static rh::Vec fishMouthOffset{};
static void log(const char* format,...);
static void updateWeaponHold(int actor){
 static int previousActor=0,previousState=-1;
 bool held=weaponHold.update(actor,weapons::flags,weapons::start,weapons::end);
 int state=held?(weaponHold.owned?1:2):0;
 if(previousActor!=actor||previousState!=state){
  log("Fishing weapon hold: actor=%d forceHolstered=%d owned=%d readback=%s",actor,int(held),int(weaponHold.owned),held?"confirmed":"unavailable");
  previousActor=actor;previousState=state;
 }
}
static void stopCastAnimation(bool resetPlan=true){
 spinLayer.stop(castAnimationActor);
 if(castSetOwned&&ownedAnimSet&&castAnimationActor&&rh::validActor(castAnimationActor)){
  castset::Snapshot current;const char* reason=nullptr;
  bool read=castset::snapshot(castAnimationActor,current,reason);
  bool baseSession=sessionBaseResource!=0;
  bool ours=read&&(baseSession?
   fishing::matchesBaseSession(sessionBaseResource,current.baseResource,current.resource,current.locked):
   current.resource==castSetResource);
  if(ours&&(baseSession||rh::invoke<0x31F5F57D,bool>(castAnimationActor,ownedAnimSet))){
   if(castTaskIssued)rh::invoke<0x16876A25>(castAnimationActor);
   // Flag 1 avoids the reset native's full animator reset branch.
   if(!baseSession)rh::invoke<0x7A6C5C2F>(castAnimationActor,1);
   log("Cast animset released: set=%s clipMatched=%d timeAdvanced=%d",ownedAnimSet,int(castClipConfirmed),int(castProgress.advanced));
  }else log("Cast animset ownership changed; actor state left to current owner");
 }
 // Restore our control bit even if the actor became unavailable.
 if(castControls.restore([](bool enabled){rh::invoke<0xD17AFCD8>(0,enabled,0,0);}))
  log("Cast player control restore requested");
 castAnimationActor=0;castClip=nullptr;castClipConfirmed=false;
 castSetOwned=false;castSetResource=0;ownedAnimSet=nullptr;sessionBaseResource=0;castTaskIssued=false;castClipAge=0;castSampleAge=0;castProgress.reset();
 castAnimation.reset();castTurn.reset();castSpin.reset();
 if(resetPlan)castPreparation.reset();else castPreparation.complete();
}
static void requestCastAnimSet(){
 if(!castAnimationEnabled||castSetRequested)return;
 rh::invoke<0x2988B3FC>(castAnimSet,0);castSetRequested=true;
 if(!spinSetRequested){rh::invoke<0x2988B3FC>(fishing::castSpinSet,0);spinSetRequested=true;}
 log("Cast animset requested: set=%s (verified in animationres.rpf)",castAnimSet);
}
static void requestFightAnimSet(){
 if(!fightPoseEnabled)return;
 if(!waitSetRequested){rh::invoke<0x2988B3FC>("gent",0);waitSetRequested=true;}
 if(fightSetRequested)return;
 rh::invoke<0x2988B3FC>(fishing::fightAnimSet,0);fightSetRequested=true;
 log("Fight animset requested: set=%s",fishing::fightAnimSet);
}
static bool bindCastAnimSet(int actor,const char* animSet=castAnimSet,bool allowBase=false,bool ownControls=true){
 castset::Snapshot before;const char* reason=nullptr;
 if(!castset::snapshot(actor,before,reason)){
  log("Cast animation skipped: %s",reason);return false;
 }
 // Never replace a pre-existing script override, even one using the same set.
 if(before.resource||before.locked){log("Cast animation skipped: existing actor animset override");return false;}
 bool accepted=rh::invoke<0x39C1E1C0,bool>(actor,animSet,0);
 bool attached=rh::invoke<0x31F5F57D,bool>(actor,animSet);
 castset::Snapshot after;
 bool read=castset::snapshot(actor,after,reason);
 auto binding=read?fishing::classifyAnimBinding(accepted,attached,allowBase,after.resource,after.locked,before.baseResource,after.baseResource):fishing::AnimBinding::Rejected;
 if(binding==fishing::AnimBinding::Rejected){
  if(accepted&&attached)rh::invoke<0x7A6C5C2F>(actor,1);
  log("Cast animset bind failed: accepted=%d attached=%d",int(accepted),int(attached));return false;
 }
 castAnimationActor=actor;castSetOwned=true;castSetResource=after.resource;ownedAnimSet=animSet;
 sessionBaseResource=binding==fishing::AnimBinding::Base?after.baseResource:0;
 if(ownControls)castControls.acquire([](){return rh::invoke<0x9613C2D0,bool>(0);},
                      [](bool enabled){rh::invoke<0xD17AFCD8>(0,enabled,0,0);});
 log("Cast animset bound: set=%s controlOwned=%d mode=%s",animSet,int(castControls.owned),sessionBaseResource?"native-base":"override");
 return true;
}
static void removeFish();
static void stopSplash();
static void restoreReleaseRod();
static void beginLineAction(fishing::LineAction::Kind kind);
static void stopRecastPreview(const char* reason);
static bool updateRecastPreview(int actor,float dt);
static void beginItemSequence(fishing::ItemSequence::Kind kind);
static bool updateItemSequence(int actor,float dt);
static rh::Vec releaseHand(int actor);
static void holdRodLeft();
static void stopRecastPreview(const char* reason){
 if(recastActive)log("Line action ended: kind=%d clip=%s reason=%s committed=%d",int(lineAction.kind),fishing::recastCandidates[recastIndex].clip,reason,int(lineAction.committed));
 bool retrieved=lineAction.kind==fishing::LineAction::Kind::Retrieve&&lineAction.committed;
 stopCastAnimation();recastActive=false;recastStage=0;recastAge=0;recastGap=0;recastLogAge=0;recastStartup.reset();
 lineAction.reset();fightPose.reset();fightFrameTransition.reset();
 if(retrieved){removeFish();game.enter(fishing::Phase::Ready);tackleMotion.prepare();}
}
static void beginLineAction(fishing::LineAction::Kind kind){
 hookFightFastBlend=false;
 stopCastAnimation();fightPose.reset();fightFrameTransition.reset();restoreReleaseRod();
 lineAction.begin(kind,geom(bobberPosition),geom(hookPosition));
 recastIndex=lineAction.clipIndex();recastActive=true;recastStage=0;recastAge=0;recastGap=0;recastLogAge=0;recastStartup.reset();
 if(kind==fishing::LineAction::Kind::Hook)requestFightAnimSet();
 if(!recastRequested[recastIndex]){rh::invoke<0x2988B3FC>(fishing::recastCandidates[recastIndex].set,0);recastRequested[recastIndex]=true;}
 reelAudio.stop(gameReelAudio);reelMenuAudio.reset();payoutMenuAudio.reset();
 if(kind==fishing::LineAction::Kind::Retrieve){waterAudio.stop(gameWaterAudio);stopSplash();}
 log("Line action begun: kind=%d set=%s clip=%s rod=RIGHT phase=%s",int(kind),fishing::recastCandidates[recastIndex].set,fishing::recastCandidates[recastIndex].clip,stateName(game.phase));
}
static bool handoffHookToFight(int actor,float phase){
 if(!rh::invoke<0x4FFF397D,bool>(fishing::fightAnimSet))return false;
 castset::Snapshot current;const char* reason=nullptr;
 bool read=castset::snapshot(actor,current,reason);
 bool ours=read&&(sessionBaseResource?fishing::matchesBaseSession(sessionBaseResource,current.baseResource,current.resource,current.locked):current.resource==castSetResource);
 if(actor!=castAnimationActor||!ours)return false;
 // Preserve the current hook task. Release only our override if one exists.
 // The base gent case already supports this same handoff for Wait -> Fight.
 if(!sessionBaseResource)rh::invoke<0x7A6C5C2F>(actor,1);
 if(!bindCastAnimSet(actor,fishing::fightAnimSet,true,false))return false;
 recastActive=false;lineAction.reset();recastStage=0;recastAge=0;recastGap=0;recastLogAge=0;recastStartup.reset();
 fightPose.reset();fightFrameTransition.reset();fightSampleAge=0;poseIsFight=true;
 fightPose.owned=true;fightPose.stage=fishing::FightPose::Stage::Bound;
 hookFightFastBlend=true;
 log("Hook -> Fight seamless handoff: hookPhase=%.4f task preserved, next-frame fight request blend=0.18",phase);
 return true;
}
static bool updateRecastPreview(int actor,float dt){
 bool pressed=retrieveButton.sample((GetAsyncKeyState(retrieveKey)&0x8000)!=0);
 if(pressed&&!lineAction.active()&&!itemSequence.active()&&!fishRelease.active()&&fishing::LineAction::canRetrieve(game.phase))
  beginLineAction(fishing::LineAction::Kind::Retrieve);
 if(!recastActive)return false;
 const auto& clip=fishing::recastCandidates[recastIndex];recastAge+=dt;
 if(recastStage==0){
  if(rh::invoke<0x4FFF397D,bool>(clip.set)){
   if(!bindCastAnimSet(actor,clip.set,true,false)){stopRecastPreview("bind failed");return true;}
   recastStage=1;recastAge=0;return true;
  }
  if(recastAge>5.f)stopRecastPreview("streaming timeout");
  return true;
 }
 if(recastStage==1){
  fishing::requestThrowPreview([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,clip.clip);
  castTaskIssued=true;recastStage=2;recastAge=0;
  log("Line action requested: rate=1 loop=0 timer=-1 clip=%s",clip.clip);return true;
 }
 bool playing=rh::invoke<0x1ADE21EB,bool>(actor,clip.clip);
 float phase=rh::invoke<0x8609F5E1,float>(actor,clip.clip);
 auto command=recastStartup.update(playing,dt);
 if(command==fishing::ReleaseStartup::Command::Failed){stopRecastPreview("no startup after bounded retries");return true;}
 if(command==fishing::ReleaseStartup::Command::Retry){
  castset::Snapshot current;const char* reason=nullptr;
  bool read=castset::snapshot(actor,current,reason);
  bool ours=read&&(sessionBaseResource?fishing::matchesBaseSession(sessionBaseResource,current.baseResource,current.resource,current.locked):current.resource==castSetResource);
  if(actor!=castAnimationActor||!ours){stopRecastPreview("ownership changed");return true;}
  rh::invoke<0x16876A25>(actor);
  fishing::requestThrowPreview([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,clip.clip);
  log("Line action startup retry: attempt=%d",recastStartup.requests);
 }
 if(playing&&lineAction.handoffDue(phase)&&handoffHookToFight(actor,phase))return true;
 if(playing)recastGap=0;else recastGap+=dt;
 if(lineAction.observe(playing?phase:-1.f)){
  removeFish();
  log("Tackle retrieval committed: phase=%.4f current fish discarded, total catches unchanged",phase);
 }
 recastLogAge+=dt;
 if(recastLogAge>=.2f){recastLogAge=0;log("Line action progress: key=%d clip=%s playing=%d time=%.4f age=%.3f",(recastIndex+1)%10,clip.clip,int(playing),phase,recastAge);}
 if(recastStartup.matched&&!playing&&recastGap>=.25f)stopRecastPreview("native playback ended");
 else if(recastAge>30.f)stopRecastPreview("30-second watchdog");
 return true;
}
static void updateCastAnimation(int actor,float dt){
 if(!castAnimationEnabled)return;
 if(castCharge.active&&castCharge.released){
  // Release our spin override, then use the confirmed normal throw controller.
  stopCastAnimation();castCharge.reset();
  castTurn.begin(geom(forward));
  log("Cast charge released: starting normal throw toward camera target captured on release");
 }
 bool casting=game.phase==fishing::Phase::Cast;
 bool allowed=casting||game.phase==fishing::Phase::Wait;
 if(!allowed){if(castSetOwned)stopCastAnimation();else castPreparation.reset();return;}
 requestCastAnimSet();
 const char* animationSet=castCharge.active?fishing::castSpinSet:castAnimSet;
 bool loaded=rh::invoke<0x4FFF397D,bool>(animationSet);
 auto prepared=castPreparation.update(casting,allowed,loaded,dt,[&](){return bindCastAnimSet(actor,animationSet,false,!castCharge.active);});
 using Prep=fishing::CastPreparation::Result;
 if(prepared==Prep::Timeout){castFlightReleased=!castCharge.active;log("Cast animation skipped: lso animset load timeout");return;}
 if(prepared==Prep::Rejected){castFlightReleased=!castCharge.active;return;}
 if(castPreparation.stage!=fishing::CastPreparation::Stage::Ready)return;
 castset::Snapshot current;const char* reason=nullptr;
 if(actor!=castAnimationActor||!castset::snapshot(actor,current,reason)||current.resource!=castSetResource){
  log("Cast animation stopped: actor or animset ownership changed");castFlightReleased=!castCharge.active;stopCastAnimation(false);return;
 }
 if(castTurn.pending){
  float heading=rh::invoke<0x42DE39F0,float>(actor),next=heading;
  auto facing=castTurn.update(heading,dt,next);
  if(facing==fishing::CastTurn::Result::Failed){
   log("Cast facing failed: heading unavailable or turn did not converge");
   castFlightReleased=!castCharge.active;stopCastAnimation(false);return;
  }
  if(facing==fishing::CastTurn::Result::Turning){
   if(dt>0)rh::invoke<0xECE8520B>(actor,next,false);
   return;
  }
  log("Cast facing aligned: heading=%.2f target=%.2f",heading,castTurn.target);
 }
 if(castCharge.active){
  bool playing=rh::invoke<0x1ADE21EB,bool>(actor,fishing::castSpinBase);
  float time=rh::invoke<0x8609F5E1,float>(actor,fishing::castSpinBase);
  auto command=castSpin.update(true,true,dt,playing,time,[](){return true;});
  using C=fishing::FightPose::Command;
  if(command==C::Request||command==C::Retry){
   if(command==C::Retry&&castTaskIssued)rh::invoke<0x16876A25>(actor);
   fishing::requestCastClip([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,fishing::castSpinBase);
   castTaskIssued=true;log("Cast spin base requested: clip=%s retry=%d",fishing::castSpinBase,int(command==C::Retry));
  }
  if(command==C::Release){log("Cast spin unavailable; waiting for key release");stopCastAnimation(false);return;}
  if(castSpin.stage==fishing::FightPose::Stage::Holding&&!spinLayer.attempted){
   bool attached=spinLayer.start(actor,fishing::castSpinClip);
   log("Additive spin start: attached=%d occupied=%u capacity=%u reason=%s",int(attached),spinLayer.occupied,spinLayer.capacity,spinLayer.reason);
  }
  castSampleAge+=dt;
  if(castSampleAge>=.5f){float additiveTime=-1;bool attached=spinLayer.matched(actor,additiveTime);
   log("Additive spin sample: basePlaying=%d basePhase=%.4f layerAttached=%d layerPhase=%.4f",int(playing),time,int(attached),additiveTime);castSampleAge=0;}
  return;
 }
 bool playing=castClip&&rh::invoke<0x1ADE21EB,bool>(actor,castClip);
 float observedTime=castClip?rh::invoke<0x8609F5E1,float>(actor,castClip):-1.f;
 auto command=castAnimation.update(casting||prepared==Prep::Start,allowed,dt,playing,observedTime);
 using Command=fishing::CastAnimCommand;
 if(command==Command::Stop){stopCastAnimation(false);return;}
 if(command==Command::Launch){
  castFlightReleased=true;game.elapsed=0;tackleMotion.beginFlight();
  log("Cast flight launched after clip advancement: seconds=%.3f clipTime=%.4f",game.castSeconds,observedTime);
 }
 if(command==Command::EndHold){
  if(!castFlightReleased){castFlightReleased=true;game.elapsed=0;}
  log("Cast hold ended: reason=%s maxTime=%.4f age=%.3f",fishing::castEndName(castAnimation.end),castAnimation.maxTime,castClipAge);
  if(castTaskIssued){rh::invoke<0x16876A25>(actor);castTaskIssued=false;}
 }
 if(command==Command::Request||command==Command::Retry){
  // A retry is allowed once, only before any match/advancement starts the flight.
  if(command==Command::Retry){
   if(castTaskIssued)rh::invoke<0x16876A25>(actor);
   log("Cast clip startup retry: no active clip after initial request");
  }
  castClip=fishing::castReleaseClip;
  castClipConfirmed=false;castClipAge=0;castSampleAge=0;castProgress.reset();
  fishing::requestCastClip([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,castClip);
  castTaskIssued=true;
  log("Cast clip requested: set=%s clip=%s rate=%.1f loop=1 timer=%.1f gamePhase=%s",castAnimSet,castClip,fishing::castPlaybackRate,fishing::castTaskTimer,stateName(game.phase));
 }
 if(!castClip)return;
 castClipAge+=dt;castSampleAge+=dt;
 playing=rh::invoke<0x1ADE21EB,bool>(actor,castClip);
 float clipTime=rh::invoke<0x8609F5E1,float>(actor,castClip);
 if(playing&&!castClipConfirmed){castClipConfirmed=true;log("Cast clip MATCHED: clip=%s",castClip);}
 if(castProgress.observe(playing,clipTime))log("Cast animation ADVANCING: clip=%s clipTime=%.4f",castClip,clipTime);
 if(castSampleAge>=.1f){
  log("Cast clip sample: clip=%s playing=%d age=%.3f clipTime=%.4f setAttached=%d gamePhase=%s",castClip,int(playing),castClipAge,clipTime,int(rh::invoke<0x31F5F57D,bool>(actor,castAnimSet)),stateName(game.phase));
  castSampleAge=0;
 }
}
static void updateFightPose(int actor,float dt){
 using Pose=fishing::FightPose;
 bool fighting=game.phase==fishing::Phase::Fight;
 if(!fighting)hookFightFastBlend=false;
 bool waiting=game.phase==fishing::Phase::Wait||game.phase==fishing::Phase::Bite;
 bool wanted=fightPoseEnabled&&(fighting||waiting);
 // Allow the confirmed cast hold/blend-out to finish before taking its session.
 if(wanted&&waiting&&castSetOwned&&!fightPose.owned)return;
 if(wanted&&fightPose.stage!=Pose::Stage::Idle&&poseIsFight!=fighting){
  // A base gent session has no override to remove. Preserve its active task
  // while binding lso_base, allowing TASK_PLAY_ANIM to crossfade from it.
  if(!sessionBaseResource)stopCastAnimation();
  fightPose.reset();fightFrameTransition.reset();fightSampleAge=0;
 }
 const char* poseClip=fighting?fishing::fightHoldClip:waitPoseClip;
 const char* poseSet=fighting?fishing::fightAnimSet:"gent";
 // Release the previous phase's animation before acquiring a new session.
 if(wanted&&fightPose.stage==Pose::Stage::Idle){
  if(!sessionBaseResource)stopCastAnimation();
  poseIsFight=fighting;fightFrameTransition.reset();fightSampleAge=0;
  log("Fight pose preparing: clip=%s",poseClip);
 }
 if(wanted&&fightPose.owned){
  castset::Snapshot current;const char* reason=nullptr;
  bool read=castset::snapshot(actor,current,reason);
  bool ours=read&&(sessionBaseResource?
   fishing::matchesBaseSession(sessionBaseResource,current.baseResource,current.resource,current.locked):
   current.resource==castSetResource);
  if(actor!=castAnimationActor||!ours){
   log("Fight pose stopped: actor or animset ownership changed");
   stopCastAnimation();fightPose.owned=false;fightPose.stage=Pose::Stage::Failed;return;
  }
 }
 if(wanted)requestFightAnimSet();
 bool loaded=wanted&&rh::invoke<0x4FFF397D,bool>(poseSet);
 bool playing=fightPose.owned&&rh::invoke<0x1ADE21EB,bool>(actor,poseClip);
 float time=fightPose.owned?rh::invoke<0x8609F5E1,float>(actor,poseClip):-1.f;
 auto before=fightPose.stage;
 auto command=fightPose.update(wanted,loaded,dt,playing,time,[&](){return bindCastAnimSet(actor,poseSet,true,false);});
 if((fightPose.stage==Pose::Stage::Failed||(!wanted&&before!=Pose::Stage::Idle))&&castSetOwned&&command!=Pose::Command::Release){
  stopCastAnimation();
 }
 if(command==Pose::Command::Release){
  log("Fight pose released: phase=%s previousStage=%d",stateName(game.phase),int(before));
  stopCastAnimation();return;
 }
 if(command==Pose::Command::Request||command==Pose::Command::Retry){
  if(command==Pose::Command::Retry&&castTaskIssued)rh::invoke<0x16876A25>(actor);
  if(fighting)fishing::requestFightClip([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,hookFightFastBlend?.18f:.65f);
  else rh::invoke<0x5AB552C6>(actor,poseClip,.45f,fishing::castBlendOut,1.f,0,true,false,-1.f);
  castTaskIssued=true;
  log("Fight pose %s: clip=%s rate=1 loop=1 timer=-1 phase=%s blend=%.2f",command==Pose::Command::Retry?"startup retry":"requested",poseClip,stateName(game.phase),fighting?(hookFightFastBlend?.18:.65):.45);
 }
 if(before!=Pose::Stage::Holding&&fightPose.stage==Pose::Stage::Holding)
  log("Fight pose ADVANCING: clip=%s clipTime=%.4f",poseClip,time);
 if(before!=Pose::Stage::Failed&&fightPose.stage==Pose::Stage::Failed)
  log("Fight pose unavailable: startup/streaming failed; fishing continues");
 if(fighting&&fightPose.stage==Pose::Stage::Holding&&playing&&dt>0){
  bool wasHeld=fightFrameTransition.held;
  float heldPhase=fightFrameTransition.sample(time,dt);
  if(!wasHeld&&fightFrameTransition.held)log("Confirmed pose held: clip=%s phase=%.4f observed=%.4f",poseClip,heldPhase,time);
  if(heldPhase>=0&&!rh::invoke<0x8626C1A0,bool>(actor,heldPhase)){
   log("Fight pose seek failed; pose session ended");
   stopCastAnimation();fightPose.owned=false;fightPose.stage=Pose::Stage::Failed;return;
  }
 }
 if(fightPose.owned){
  fightSampleAge+=dt;
  if(fightSampleAge>=1.f){log("Fight pose sample: playing=%d clipTime=%.4f phase=%s",int(playing),time,stateName(game.phase));fightSampleAge=0;}
 }
}
static bool fishVisiblePhase(){
 using fishing::Phase;
 return game.phase==Phase::Bite||game.phase==Phase::Fight||(game.phase==Phase::Caught&&!catchResolved);
}
static void removeFish(){
 if(rh::validObject(fishObject)){rh::invoke<0x21144994>(fishObject);log("Hooked fish removed: object=%d",fishObject);}
 fishObject=0;fishSpawnAttempted=false;
}
static int layout=0;static float loadTime=0;
static void log(const char* format,...) {
 char buf[1024];va_list a;va_start(a,format);vsnprintf(buf,sizeof(buf),format,a);va_end(a);
 rh::print(1,"[Fishing] %s",buf);
 if(FILE* f=fopen(logPath.c_str(),"a")){fprintf(f,"[%llu ms] %s\n",static_cast<unsigned long long>(GetTickCount64()),buf);fclose(f);}
}
static void stopSplash(){
 if(rh::validObject(splashEmitter)){
  rh::invoke<0x7246F438,bool>(splashEmitter);
  rh::invoke<0x21144994>(splashEmitter);
 }
 splashEmitter=0;splashLife=0;releaseSplashTail=false;
}
static void clearSplashes(){
 stopSplash();
 if(rh::validObject(splashLayout))rh::invoke<0x21144994>(splashLayout);
 splashLayout=0;struggleSplash.reset();
}
static void launchSplash(){
 if(!hasWaterTarget)return;
 stopSplash();
 if(!rh::validObject(splashLayout))splashLayout=rh::invoke<0x6CA53214,int>("RDR1FishingSplashes");
 if(!rh::validObject(splashLayout)){log("Splash: layout creation failed");return;}
 rh::Vec at=(game.phase==fishing::Phase::Fight||game.phase==fishing::Phase::Bite)?bobberPosition:waterTarget;
 // y is the vertical axis in RDR1. The fish/hook can sit below the surface.
 at.y=waterTarget.y-.08f+.025f;
 char name[64];snprintf(name,sizeof(name),"FishingSplash_%u",++splashSerial);
 const char* effect=fishing::splashForWeight(game.weight);
 splashEmitter=rh::invoke<0xF1F8AFCA,int>(splashLayout,name,effect,rh::XY{at.x,at.y},at.z);
 bool started=false;
 if(rh::validObject(splashEmitter)){
  rh::invoke<0x1A4C98C1,bool>(splashEmitter,1.f);
  // START takes Euler angles, not a second position. Packed XY + Z ABI.
  started=rh::invoke<0x6745191B,bool>(splashEmitter,rh::XY{0,0},0.f);
 }
 splashLife=1.5f;
 log("Struggle splash: weight=%.2f effect=%s emitter=%d started=%d scale=1 xyz=(%.3f %.3f %.3f)",
  game.weight,effect,splashEmitter,int(started),at.x,at.y,at.z);
 if(!started)stopSplash();
}
static void updateSplashes(float dt){
 if(splashEmitter){splashLife-=dt;if(splashLife<=0)stopSplash();}
 bool fighting=game.phase==fishing::Phase::Fight;
 bool biting=game.phase==fishing::Phase::Bite;
 if(!fighting&&!biting&&!releaseSplashTail)stopSplash();
 if(struggleSplash.update(fighting||biting,biting||game.pulling(),dt))launchSplash();
}
static void save(){char b[32];snprintf(b,sizeof(b),"%u",game.catches);if(!WritePrivateProfileStringA("Progress","Catches",b,iniPath.c_str()))log("Cannot save catches (Win32 %lu)",GetLastError());savedCatches=game.catches;}
static void cleanup(){
 lostNoticeTime=0;
 blockFishingInputs(false);
 if(recastActive)stopRecastPreview("cleanup");
 for(int i=0;i<10;++i)if(recastRequested[i]){rh::invoke<0xD04A817A>(fishing::recastCandidates[i].set);recastRequested[i]=false;}
 itemSequence.reset();itemPreviewActive=false;rodVisible=false;catchResolved=false;hookFightFastBlend=false;
 for(int i=0;i<fishing::itemPreviewCount;++i)if(itemPreviewRequested[i]){
  rh::invoke<0xD04A817A>(fishing::itemPreviewClips[i].set);itemPreviewRequested[i]=false;
 }
 fishRelease.reset();
 if(releaseSavedBone){handBone=releaseSavedBone;releaseSavedBone=nullptr;}
 if(releaseSetRequested){rh::invoke<0xD04A817A>(fishing::releaseAnimSet);releaseSetRequested=false;}
 clearSplashes();
 reelAudio.stop(gameReelAudio);reelMenuAudio.reset();payoutMenuAudio.reset();fightMotion.reset();castSound.reset(gameReelAudio);waterAudio.stop(gameWaterAudio);waterTriggers.reset();reelAudioFailureLogged=false;
 castCharge.reset();rodCone.reset();rodGripPose.reset();tackleMotion.reset();
 tackleCamera.clear([](int camera,int object){if(rh::validObject(camera))rh::invoke<0x781D5599>(camera,object);});
 fightPose.reset();fightFrameTransition.reset();fightSampleAge=0;
 stopCastAnimation();
 if(castSetRequested){rh::invoke<0xD04A817A>(castAnimSet);castSetRequested=false;}
 if(spinSetRequested){rh::invoke<0xD04A817A>(fishing::castSpinSet);spinSetRequested=false;}
 if(fightSetRequested){rh::invoke<0xD04A817A>(fishing::fightAnimSet);fightSetRequested=false;}
 if(waitSetRequested){rh::invoke<0xD04A817A>("gent");waitSetRequested=false;}
 if(rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment))rh::invoke<0xE894DC13>(rodAttachment);
 rodAttachment=0;rodAttachRetry=0;
 removeFish();
 if(fishing::validAsset(fishAsset))rh::invoke<0xA8D12960>(fishAsset);
 fishAsset=-1;fishLoaded=false;fishRequestPending=false;fishLoadTime=0;
 for(auto& p:props){if(rh::validObject(p.object))rh::invoke<0x21144994>(p.object);p.object=0;if(fishing::validAsset(p.asset))rh::invoke<0xA8D12960>(p.asset);p.asset=-1;p.done=false;}
 if(layout&&rh::validObject(layout))rh::invoke<0x21144994>(layout);
 layout=0;hasWaterTarget=false;handBone=nullptr;rigHandBone.clear();rigNamesLogged=false;
}
static void requestProps(){
 if(!visuals)return;
 layout=rh::invoke<0x6CA53214,int>("RDR1Fishing");loadTime=0;
 for(auto& p:props){std::string path="$/fragments/";path+=p.name;rh::invoke<0x9AA02DA7,int>(path.c_str(),0);p.asset=rh::invoke<0x6005B514,int>(path.c_str(),0);log("Request %s: asset=%d",path.c_str(),p.asset);if(fishing::validAsset(p.asset))rh::invoke<0x38DC1F50,bool>(p.asset,true);else p.done=true;}
 if(!fishModel.empty()){
  std::string path="$/fragments/"+fishModel;
  rh::invoke<0x9AA02DA7,int>(path.c_str(),0);fishAsset=rh::invoke<0x6005B514,int>(path.c_str(),0);
  fishRequestPending=fishing::validAsset(fishAsset);fishLoadTime=0;
  if(fishRequestPending)rh::invoke<0x38DC1F50,bool>(fishAsset,true);
  log("Fish request %s: asset=%d pending=%d",path.c_str(),fishAsset,int(fishRequestPending));
 }else log("Fish rendering disabled: no installed fish model configured in [Fish] Model");
}
static rh::Vec point(float distance,float height,float side=0){return {origin.x+forward.x*distance+forward.z*side,origin.y+height,origin.z+forward.z*distance-forward.x*side};}
static rh::Vec actorForward(int actor){
 float heading=rh::invoke<0x42DE39F0,float>(actor)*.01745329252f;
 return {std::sin(heading),0,std::cos(heading)};
}
static rh::Vec actorPoint(int actor,float distance,float height,float side=0){
 auto body=rh::position(actor);auto facing=actorForward(actor);
 return {body.x+facing.x*distance+facing.z*side,body.y+height,body.z+facing.z*distance-facing.x*side};
}
static bool updateCastDirection(){
 // RDR.exe 0x1403AAEF0: output vector pointer first, camera channel second.
 // Channel 0 is the rendered view; the handler returns its forward direction.
 alignas(16) rh::Vec direction{};
 if(!rh::invoke<0x6ED00237,bool>(&direction,0))return false;
 fishing::Point flat{};
 if(!fishing::horizontalDirection(geom(direction),flat))return false;
 forward=vector(flat);return true;
}
static bool handPositionValid(rh::Vec p,int actor){
 auto body=rh::position(actor);
 float dx=p.x-body.x,dy=p.y-body.y,dz=p.z-body.z;
 return fishing::finite(geom(p))&&dx*dx+dy*dy+dz*dz<9;
}
static void findHandBone(int actor){
 int object=rh::invoke<0x4A2063EC,int>(actor);
 // Confirmed by the user's Rampage inspection AND the v0.1.14 actor bone log.
 alignas(16) rh::Vec wrist{};
 bool wristFound=rh::invoke<0x30516389,bool>(object,"wrist_r",&wrist);
 if(wristFound&&handPositionValid(wrist,actor)){
  handBone="wrist_r";rigNamesLogged=true;
  log("Hand bone found: wrist_r position=(%.3f %.3f %.3f)",wrist.x,wrist.y,wrist.z);return;
 }
 if(!rigNamesLogged)log("Confirmed wrist lookup: wrist_r result=%d position=(%.3f %.3f %.3f)",int(wristFound),wrist.x,wrist.y,wrist.z);
 // Resolve the actual name in this loaded model, preserving exact case.
 std::vector<std::string> names;const char* reason="";
 if(rig::names(object,names,reason)){
  if(!rigNamesLogged){
   log("Actor skeleton: %u named bones",unsigned(names.size()));
   for(const auto& name:names)log("Actor bone: %s",name.c_str());
  }
  for(const auto& name:names){
   if(!fishing::rightHandBoneName(name))continue;
   alignas(16) rh::Vec p{};
   bool ok=rh::invoke<0x30516389,bool>(object,name.c_str(),&p);
   if(!rigNamesLogged)log("Right-hand candidate: %s result=%d position=(%.3f %.3f %.3f)",name.c_str(),int(ok),p.x,p.y,p.z);
   if(ok&&handPositionValid(p,actor)){
    rigHandBone=name;handBone=rigHandBone.c_str();rigNamesLogged=true;
    log("Hand bone resolved from actor skeleton: %s",handBone);return;
   }
  }
 }else if(!rigNamesLogged)log("Actor skeleton enumeration unavailable: %s",reason);
 // Compatibility fallback for models/builds whose descriptor cannot be enumerated.
 for(const char* name:{"wrist_r","SKEL_R_Hand","skel_r_hand","R_Hand","r_hand","hand_r","Hand_R","Hand_Right","RightHand","RHand","rhand","Bip01 R Hand"}){
  alignas(16) rh::Vec p{};
  bool ok=rh::invoke<0x30516389,bool>(object,name,&p);
  if(!rigNamesLogged)log("Hand lookup: %s result=%d position=(%.3f %.3f %.3f)",name,int(ok),p.x,p.y,p.z);
  if(ok&&handPositionValid(p,actor)){
   handBone=name;rigNamesLogged=true;log("Hand bone found: %s",name);return;
  }
 }
 if(!rigNamesLogged)log("Hand not resolved; attachment pending (retry every second)");
 rigNamesLogged=true;
}
static rh::Vec handPosition(int actor){
 rh::Vec p{};
 if(handBone){
  int object=rh::invoke<0x4A2063EC,int>(actor);
  if(rh::invoke<0x30516389,bool>(object,handBone,&p)&&handPositionValid(p,actor))return p;
 }
 return actorPoint(actor,.35f,1.0f,.3f);
}
static void disablePropCollisions(int rod){
 if(!rh::validObject(rod))return;
 // These tackle props are visual only. RDR.exe handlers 0x1402331F0 / 0x140233230:
 // false sets the no-world/no-movables collision flags on this prop only.
 rh::invoke<0x601FC9F4>(rod,false);
 rh::invoke<0x05D69EA6>(rod,false);
}
static void disableRodCollisions(){disablePropCollisions(props[0].object);}
static bool attachRod(float dt,int actor){
 if(rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment))return true;
 rodAttachment=0;rodAttachRetry-=dt;
 if(rodAttachRetry>0||!rh::validObject(props[0].object))return false;
 rodAttachRetry=1.f;
 if(!handBone)findHandBone(actor);
 if(!handBone)return false;
 int parent=rh::invoke<0x4A2063EC,int>(actor);
 if(!rh::validObject(parent))return false;
 // RDR.exe 0x140230E80: child, parent, parent bone, packed offset,
 // offset Z, packed rotation, rotation Z, flags (8 native slots).
 rodAttachment=rh::invoke<0xE1421B42,int>(props[0].object,parent,handBone,
     rh::XY{0,0},0.f,rh::XY{0,0},0.f,0);
 bool attached=rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment);
 if(attached){
  // 0x1402DAA5C: preserve child rotation while the engine updates hand translation.
  rh::invoke<0xA870B28E>(rodAttachment,true);
  // Reapply after attachment initialization, before yielding to the physics frame.
  disableRodCollisions();
 }
 log("Rod attachment: bone=%s child=%d parent=%d attachment=%d valid=%d",
     handBone,props[0].object,parent,rodAttachment,int(attached));
 return attached;
}
static bool findWater(rh::Vec candidate,rh::Vec& hit){
 // RDR.exe 1.0.40 handler 0x1402965D0: two packed input vectors,
 // then two vector output pointers. The SDK's eight-int placeholder is incomplete.
 alignas(16) rh::Vec intersection{},normal{};
 float top=origin.y+8, bottom=origin.y-40;
 bool ok=rh::invoke<0x4F193BE4,bool>(rh::XY{candidate.x,top},candidate.z,rh::XY{candidate.x,bottom},candidate.z,&intersection,&normal,0,0);
 if(ok&&fishing::waterHitValid(geom(candidate),geom(intersection),top,bottom)){
  hit=intersection;log("Water hit at %.3f %.3f %.3f",hit.x,hit.y,hit.z);return true;
 }
 log("No water intersection at %.3f %.3f (result=%d xyz=%.3f %.3f %.3f)",candidate.x,candidate.z,int(ok),intersection.x,intersection.y,intersection.z);
 return false;
}
static bool prepareCast(int actor){
 origin=rh::position(actor);hasWaterTarget=false;
 if(!updateCastDirection()){
  notice="Cannot read camera direction.\nLook toward the water and try again.";noticeTime=4;
  log("Cast refused: camera direction unavailable or vertical");return false;
 }
 castRequestedDistance=fishing::chargedCastDistance(castCharge.heldSeconds,castDistance);
 log("Cast charge distance: seconds=%.3f power=%.3f requested=%.3fm maximum=%.3fm",castCharge.heldSeconds,fishing::castPower(castCharge.heldSeconds),castRequestedDistance,castDistance);
 log("Cast direction from camera: %.4f %.4f %.4f",forward.x,forward.y,forward.z);
 if(autoWater){
  // Prefer requested distance; shorten until we find a water surface ahead.
  for(float distance=castRequestedDistance;;distance=std::max(3.f,distance-2.f)){
   auto candidate=point(distance,0);
   if(findWater(candidate,waterTarget)){hasWaterTarget=true;break;}
   if(distance<=3.f)break;
  }
 }
 if(!hasWaterTarget){
  if(requireWater&&autoWater){notice="No water ahead.\nFace the water and press your cast key.";noticeTime=4;log("Cast refused: no verified water surface ahead");return false;}
  waterTarget=point(castRequestedDistance,waterOffset);hasWaterTarget=true;
  log("Manual water target: %.3f %.3f %.3f",waterTarget.x,waterTarget.y,waterTarget.z);
 }
 // Keep the model pivot slightly above water so the float remains visible.
 waterTarget.y+=.08f;
 game.castRange=std::hypot(waterTarget.x-origin.x,waterTarget.z-origin.z);
 game.castSeconds=fishing::castFlightSeconds(game.castRange,castAnimationEnabled);
 castTurn.reset();
 if(castAnimationEnabled){
  if(!castTurn.begin(geom(forward))){log("Cast refused: invalid facing direction");return false;}
  log("Cast facing target: heading=%.2f from release camera direction",castTurn.target);
 }
 noticeTime=0;castFlightReleased=!castAnimationEnabled;tackleMotion.prepare();
 log("Cast target: %.3f %.3f %.3f (player %.3f %.3f %.3f)",waterTarget.x,waterTarget.y,waterTarget.z,origin.x,origin.y,origin.z);
 return true;
}
static bool project(rh::Vec p,float& x,float& y){
 if(!rh::invoke<0xBAA72911,bool>(&p,&x,&y))return false;
 return std::isfinite(x)&&std::isfinite(y)&&x>=0&&x<=1&&y>=0&&y<=1;
}
static void drawRig(){
 using fishing::Phase;
 bool out=game.phase!=Phase::Off;
 if(!out||!tackleMotion.valid)return;
 if(showLine){
  RECT viewport{};
  if(!GetClientRect(GetForegroundWindow(),&viewport))return;
  int width=int(viewport.right-viewport.left),height=int(viewport.bottom-viewport.top);
  if(width<1||height<1)return;
  float invWidth=1.f/width,invHeight=1.f/height;
  bool previousValid=false,connected=false;int previousX=0,previousY=0;
  for(int i=0;i<=64;i++){
   float t=i/64.f;
   float sag=tackleMotion.whirling?.025f:std::min(.18f,std::hypot(lineTip.x-bobberPosition.x,lineTip.z-bobberPosition.z)*.03f);
   auto p=fishing::tackleLine(geom(lineTip),geom(bobberPosition),geom(hookPosition),t,sag);
   float x=0,y=0;
   if(!project(vector(p),x,y)){previousValid=false;connected=false;continue;}
   int px=std::clamp(int(std::lround(x*(width-1))),0,width-1);
   int py=std::clamp(int(std::lround(y*(height-1))),0,height-1);
   if(previousValid){
    fishing::solidLine(previousX,previousY,px,py,connected,[&](int left,int top,int w,int h){
     rh::drawRect((left+w*.5f)*invWidth,(top+h*.5f)*invHeight,w*invWidth,h*invHeight,220,225,215,190);
    });
    connected=true;
   }
   previousX=px;previousY=py;previousValid=true;
  }
 }
}
static void updateFish(float dt,rh::Vec hook){
 if(fishRequestPending){
  fishLoadTime+=dt;
  if(rh::invoke<0xD7F80035,bool>(fishAsset)){fishRequestPending=false;fishLoaded=true;log("Fish asset loaded: %s",fishModel.c_str());}
  else if(fishLoadTime>5){fishRequestPending=false;log("Fish asset unavailable: %s (no substitute model created)",fishModel.c_str());}
 }
 if(lineAction.kind==fishing::LineAction::Kind::Retrieve&&lineAction.committed){removeFish();return;}
 if(fishRelease.active())return;
 if(!fishVisiblePhase()){removeFish();return;}
 if(!fishLoaded)return;
 float fishYaw=std::atan2(forward.x,forward.z)*57.295779513f-90.f;
 float flutter=fishMouthOffset.x==0&&fishMouthOffset.y==0&&fishMouthOffset.z==0?
  (game.phase==fishing::Phase::Fight?fightMotion.fishRoll:10.f*std::sin(game.elapsed*10)):0.f;
 auto mouth=fishMouthOffset;
 if(game.phase==fishing::Phase::Caught){
  if(releaseSavedBone)hook=releaseHand(rh::player());
  auto grip=fishing::caughtFishGrip(geom(actorForward(rh::player())));
  hook.x+=grip.x;hook.y+=grip.y;hook.z+=grip.z;
  auto hang=fishing::fishHang(fishYaw,geom(mouth),game.elapsed);
  fishYaw=hang.yaw;flutter=hang.roll;mouth=vector(hang.mouth);
 }
 rh::Vec position{hook.x-mouth.x,hook.y-mouth.y,hook.z-mouth.z};
 if(!fishSpawnAttempted){
  fishSpawnAttempted=true;std::string path="$/fragments/"+fishModel;
  fishObject=rh::invoke<0xE351587D,int>(layout,"FishingHookedFish",path.c_str(),rh::XY{position.x,position.y},position.z,rh::XY{0,0},0.f,true);
  log("Fish spawn in %s: model=%s object=%d valid=%d",stateName(game.phase),fishModel.c_str(),fishObject,int(rh::validObject(fishObject)));
 }
 if(rh::validObject(fishObject)){
  float fishScale=fishing::fishScaleForWeight(game.weight);
  rh::move(fishObject,position);
  // Swimming yaw remains unchanged; only Caught blends to head-up hanging.
  bool rotated=rh::invoke<0xC8A4EE74,bool>(fishObject,rh::XY{0,fishYaw},flutter);
  fishScaleLogTime+=dt;
  if(rotated){
   disablePropCollisions(fishObject);
   const char* reason=nullptr;float observed=-1;
   bool applied=fishscale::apply(fishObject,fishScale,geom(mouth),reason,observed);
   if(!applied){rh::move(fishObject,position);rh::invoke<0xC8A4EE74,bool>(fishObject,rh::XY{0,fishYaw},flutter);}
   if(fishScaleLogTime>=2){fishScaleLogTime=0;log("Fish scale: object=%d weight=%.2fkg category=%s requested=%.2f observed=%.3f applied=%d reason=%s",fishObject,game.weight,game.weight<1?"small":game.weight<=5?"normal":"large",fishScale,observed,int(applied),reason);}
  }
 }
}
static void updateProps(float dt,int actor){
 if(!visuals||!layout||!rodVisible)return;
 loadTime+=dt;
 for(auto& p:props){if(p.done)continue;
  if(fishing::validAsset(p.asset)&&rh::invoke<0xD7F80035,bool>(p.asset)){
   auto at=actorPoint(actor,.4f,1);std::string path="$/fragments/";path+=p.name;
   p.object=rh::invoke<0xE351587D,int>(layout,p.name,path.c_str(),rh::XY{at.x,at.y},at.z,rh::XY{0,0},0.f,true);p.done=true;
   disablePropCollisions(p.object);
   if(&p==&props[0]&&rh::validObject(p.object)){
    disableRodCollisions();
    log("Rod collision disabled: object=%d world=0 movables=0",p.object);
   }
   log("Created %s: object=%d valid=%d",p.name,p.object,int(rh::validObject(p.object)));
  }else if(loadTime>5){p.done=true;log("Model unavailable: %s; continuing gameplay without it",p.name);}
 }
 int camera=rh::invoke<0x6B7677BF,int>();
 if(!rh::validObject(camera))camera=0;
 std::array<int,3> cameraProps{};
 for(unsigned i=0;i<cameraProps.size();++i)if(rh::validObject(props[i].object))cameraProps[i]=props[i].object;
 tackleCamera.sync(camera,cameraProps,
  [](int cam,int object,int flags){rh::invoke<0x5BBFA4D7>(cam,object,flags);},
  [](int cam,int object){if(rh::validObject(cam))rh::invoke<0x781D5599>(cam,object);});
 auto hand=handPosition(actor);
 // Procedural rod motion; body animation is not fabricated from unknown lasso clip names.
 float pitch=-12.f;
 if(game.phase==fishing::Phase::Cast){
  if(castFlightReleased)pitch=-55+90*std::clamp(game.elapsed/game.castSeconds,0.f,1.f);
  else pitch=-12-43*std::clamp(castProgress.last,0.f,1.f);
 }
 else if(game.phase==fishing::Phase::Wait&&castAnimation.stage==fishing::CastAnimation::Stage::BlendOut)
  pitch=35-47*std::clamp(castAnimation.elapsed/fishing::castBlendOut,0.f,1.f);
 else if(game.phase==fishing::Phase::Bite)pitch=-28+8*std::sin(game.elapsed*12);
 else if(game.phase==fishing::Phase::Fight)pitch=-20-game.tension*22+4*std::sin(game.elapsed*5)+fightMotion.rodPitch;
 bool rodAttached=attachRod(dt,actor);
 bool rodMoved=rodAttached;
 if(!rodAttached&&rh::validObject(props[0].object))
  rodMoved=rh::invoke<0xC5D796F8,bool>(props[0].object,rh::XY{hand.x,hand.y},hand.z);
 float spinPhase=-1;
 bool nativeSpin=castCharge.active&&!castCharge.released&&spinLayer.matched(actor,spinPhase);
 bool windingDown=tackleMotion.whirling&&(!castCharge.active||castCharge.released);
 bool spinning=game.phase==fishing::Phase::Cast&&!castFlightReleased&&(nativeSpin||windingDown);
 auto poleRotation=rodCone.rotation(spinning,dt,tackleMotion.angle,pitch,rh::invoke<0x42DE39F0,float>(actor));
 if(game.phase==fishing::Phase::Fight)poleRotation.z+=fightMotion.rodRoll;
 if(rh::validObject(props[0].object))rh::invoke<0xC8A4EE74,bool>(props[0].object,rh::XY{poleRotation.x,poleRotation.y},poleRotation.z);
 auto gripPose=fishing::GripPose::Neutral;
 if(game.phase==fishing::Phase::Ready)gripPose=fishing::GripPose::Ready;
 else if(game.phase==fishing::Phase::Wait||game.phase==fishing::Phase::Bite)gripPose=fishing::GripPose::Waiting;
 else if(game.phase==fishing::Phase::Fight)gripPose=fishing::GripPose::Fighting;
 auto gripDelta=rodGripPose.update(gripPose,dt,geom(actorForward(actor)));
 // Offset the grip in the current wrist frame; do not move the actor or reattach each frame.
 if(rodAttached){
  rh::Vec axes[3]{},tip{},base{};
  int parent=rh::invoke<0x4A2063EC,int>(actor);
  if(rig::basis(parent,handBone,axes)&&rh::invoke<0x30516389,bool>(props[0].object,"joint5",&tip)&&
     rh::invoke<0x31201B4C,bool>(props[0].object,&base)){
   fishing::Point basis[3]={geom(axes[0]),geom(axes[1]),geom(axes[2])},offset{};
   auto world=fishing::gripWorld({tip.x-base.x,tip.y-base.y,tip.z-base.z},geom(actorForward(actor)));
   world.x+=gripDelta.x;world.y+=gripDelta.y;world.z+=gripDelta.z;
   if(fishing::gripLocal(world,basis,offset)){
    rh::invoke<0xD4A54348>(rodAttachment,rh::XY{offset.x,offset.y},offset.z);
    static int loggedGrip=0;static auto loggedPose=fishing::GripPose::Neutral;
    if(loggedGrip!=rodAttachment||loggedPose!=gripPose){
     loggedGrip=rodAttachment;loggedPose=gripPose;
     auto correction=fishing::gripCorrection(gripPose);
     log("Rod grip profile: pose=%d right=%.3f vertical=%.3f blendSeconds=0.65",int(gripPose),correction.x,correction.y);
     log("Rod grip: attachment=%d shaftShift=-0.120 palmShift=0.025 sideShift=0.020 local=(%.4f %.4f %.4f)",rodAttachment,offset.x,offset.y,offset.z);
    }
   }
  }
 }
 auto rodFacing=actorForward(actor);
 lineTip={hand.x+rodFacing.x*1.7f,hand.y+1,hand.z+rodFacing.z*1.7f};
 // Use the actual rod tip when this model exposes its named terminal bone.
 if(rh::validObject(props[0].object)){
  rh::Vec tip{};
  if(rh::invoke<0x30516389,bool>(props[0].object,"joint5",&tip)&&fishing::finite(geom(tip))){
   float dx=tip.x-hand.x,dy=tip.y-hand.y,dz=tip.z-hand.z;
   if(dx*dx+dy*dy+dz*dz<100)lineTip=tip;
  }
 }
 using fishing::Phase;
 bool cast=game.phase==Phase::Cast;
 bool out=(cast&&castFlightReleased)||game.phase==Phase::Wait||game.phase==Phase::Bite||game.phase==Phase::Fight;
 if(lineAction.kind==fishing::LineAction::Kind::Retrieve&&lineAction.committed){
  auto to=geom(lineTip);to.y-=.35f;
  auto b=lineAction.retract(lineAction.bobber,to);to.y-=.20f;
  auto h=lineAction.retract(lineAction.hook,to);tackleMotion.commit(b,h,dt);
 }else if(out&&hasWaterTarget){
  if(cast)tackleMotion.fly(geom(lineTip),geom(waterTarget),game.elapsed/game.castSeconds,game.castSeconds,dt);
  else {
   auto at=waterTarget;
   if(game.emptyReeled>0){
    auto closePoint=point(2,0);closePoint.y=waterTarget.y;
    float fraction=std::clamp(game.emptyReeled/std::max(.01f,game.castRange-2.f),0.f,1.f);
    at=vector(fishing::mix(geom(waterTarget),geom(closePoint),fraction));
   }
   if(game.phase==Phase::Fight){
    auto closePoint=point(2,0);closePoint.y=waterTarget.y;
    at=vector(fishing::mix(geom(at),geom(closePoint),game.progress));
    at.x+=forward.z*fightMotion.side;at.z-=forward.x*fightMotion.side;
    at.y+=.025f*std::sin(game.elapsed*8)+fightMotion.vertical;
   }else if(game.phase==Phase::Bite)at.y+=.06f*std::sin(game.elapsed*18);
   else at.y+=.018f*std::sin(game.elapsed*3);
   auto hook=at;hook.y-=.3f;tackleMotion.commit(geom(at),geom(hook),dt);
  }
 }else if(spinning)tackleMotion.whirl(geom(lineTip),geom(forward),dt,spinPhase,fishing::subtract(geom(lineTip),geom(hand)));
 else tackleMotion.stow(geom(lineTip),dt);
 bobberPosition=vector(tackleMotion.bobber);hookPosition=vector(tackleMotion.hook);
 bool bobberMoved=rh::validObject(props[1].object)&&rh::invoke<0xC5D796F8,bool>(props[1].object,rh::XY{bobberPosition.x,bobberPosition.y},bobberPosition.z);
 auto hook=hookPosition;rh::move(props[2].object,hook);
 updateFish(dt,hook);
 drawRig();
 visualLogTime+=dt;
 if(visualLogTime>=2){
  visualLogTime=0;rh::Vec actual{};
  if(rh::validObject(props[1].object))rh::invoke<0x31201B4C,bool>(props[1].object,&actual);
  if(handBone){
   rh::Vec rod{};bool readRod=rh::invoke<0x31201B4C,bool>(props[0].object,&rod);
   log("Rod hand check: bone=%s attached=%d read=%d hand=(%.3f %.3f %.3f) rod=(%.3f %.3f %.3f)",handBone,int(rodAttached),int(readRod),hand.x,hand.y,hand.z,rod.x,rod.y,rod.z);
  }
  log("Rig %s: moveRod=%d moveFloat=%d desired=(%.3f %.3f %.3f) actual=(%.3f %.3f %.3f)",stateName(game.phase),int(rodMoved),int(bobberMoved),bobberPosition.x,bobberPosition.y,bobberPosition.z,actual.x,actual.y,actual.z);
  if(rh::validObject(fishObject)){rh::Vec fishAt{};rh::invoke<0x31201B4C,bool>(fishObject,&fishAt);log("Fish follows hook: object=%d hook=(%.3f %.3f %.3f) fish=(%.3f %.3f %.3f)",fishObject,hook.x,hook.y,hook.z,fishAt.x,fishAt.y,fishAt.z);}
 }
}
static bool rewardReady(){
 rewards::Snapshot state;
 bool ready=rewards::inspect(state);
 auto cache=rewards::cache();
 log("Reward preflight: valid=%d reason=%s cash=%.2f honor=%.2f cacheReadable=%d cacheReady=%d cacheHonor=%.2f (diagnostic only)",int(ready),rewards::reason,state.cash,state.honor,int(cache.readable),int(cache.ready),cache.honor);
 if(!ready){
  log("Reward unavailable: %s",rewards::reason);
  rh::help("Game reward unavailable. Fish retained; check Fishing.log.");
 }
 return ready;
}
static bool recordFishDecision(bool released){
 if(catchReward.paid)return true;
 float before=0,after=0;int price=fishing::fishSalePrice(game.weight);
 if(!catchReward.commit([&](){return rewards::apply(released,price,before,after);})){ 
  log("Reward FAILED: kind=%s weight=%.2f price=%d reason=%s",released?"honor":"money",game.weight,price,rewards::reason);
  rh::help("Game reward failed. Check Fishing.log.");return false;
 }
 log("Game reward verified: kind=%s before=%.2f after=%.2f delta=%.2f weight=%.2fkg",released?"honor":"money",before,after,after-before,game.weight);
 if(!released){
  static char message[160];snprintf(message,sizeof(message),"Fish sold: %.2f kg. Money +$%d.",game.weight,price);
  rh::help(message);notice=message;noticeTime=5.f;
 }else{
  log("Honor HUD: native stat message requested=%d label=sn_hnrr delta=%.0f capped=%d",int(after>before),after-before,int(after==before));
 }
 const char* key=released?"Released":"Kept";
 unsigned count=GetPrivateProfileIntA("Progress",key,0,iniPath.c_str());
 char value[32];snprintf(value,sizeof(value),"%u",count+1);
 if(!WritePrivateProfileStringA("Progress",key,value,iniPath.c_str()))log("Cannot save fish decision: %s",key);
 log("Fish decision: %s weight=%.2fkg totalCatches=%u",key,game.weight,game.catches);
 return true;
}
static void restoreReleaseRod(){
 if(!releaseSavedBone)return;
 if(rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment))rh::invoke<0xE894DC13>(rodAttachment);
 rodAttachment=0;rodAttachRetry=0;handBone=releaseSavedBone;releaseSavedBone=nullptr;
}
static rh::Vec releaseHand(int actor){
 rh::Vec at{};int parent=rh::invoke<0x4A2063EC,int>(actor);
 const char* bone=releaseSavedBone?releaseSavedBone:"wrist_r";
 if(rh::invoke<0x30516389,bool>(parent,bone,&at)&&handPositionValid(at,actor)){
  at.x+=forward.x*.07f;at.z+=forward.z*.07f;return at;
 }
 return actorPoint(actor,.35f,1.f);
}
static void finishFishRelease(bool landed,const char* reason){
 log("Fish release finished: landed=%d reason=%s",int(landed),reason);
 stopCastAnimation();fishRelease.reset();
 if(landed){removeFish();beginItemSequence(fishing::ItemSequence::Kind::Recover);}
 else rh::help("Release not completed. Fish retained; check Fishing.log or try again.");
}
static void beginFishRelease(){
 if(!hasWaterTarget||!rh::validObject(fishObject)){
  rh::help("Cannot release: fish or water target unavailable. You can keep the catch.");return;
 }
 stopCastAnimation();fightPose.reset();fightFrameTransition.reset();
 rh::Vec from{};rh::invoke<0x31201B4C,bool>(fishObject,&from);
 auto target=waterTarget;target.y-=.08f;
 fishRelease.begin(geom(from),geom(target));releaseAnimationDone=false;
 releaseStartup.reset();releaseQueryGap=0;releaseLogAge=0;
 if(!releaseSetRequested){rh::invoke<0x2988B3FC>(fishing::releaseAnimSet,0);releaseSetRequested=true;}
 // The throwing wrist is needed for the fish. Temporarily hold the pole in the left wrist.
 holdRodLeft();
 log("Fish release begun: clip=%s weight=%.2fkg target=(%.3f %.3f %.3f)",fishing::releaseClip,game.weight,target.x,target.y,target.z);
}
static void updateFishRelease(int actor,float dt){
 using Stage=fishing::FishRelease::Stage;
 fishRelease.age+=dt;
 if(fishRelease.stage==Stage::Loading){
  if(rh::invoke<0x4FFF397D,bool>(fishing::releaseAnimSet)){
   if(!bindCastAnimSet(actor,fishing::releaseAnimSet,true,false)){finishFishRelease(false,"bind failed");return;}
   // Native animset binding queues work. Let the engine process it before TASK_PLAY_ANIM.
   fishRelease.stage=Stage::Bound;
   log("Fish release animset ready; task scheduled for next script frame");
   return;
  }else if(fishRelease.age>5){finishFishRelease(false,"streaming timeout");return;}
  else return;
 }
 if(fishRelease.stage==Stage::Bound){
  fishing::requestThrowPreview([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,fishing::releaseClip);
  castTaskIssued=true;fishRelease.stage=Stage::Hand;fishRelease.age=0;
  log("Fish release animation requested: rate=1 loop=0 timer=-1 releasePhase=%.3f attempt=1",fishRelease.phase);
  return;
 }
 if(!fishRelease.active())return;
 bool playing=castTaskIssued&&rh::invoke<0x1ADE21EB,bool>(actor,fishing::releaseClip);
 float phase=playing?rh::invoke<0x8609F5E1,float>(actor,fishing::releaseClip):-1.f;
 if(playing){fishRelease.seen=true;releaseQueryGap=0;}
 else releaseQueryGap+=dt;
 releaseAnimationDone=fishRelease.seen&&!playing&&releaseQueryGap>=.25f;
 if(fishRelease.stage==Stage::Hand){
  auto command=releaseStartup.update(playing,dt);
  if(command==fishing::ReleaseStartup::Command::Failed){finishFishRelease(false,"no startup after three bounded requests");return;}
  if(command==fishing::ReleaseStartup::Command::Retry){
   castset::Snapshot current;const char* reason=nullptr;
   bool read=castset::snapshot(actor,current,reason);
   bool ours=read&&(sessionBaseResource?fishing::matchesBaseSession(sessionBaseResource,current.baseResource,current.resource,current.locked):current.resource==castSetResource);
   if(actor!=castAnimationActor||!ours){finishFishRelease(false,"animset ownership changed before startup retry");return;}
   rh::invoke<0x16876A25>(actor);
   fishing::requestThrowPreview([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,fishing::releaseClip);
   log("Fish release startup retry: attempt=%d playing=0 neverMatched=1",releaseStartup.requests);
  }
 }
 releaseLogAge+=dt;
 if(releaseLogAge>=.2f){
  releaseLogAge=0;log("Fish release playback: stage=%d playing=%d time=%.4f age=%.3f seen=%d attempts=%d",int(fishRelease.stage),int(playing),phase,fishRelease.age,int(fishRelease.seen),releaseStartup.requests);
 }
 auto hand=releaseHand(actor);
 if(fishRelease.launch(phase,geom(hand)))log("Fish detached from hand: clipTime=%.4f flightSeconds=%.3f",phase,fishRelease.duration);
 if(fishRelease.stage==Stage::Hand&&((releaseAnimationDone&&fishRelease.age>.3f)||fishRelease.age>6.f)){
  finishFishRelease(false,"clip ended/interrupted before throw phase");return;
 }
 if(fishRelease.fly(dt)){
  if(!recordFishDecision(true)){finishFishRelease(false,"honor reward failed; catch retained");return;}
  removeFish();catchResolved=true;
  gameWaterAudio.position=fishRelease.target;
  bool sound=waterAudio.play(fishing::WaterCue::Release,gameWaterAudio);
  launchSplash();releaseSplashTail=splashEmitter!=0;
  log("Released fish hit water: sample=0x%08X requested=%d xyz=(%.3f %.3f %.3f)",unsigned(waterAudio.lastSample),int(sound),fishRelease.target.x,fishRelease.target.y,fishRelease.target.z);
 }
 if(rh::validObject(fishObject)){
  fishing::Point at;
  float yaw=fishing::releasedFishYaw(geom(forward));
  float roll=0;
  if(fishRelease.stage==Stage::Flight){at=fishRelease.position();roll=15.f*std::sin(fishRelease.flight*12.f);}
  else at=fishing::mix(fishRelease.caught,geom(hand),std::clamp(fishRelease.age/.25f,0.f,1.f));
  rh::move(fishObject,vector(at));rh::invoke<0xC8A4EE74,bool>(fishObject,rh::XY{0,yaw},roll);
  disablePropCollisions(fishObject);
  const char* reason=nullptr;float observed=-1;
  fishscale::apply(fishObject,fishing::fishScaleForWeight(game.weight),{0,0,0},reason,observed);
 }
 if(splashEmitter){splashLife-=dt;if(splashLife<=0)stopSplash();}
 if(fishRelease.stage==Stage::Landed&&(releaseAnimationDone||fishRelease.age>12.f))finishFishRelease(true,"returned to fishing");
}
static void holdRodLeft(){
 if(releaseSavedBone)return;
 releaseSavedBone=handBone?handBone:"wrist_r";
 if(rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment))rh::invoke<0xE894DC13>(rodAttachment);
 rodAttachment=0;rodAttachRetry=0;handBone="wrist_l";
 log("Catch hands: rod=LEFT fish=RIGHT vertical=1");
}
static void hideTackle(){
 tackleCamera.clear([](int camera,int object){if(rh::validObject(camera))rh::invoke<0x781D5599>(camera,object);});
 if(rodAttachment&&rh::invoke<0x50305244,bool>(rodAttachment))rh::invoke<0xE894DC13>(rodAttachment);
 rodAttachment=0;rodAttachRetry=0;
 for(auto& prop:props){if(rh::validObject(prop.object))rh::invoke<0x21144994>(prop.object);prop.object=0;prop.done=false;}
 rodVisible=false;
}
static void beginItemSequence(fishing::ItemSequence::Kind kind){
 stopCastAnimation();fightPose.reset();fightFrameTransition.reset();
 itemSequence.begin(kind,game.weight);itemPreviewActive=true;
 // Stream every step up front, including the second draw set.
 for(int step=0;step<itemSequence.count;++step){
  int index=itemSequence.clips[step],resource=fishing::itemPreviewResourceIndex(index);
  if(!itemPreviewRequested[resource]){
   rh::invoke<0x2988B3FC>(fishing::itemPreviewClips[index].set,0);itemPreviewRequested[resource]=true;
  }
 }
 itemPreviewSelected=itemSequence.index();itemPreviewStage=0;
 itemPreviewAge=0;itemPreviewGap=0;itemPreviewLogAge=0;itemPreviewStartup.reset();
 if(kind==fishing::ItemSequence::Kind::Equip){rodVisible=false;catchResolved=false;}
 log("Item sequence begun: kind=%d weight=%.2f steps=%d",int(kind),game.weight,itemSequence.count);
}
static void finishItemSequence(bool success,const char* reason){
 using Kind=fishing::ItemSequence::Kind;
 auto kind=itemSequence.kind;bool committed=itemSequence.event;
 log("Item sequence finished: kind=%d success=%d committed=%d reason=%s",int(kind),int(success),int(committed),reason);
 stopCastAnimation();itemSequence.reset();itemPreviewActive=false;
 if(kind==Kind::Stow||(!success&&kind==Kind::Equip)){
  cleanup();game.enter(fishing::Phase::Off);return;
 }
 if(kind==Kind::Keep&&!committed){
  game.enter(fishing::Phase::Caught);rh::help("Fish not stored. Choose keep or release again.");return;
 }
 if(kind==Kind::Keep||kind==Kind::Recover){restoreReleaseRod();removeFish();catchResolved=true;game.enter(fishing::Phase::Ready);}
 if(kind==Kind::Equip)game.enter(fishing::Phase::Ready);
 origin=rh::position(rh::player());
}
static void itemSequenceEvent(){
 using Kind=fishing::ItemSequence::Kind;
 if(itemSequence.kind==Kind::Equip){rodVisible=true;loadTime=0;log("Rod appeared in right hand at draw phase");}
 else if(itemSequence.kind==Kind::Stow){hideTackle();log("Rod disappeared at stow phase");}
 else if(itemSequence.kind==Kind::Keep){
  if(!recordFishDecision(false)){
   itemSequence.event=false;finishItemSequence(false,"game sale failed before fish removal");return;
  }
  removeFish();catchResolved=true;restoreReleaseRod();
  log("Fish stored: fish disappeared, rod transferred LEFT -> RIGHT");
 }else if(itemSequence.kind==Kind::Recover){restoreReleaseRod();log("After release: rod transferred LEFT -> RIGHT");}
}
static bool updateItemSequence(int actor,float dt){
 if(!itemSequence.active())return false;
 itemPreviewSelected=itemSequence.index();
 const auto& clip=fishing::itemPreviewClips[itemPreviewSelected];
 itemPreviewAge+=dt;
 if(itemPreviewStage==0){
  int resource=fishing::itemPreviewResourceIndex(itemPreviewSelected);
  if(!itemPreviewRequested[resource]){rh::invoke<0x2988B3FC>(clip.set,0);itemPreviewRequested[resource]=true;}
  if(rh::invoke<0x4FFF397D,bool>(clip.set)){
   if(!bindCastAnimSet(actor,clip.set,true,false)){finishItemSequence(false,"bind failed");return true;}
   itemPreviewStage=1;itemPreviewAge=0;return true;
  }
  if(itemPreviewAge>5.f)finishItemSequence(false,"streaming timeout");
  return true;
 }
 if(itemPreviewStage==1){
  fishing::requestThrowPreview([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,clip.clip);
  castTaskIssued=true;itemPreviewStage=2;itemPreviewAge=0;
  log("Item sequence requested: kind=%d step=%d set=%s clip=%s rate=1 loop=0 timer=-1",int(itemSequence.kind),itemSequence.step,clip.set,clip.clip);
  return true;
 }
 bool playing=rh::invoke<0x1ADE21EB,bool>(actor,clip.clip);
 float phase=playing?rh::invoke<0x8609F5E1,float>(actor,clip.clip):-1.f;
 auto command=itemPreviewStartup.update(playing,dt);
 if(command==fishing::ReleaseStartup::Command::Failed){finishItemSequence(false,"no startup after bounded retries");return true;}
 if(command==fishing::ReleaseStartup::Command::Retry){
  castset::Snapshot current;const char* reason=nullptr;
  bool read=castset::snapshot(actor,current,reason);
  bool ours=read&&(sessionBaseResource?fishing::matchesBaseSession(sessionBaseResource,current.baseResource,current.resource,current.locked):current.resource==castSetResource);
  if(actor!=castAnimationActor||!ours){finishItemSequence(false,"ownership changed");return true;}
  rh::invoke<0x16876A25>(actor);
  fishing::requestThrowPreview([](auto... args){rh::invoke<0x5AB552C6>(args...);},actor,clip.clip);
  log("Item sequence startup retry: attempt=%d",itemPreviewStartup.requests);
 }
 if(playing)itemPreviewGap=0;else itemPreviewGap+=dt;
 if(itemSequence.eventDue(phase)){itemSequenceEvent();if(!itemSequence.active())return true;}
 itemPreviewLogAge+=dt;
 if(itemPreviewLogAge>=.2f){itemPreviewLogAge=0;log("Item sequence progress: kind=%d step=%d clip=%s playing=%d time=%.4f event=%d",int(itemSequence.kind),itemSequence.step,clip.clip,int(playing),phase,int(itemSequence.event));}
 if(itemPreviewStartup.matched&&!playing&&itemPreviewGap>=.25f){
  if(itemSequence.next()){
   stopCastAnimation();itemPreviewStage=0;itemPreviewAge=0;itemPreviewGap=0;itemPreviewLogAge=0;itemPreviewStartup.reset();
   log("Item sequence next step=%d",itemSequence.step);
  }else finishItemSequence(itemSequence.event,"native playback ended");
 }else if(itemPreviewAge>30.f)finishItemSequence(false,"30-second watchdog");
 return true;
}
static const char* label(fishing::UiText id){return fishing::uiText(id,language);}
static void uiDraw(const char* text,const char* fallback,float x,float y,float height,int alignment){
 if(!fishing::asciiText(text)){
  if(unicodeText.draw(text,x,y,height,alignment))return;
  static bool reported=false;
  if(!reported){log("Unicode UI fallback: %s",unicodeText.reason);reported=true;}
  text=fallback;
 }
 for(int dy=-1;dy<=1;++dy)for(int dx=-1;dx<=1;++dx)if(dx||dy)
  rh::drawText(text,x+dx/1920.f,y+dy/1080.f,0,height,0,0,0,255,alignment);
 rh::drawText(text,x,y,0,height,255,255,255,255,alignment);
}
static void hud(){
 using fishing::UiText;
 if(lostNoticeTime>0)uiDraw(label(UiText::Lost),"Fish got away",.035f,.105f,.024f,0);
 if(!hudEnabled||game.phase!=fishing::Phase::Caught||catchResolved||
    fishRelease.active()||itemSequence.active()||recastActive)return;
 static std::string keepLabel,releaseLabel;
 keepLabel=keyName(keepKey);releaseLabel=keyName(releaseKey);
 static char summary[256],englishSummary[256];
 auto size=fishing::sizeLabel(game.weight);
 snprintf(summary,sizeof(summary),"%s: %s | %s: %.2f %s",label(UiText::Size),label(size),label(UiText::Weight),game.weight,language==fishing::Language::Russian?"кг":"kg");
 snprintf(englishSummary,sizeof(englishSummary),"Size: %s | Weight: %.2f kg",fishing::uiText(size,fishing::Language::English),game.weight);
 uiDraw(summary,englishSummary,.962f,.817f,hudTextHeight,2);
 auto row=[](UiText caption,const std::string& key,int code,float y){
  float width=std::clamp(.013f*float(key.size())+.016f,.028f,.14f);
  float right=.962f,left=right-width;
  rh::drawRect(left+width*.5f,y+.014f,width+.003f,.041f,0,0,0,240);
  rh::drawRect(left+width*.5f,y+.014f,width,.037f,48,48,48,245);
  uiDraw(label(caption),fishing::uiText(caption,fishing::Language::English),left-.012f,y,hudTextHeight,2);
  // Storage persists until the queued draw consumes it.
  static char keepFallback[24],releaseFallback[24];
  char* fallback=caption==UiText::Sell?keepFallback:releaseFallback;
  snprintf(fallback,24,"VK%d",code);
  uiDraw(key.c_str(),fallback,left+width*.5f,y,hudTextHeight,1);
 };
 row(UiText::Sell,keepLabel,keepKey,.865f);
 row(UiText::Release,releaseLabel,releaseKey,.915f);
}
static void script(){
 char path[MAX_PATH];GetModuleFileNameA(module,path,MAX_PATH);std::string root=path;root=root.substr(0,root.find_last_of("\\/")+1);iniPath=root+"Fishing.ini";logPath=root+"Fishing.log";
 char languageSetting[24]{};
 GetPrivateProfileStringA("UI","Language","en",languageSetting,sizeof(languageSetting),iniPath.c_str());
 language=fishing::uiLanguage(languageSetting);
 char existingLanguage[24]{};
 GetPrivateProfileStringA("UI","Language","",existingLanguage,sizeof(existingLanguage),iniPath.c_str());
 if(!existingLanguage[0])WritePrivateProfileStringA("UI","Language","en",iniPath.c_str());
 log("UI language=%s",language==fishing::Language::Russian?"ru":"en");
 castAnimationEnabled=GetPrivateProfileIntA("Animation","Cast",1,iniPath.c_str())!=0;
 fightPoseEnabled=GetPrivateProfileIntA("Animation","Fight",1,iniPath.c_str())!=0;
 hudEnabled=GetPrivateProfileIntA("HUD","CatchPrompts",1,iniPath.c_str())!=0;
 hudTextHeight=std::clamp(GetPrivateProfileIntA("HUD","PromptTextHeightPermille",22,iniPath.c_str()),14u,30u)/1000.f;
 char fishName[160]{};
 GetPrivateProfileStringA("Fish","Model","p_gen_fish02x",fishName,sizeof(fishName),iniPath.c_str());
 fishModel=fishName;
 if(fishModel=="p_gen_fish01x"){fishModel="p_gen_fish02x";log("Replaced sliced fish01 with intact fish02");}
 if(!GetPrivateProfileIntA("Fish","Enabled",1,iniPath.c_str()))fishModel.clear();
 // Resource names only: do not accept paths or a local WFT masquerading as an installed asset.
 if(fishModel.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")!=std::string::npos)fishModel.clear();
 fishMouthOffset={std::clamp(int(GetPrivateProfileIntA("Fish","MouthOffsetXcm",0,iniPath.c_str())),-500,500)/100.f,std::clamp(int(GetPrivateProfileIntA("Fish","MouthOffsetYcm",0,iniPath.c_str())),-500,500)/100.f,std::clamp(int(GetPrivateProfileIntA("Fish","MouthOffsetZcm",0,iniPath.c_str())),-500,500)/100.f};
 visuals=GetPrivateProfileIntA("Fishing","Visuals",1,iniPath.c_str())!=0;
 waterOffset=std::clamp(int(GetPrivateProfileIntA("Fishing","WaterOffsetCm",-65,iniPath.c_str()))/100.f,-5.f,2.f);
 autoWater=GetPrivateProfileIntA("Fishing","AutoWater",1,iniPath.c_str())!=0;
 requireWater=GetPrivateProfileIntA("Fishing","RequireWater",1,iniPath.c_str())!=0;
 showLine=GetPrivateProfileIntA("HUD","ShowLine",1,iniPath.c_str())!=0;
 int configuredCastDistance=int(GetPrivateProfileIntA("Fishing","CastDistance",10,iniPath.c_str()));
 // Migrate the previous default without replacing the user's INI or statistics.
 castDistance=float(std::clamp(configuredCastDistance==9?10:configuredCastDistance,3,10));
 if(GetPrivateProfileIntA("Keys","LayoutVersion",0,iniPath.c_str())<2){
  struct DefaultKey {const char* name;int value;};
  for(auto binding:{DefaultKey{"Toggle",VK_F6},{"Spin",VK_RBUTTON},{"Cast",VK_LBUTTON},
       {"Hook",VK_LBUTTON},{"Reel",VK_SPACE},{"Ease",VK_SHIFT},{"Retrieve",'E'},{"Keep",'E'},{"Release",'F'}}){
   char existing[32]{};GetPrivateProfileStringA("Keys",binding.name,"",existing,sizeof(existing),iniPath.c_str());
   bool legacy=(std::strcmp(binding.name,"Reel")==0&&std::strcmp(existing,"82")==0)||
               (std::strcmp(binding.name,"Ease")==0&&std::strcmp(existing,"81")==0);
   if(!existing[0]||legacy){
    char value[16];snprintf(value,sizeof(value),"%d",binding.value);
    if(!WritePrivateProfileStringA("Keys",binding.name,value,iniPath.c_str()))log("Cannot add binding: %s",binding.name);
   }
  }
  WritePrivateProfileStringA("Keys","LayoutVersion","2",iniPath.c_str());
 }
 toggleKey=readKey("Toggle",VK_F6);spinKey=readKey("Spin",VK_RBUTTON);
 actionKey=readKey("Cast",VK_LBUTTON);hookKey=readKey("Hook",VK_LBUTTON);
 reelKey=readKey("Reel",VK_SPACE);easeKey=readKey("Ease",VK_SHIFT);
 retrieveKey=readKey("Retrieve",'E');keepKey=readKey("Keep",'E');releaseKey=readKey("Release",'F');
 toggleName=keyName(toggleKey);actionName=keyName(actionKey);reelName=keyName(reelKey);easeName=keyName(easeKey);
 log("Bindings: toggle=%d spin=%d cast=%d hook=%d reel=%d ease=%d retrieve=%d keep=%d release=%d",toggleKey,spinKey,actionKey,hookKey,reelKey,easeKey,retrieveKey,keepKey,releaseKey);
 game.biteWindow=std::clamp(GetPrivateProfileIntA("Fishing","BiteWindowSeconds",6,iniPath.c_str())*1.f,3.f,20.f);
 game.catches=GetPrivateProfileIntA("Progress","Catches",0,iniPath.c_str());savedCatches=game.catches;game.seed=GetTickCount();
 log("v0.1.97-RDR-1.0.42 loaded. Toggle=%s action=%s reel=%s ease=%s visuals=%d biteWindow=%.1f",toggleName.c_str(),actionName.c_str(),reelName.c_str(),easeName.c_str(),int(visuals),game.biteWindow);
 log("HUD enabled=%d textHeight=%.3f (fraction of screen height)",int(hudEnabled),hudTextHeight);
 log("Fish model=%s (pivot anchor; mouth alignment unverified)",fishModel.empty()?"disabled":fishModel.c_str());
 reelAudio.seed=uint32_t(GetTickCount64())^GetCurrentProcessId()^0x9e3779b9u;
 waterAudio.seed=uint32_t(GetTickCount64())^0x6a09e667u;
 reelAudio.fixed=-1;
 log("Reel: MENU_INITPARAMS fixed relative gain0dB; game/system/speaker volume unchanged");
 for(const auto& clip:fishing::reelClips)log("Reel clip: sample=0x%08X event=%s",unsigned(clip.sample),clip.event);
 float previous=rh::invoke<0x5842B9D1,float>();

 while(true){
  rh::wait(0);
  float now=rh::invoke<0x5842B9D1,float>();float frameElapsed=std::max(0.f,now-previous);float dt=std::clamp(frameElapsed,0.f,.1f);previous=now;
  DWORD foregroundPid=0;
  GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);
  bool toggleEdge=toggleButton.sample((GetAsyncKeyState(toggleKey)&0x8000)!=0);
  bool actionDown=(GetAsyncKeyState(actionKey)&0x8000)!=0;
  bool castEdge=actionButton.sample(actionDown);
  bool hookEdge=hookButton.sample((GetAsyncKeyState(hookKey)&0x8000)!=0);
  bool actionEdge=game.phase==fishing::Phase::Bite?hookEdge:castEdge;
  bool spinDown=(GetAsyncKeyState(spinKey)&0x8000)!=0;
  bool spinEdge=spinButton.sample(spinDown);
  bool keepEdge=keepButton.sample((GetAsyncKeyState(keepKey)&0x8000)!=0);
  bool releaseEdge=releaseButton.sample((GetAsyncKeyState(releaseKey)&0x8000)!=0);
  if(foregroundPid!=GetCurrentProcessId()||rh::invoke<0x57246C02,bool>()){reelAudio.stop(gameReelAudio);reelMenuAudio.reset();payoutMenuAudio.reset();castSound.update(0,gameReelAudio);waterAudio.stop(gameWaterAudio);stopSplash();continue;}
  lostNoticeTime=std::max(0.f,lostNoticeTime-dt);
  int a=rh::player();bool alive=rh::validActor(a)&&!rh::invoke<0x0D798FFE,bool>(a);
  if(game.phase!=fishing::Phase::Off&&(!alive||!rh::invoke<0x63D6551C,bool>(a))){cleanup();game.enter(fishing::Phase::Off);log("Stopped: player unavailable or not on foot");}
  if(toggleEdge){
   if(game.phase!=fishing::Phase::Off){
    if(itemSequence.active()||fishRelease.active()||recastActive){cleanup();game.enter(fishing::Phase::Off);log("Stopped by player during item animation");}
    else beginItemSequence(fishing::ItemSequence::Kind::Stow);
   }
   else if(alive&&rh::invoke<0x63D6551C,bool>(a)){
    origin=rh::position(a);float h=rh::invoke<0x42DE39F0,float>(a)*.01745329252f;forward={std::sin(h),0,std::cos(h)};updateCastDirection();game.enter(fishing::Phase::Ready);updateWeaponHold(a);findHandBone(a);requestProps();requestCastAnimSet();requestFightAnimSet();log("Enabled at %.3f %.3f %.3f heading %.3f",origin.x,origin.y,origin.z,h);
    beginItemSequence(fishing::ItemSequence::Kind::Equip);
   }
  }
  if(game.phase==fishing::Phase::Off){reelAudio.stop(gameReelAudio);reelMenuAudio.reset();payoutMenuAudio.reset();castSound.update(0,gameReelAudio);waterAudio.stop(gameWaterAudio);stopSplash();continue;}
  auto pos=rh::position(a);float dx=pos.x-origin.x,dz=pos.z-origin.z;
  if(!fishRelease.active()&&!itemPreviewActive&&!recastActive&&dx*dx+dz*dz>4){cleanup();game.enter(fishing::Phase::Off);rh::help("Fishing stopped: moved away from casting spot.");log("Stopped: player moved");continue;}
  blockFishingInputs(true);
  updateWeaponHold(a);
  bool wasRecastPreview=recastActive;
  if(updateRecastPreview(a,dt)){
   if(wasRecastPreview&&!recastActive)origin=rh::position(a);
   updateProps(dt,a);castSound.update(dt,gameReelAudio);waterAudio.update(dt,gameWaterAudio);
   updateSplashes(dt);hud();continue;
  }
  if(updateItemSequence(a,dt)){
   updateProps(dt,a);castSound.update(dt,gameReelAudio);waterAudio.update(dt,gameWaterAudio);
   if(splashEmitter){splashLife-=dt;if(splashLife<=0)stopSplash();}
   hud();continue;
  }
  if(game.phase==fishing::Phase::Caught&&!fishRelease.active()){
   if(releaseEdge&&rewardReady())beginFishRelease();
   else if(keepEdge&&rewardReady())beginItemSequence(fishing::ItemSequence::Kind::Keep);
   actionEdge=false; // Only E/F resolve a caught fish; mouse cannot discard it.

  }
  if(itemSequence.active()){updateProps(dt,a);hud();continue;}
  if(fishRelease.active()){
   updateProps(dt,a);updateFishRelease(a,dt);
   castSound.update(dt,gameReelAudio);waterAudio.update(dt,gameWaterAudio);
   hud();continue;
  }
  noticeTime=std::max(0.f,noticeTime-dt);
  auto old=game.phase;
  auto castCommand=fishing::castInput(old==fishing::Phase::Ready,castCharge,spinDown,spinEdge,actionEdge);
  bool chargeStarted=castCommand==fishing::CastInput::Begin;
  bool confirm=castCommand==fishing::CastInput::Confirm||(chargeStarted&&actionEdge);
  if(chargeStarted){
   castSound.reset(gameReelAudio);
   origin=rh::position(a);hasWaterTarget=false;castTurn.reset();tackleMotion.prepare();
   castCharge.begin();castFlightReleased=false;noticeTime=0;
   actionEdge=true; // Begin Game::Cast for RMB as well as an immediate LMB cast.
   log("Cast charge begun: RMB hold, free camera; LMB confirms; release RMB cancels");
  }
  if(castCommand==fishing::CastInput::Cancel){
   stopCastAnimation();castCharge.reset();castFlightReleased=false;hasWaterTarget=false;
   tackleMotion.prepare();game.enter(fishing::Phase::Ready);actionEdge=false;
   log("RMB released before LMB: spin cancelled, no cast");
  }else if(castCharge.active&&!castCharge.released){
   if(!chargeStarted)castCharge.advance(frameElapsed);
   updateCastDirection();
   if(confirm){
    castCharge.observe(false);
    if(!prepareCast(a)){
     stopCastAnimation();castCharge.reset();castFlightReleased=false;hasWaterTarget=false;
     game.enter(fishing::Phase::Ready);actionEdge=false;
     log("LMB cast cancelled: no valid camera/water target");
    }else if(!castAnimationEnabled){
     castCharge.reset();castFlightReleased=true;game.elapsed=0;tackleMotion.beginFlight();
    }
   }
  }
  if(actionEdge)log("Action pressed in %s at %.2f s%s",stateName(old),game.elapsed,old==fishing::Phase::Wait?" (waiting for bite; ignored)":"");
  bool reeling=(GetAsyncKeyState(reelKey)&0x8000)!=0;
  bool easing=(GetAsyncKeyState(easeKey)&0x8000)!=0;
  float tensionBefore=game.tension,progressBefore=game.progress;
  bool pullingBefore=game.pulling();
  game.update(fishing::castGameStep(old==fishing::Phase::Cast,castFlightReleased,dt),{actionEdge,reeling,easing});
  if(old==fishing::Phase::Fight&&game.phase==fishing::Phase::Fight&&pullingBefore!=game.pulling())
   log("Fish struggle transition: pulling=%d calmSeconds=%.3f",int(game.pulling()),game.struggle.restSeconds);
  fightMotion.update(game.phase==fishing::Phase::Fight,game.pulling(),dt,game.elapsed);
  auto waterCue=waterTriggers.update(game.phase,castFlightReleased,game.pulling());
  if(waterCue!=fishing::WaterCue::None){
   gameWaterAudio.position=waterCue==fishing::WaterCue::Landing?geom(waterTarget):
    waterCue==fishing::WaterCue::Caught||!hasWaterTarget?geom(rh::position(a)):geom(bobberPosition);
   bool requested=waterAudio.play(waterCue,gameWaterAudio);
   log("Water sound: situation=%d sample=0x%08X channel=%d gainDb=%.1f requested=%d reason=%s",int(waterCue),unsigned(waterAudio.lastSample),waterAudio.sound[int(waterCue)],fishing::waterGainDb(waterAudio.lastSample),int(requested),gameWaterAudio.reason);
  }
  uint64_t reelPlaysBefore=reelMenuAudio.playCount;
  bool reelWanted=fishing::reelSoundWanted(game.phase==fishing::Phase::Fight||game.phase==fishing::Phase::Wait,reeling,easing,true,false);
  float clickInterval=game.phase==fishing::Phase::Wait?.70f:fishing::reelClickIntervalForWeight(game.weight);
  reelMenuAudio.updateWithPick(reelWanted,dt,[](){return reelAudio.choose();},gameReelAudio,clickInterval);
  if(reelMenuAudio.playCount!=reelPlaysBefore)
   log("Reel click: sample=0x%08X mode=MENU_INITPARAMS gainDb=0 interval=%.2f phase=%s",unsigned(fishing::reelClips[reelAudio.selected].sample),clickInterval,stateName(game.phase));
  bool payingOut=game.phase==fishing::Phase::Fight&&easing&&(tensionBefore>0||progressBefore>0);
  auto payoutBefore=payoutMenuAudio.playCount;
  payoutMenuAudio.updateWithPick(payingOut,dt,[](){return payoutPick.choose();},gameReelAudio,.22f);
  if(payoutMenuAudio.playCount!=payoutBefore)log("Line payout click: sample=0x%08X tension=%.3f progress=%.3f",unsigned(fishing::payoutClips[payoutPick.selected].sample),game.tension,game.progress);
  audioTestLogAge+=dt;
  if(audioTestLogAge>=.5f&&game.phase==fishing::Phase::Fight){
   audioTestLogAge=0;
   log("Audio coexistence: mode=MENU_INITPARAMS SPACE=%d SHIFT=%d wanted=%d struggleID=%d",int(reeling),int(easing),int(reelWanted),waterAudio.sound[1]);
  }
  if(old!=game.phase){
   if(old==fishing::Phase::Wait&&game.phase==fishing::Phase::Ready)log("Empty tackle fully reeled in: %.3fm, catches unchanged=%u",game.emptyReeled,game.catches);
   if(game.phase==fishing::Phase::Caught){catchResolved=false;catchReward.reset();holdRodLeft();}
   if(game.phase==fishing::Phase::Cast){
    fishScaleLogTime=2;
    log("Fish roll: weight=%.2fkg category=%s scale=%.1fx reelSpeed=%.2fx",game.weight,game.weight<1?"small":game.weight<=5?"normal":"large",fishing::fishScaleForWeight(game.weight),fishing::reelSpeedForWeight(game.weight));
   }
   log("State %s -> %s (wait=%.2f tension=%.2f progress=%.2f)",stateName(old),stateName(game.phase),game.wait,game.tension,game.progress);
   if(game.phase==fishing::Phase::Bite)log("BITE: press %s within %.1f seconds",actionName.c_str(),game.biteWindow);
   if(old==fishing::Phase::Bite&&game.phase==fishing::Phase::Lost)log("Missed bite: no new Action press during bite window");
  }
  if(game.phase==fishing::Phase::Lost){
   stopCastAnimation();fightPose.reset();fightFrameTransition.reset();hookFightFastBlend=false;
   castCharge.reset();castFlightReleased=false;hasWaterTarget=false;
   removeFish();restoreReleaseRod();tackleMotion.reset();fightMotion.reset();
   reelAudio.stop(gameReelAudio);reelMenuAudio.reset();payoutMenuAudio.reset();
   castSound.reset(gameReelAudio);waterAudio.stop(gameWaterAudio);waterTriggers.reset();stopSplash();
   game.recoverLoss();lostNoticeTime=3.f;
   log("Fish lost: immediate Ready, no recast cooldown; notice only for3s");
  }
  if(game.catches!=savedCatches)save();
  if(old==fishing::Phase::Bite&&game.phase==fishing::Phase::Fight){
   beginLineAction(fishing::LineAction::Kind::Hook);
   updateProps(dt,a);hud();continue;
  }
  if(!fightPose.owned&&(fightPose.stage==fishing::FightPose::Stage::Idle||!fightPoseEnabled))updateCastAnimation(a,dt);
  updateFightPose(a,dt);
  if(game.phase==fishing::Phase::Cast&&castFlightReleased&&!castSound.played){
   bool started=castSound.launch(gameReelAudio);
   log("Cast throw sound: event=%s requested=%d",fishing::castWhooshEvent,int(started));
  }
  castSound.update(dt,gameReelAudio);
  waterAudio.update(dt,gameWaterAudio);
  updateProps(dt,a);updateSplashes(dt);hud();
 }
}
BOOL WINAPI DllMain(HMODULE m,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH){module=m;DisableThreadLibraryCalls(m);if(!rh::bind())return FALSE;rh::reg(m,script);}
 else if(reason==DLL_PROCESS_DETACH&&rh::unreg){blockFishingInputs(false);rh::unreg(m);}
 return TRUE;
}
