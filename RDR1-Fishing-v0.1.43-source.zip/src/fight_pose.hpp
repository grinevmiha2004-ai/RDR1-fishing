#pragma once
#include <algorithm>
#include <cmath>
#include "cast_playback.hpp"
namespace fishing {
inline constexpr const char* fightAnimSet="lso_base";
inline constexpr const char* fightHoldClip="nor_lso_pul_wlk_000";
// Start at normal speed so the native task evaluates/blends the pose.
// Seek only this matched task after advancement; never change global speed.
inline constexpr float fightStopAfter=1.8f;
// Let the native clip actually play, then capture its current phase.
// Negative sample means no seek: the task continues at its normal rate.
struct FightFrameTransition {
 bool started=false,held=false;
 float elapsed=0,frame=-1;
 void reset(){started=false;held=false;elapsed=0;frame=-1;}
 float sample(float observed,float dt){
  if(held)return frame;
  if(!started){started=true;return -1;}
  elapsed+=std::isfinite(dt)?std::clamp(dt,0.f,.1f):0.f;
  if(elapsed+1e-5f<fightStopAfter||!std::isfinite(observed)||observed<0)return -1;
  frame=std::clamp(observed,0.f,.999f);held=true;return frame;
 }
};
template<class Native> void requestFightClip(Native native,int actor){
 native(actor,fightHoldClip,.65f,castBlendOut,1.f,0,true,false,castTaskTimer);
}
// One owned animation session per Fight. Never restart a running/finished hold.
struct FightPose {
 enum class Stage {Idle,Loading,Bound,Starting,Holding,Failed};
 enum class Command {None,Request,Retry,Release};
 Stage stage=Stage::Idle;
 bool owned=false,retried=false,matched=false;
 float elapsed=0,last=-1;
 template<class Bind> Command update(bool fighting,bool loaded,float dt,bool playing,float time,Bind bind,bool staticPose=false){
  if(!fighting){bool release=owned;reset();return release?Command::Release:Command::None;}
  dt=std::isfinite(dt)?std::clamp(dt,0.f,.1f):0.f;
  if(stage==Stage::Failed)return Command::None;
  if(stage==Stage::Idle){stage=Stage::Loading;elapsed=0;}
  if(stage==Stage::Loading){
   if(loaded){if(!bind()){stage=Stage::Failed;return Command::None;}owned=true;stage=Stage::Bound;elapsed=0;}
   else {elapsed+=dt;if(elapsed>=2.f)stage=Stage::Failed;}
   return Command::None;
  }
  if(stage==Stage::Bound){stage=Stage::Starting;elapsed=0;return Command::Request;}
  elapsed+=dt;
  if(stage==Stage::Starting){
   matched=matched||playing;
   if(playing&&std::isfinite(time)&&time>=0){
    bool advanced=last>=0&&(staticPose||std::abs(time-last)>.0001f);last=time;
    if(advanced){stage=Stage::Holding;elapsed=0;return Command::None;}
   }
   if(elapsed>=1.f){stage=Stage::Failed;owned=false;return Command::Release;}
   if(!matched&&!playing&&!retried&&elapsed>=.25f){retried=true;return Command::Retry;}
  }else if(stage==Stage::Holding){
   // Allow a brief query gap. A real interruption ends this session; do not fight other tasks.
   if(playing)elapsed=0;
   else if(elapsed>=.25f){stage=Stage::Failed;owned=false;return Command::Release;}
  }
  return Command::None;
 }
 void reset(){stage=Stage::Idle;owned=false;retried=false;matched=false;elapsed=0;last=-1;}
};
}
