#pragma once
#include "cast_animset.hpp"
#include "spin_additive_plan.hpp"
#include <initializer_list>
namespace spinlayer {
inline bool fingerprint(uintptr_t address,std::initializer_list<unsigned char> expected){
 unsigned char actual[64]{};
 if(expected.size()>sizeof(actual)||!ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<const void*>(address),actual,expected.size(),nullptr))return false;
 size_t i=0;for(auto b:expected)if(actual[i++]!=b)return false;
 return true;
}
inline bool profile(uintptr_t base){
 if(!fingerprint(base+0xce7af0,{0x40,0x53,0x56,0x57,0x41,0x54,0x41,0x55,0x41,0x56,0x41,0x57,0x48,0x81,0xec,0x90}))return false;
 if(!fingerprint(base+0xcedf50,{0x44,0x88,0x4c,0x24,0x20,0x44,0x88,0x44,0x24,0x18,0x48,0x89,0x54,0x24,0x10,0x53}))return false;
 if(!fingerprint(base+0x26ef30,{0x48,0x89,0x5c,0x24,0x10,0x57,0x48,0x83,0xec,0x20,0x48,0x8b,0x3a,0x48,0x8b,0xd9}))return false;
 if(!fingerprint(base+0xd42020,{0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x57,0x48,0x83,0xec,0x40,0x48}))return false;
 if(!fingerprint(base+0xd4275c,{0x83,0xfe,0x01,0x75,0x3e,0xc7,0x44,0x24,0x38,0x00,0x00,0x00,0x00,0x83,0x78,0x24,0x01,0xf3,0x0f,0x10,0x40,0x34,0xf3,0x0f,0x10,0x48,0x30,0x41,0x0f,0x94,0xc1,0xf3,0x0f,0x11,0x74,0x24,0x30,0x45,0x33,0xc0,0xf3,0x0f,0x11,0x44,0x24,0x28,0xf3,0x0f,0x11,0x4c,0x24,0x20,0xe8,0xbb,0xb7,0xfa,0xff}))return false;
 return true;
}
using Lookup=void(*)(uintptr_t,uintptr_t*,uint32_t,const char*,bool,uintptr_t);
using Play=bool(*)(uintptr_t,uintptr_t*,bool,bool,float,float,float,int);
using Assign=uintptr_t*(*)(uintptr_t*,const uintptr_t*);
using Leave=bool(*)(uintptr_t);
inline uint32_t key(const char* s){
 uint32_t h=0;for(;*s;++s){h+=uint8_t(*s);h+=h<<10;h^=h>>6;}
 h+=h<<3;h^=h>>11;return h+(h<<15);
}
struct Session {
 uintptr_t component=0,resource=0;
 bool attempted=false;
 const char* reason="idle";
 bool matched(int actor,float& phase){
  phase=-1;castset::Snapshot snap;const char* why=nullptr;
  if(!resource||!castset::snapshot(actor,snap,why)||snap.component!=component)return false;
  std::array<uintptr_t,6> slots{};if(!rig::read(component+0xb40,slots))return false;
  for(size_t i=0;i<slots.size();++i)if(slots[i]==resource){rig::read(component+0xb70+i*4,phase);return true;}
  return false;
 }
 void stop(int actor){
  if(!resource){component=0;attempted=false;return;}
  uintptr_t base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
  if(profile(base)){
   float phase=-1;
   if(matched(actor,phase)){
    fishing::AdditiveLeaveContext context(component,resource);
    reinterpret_cast<Leave>(base+0xd42020)(reinterpret_cast<uintptr_t>(context.state.data()));
   }
   uintptr_t empty=0;
   reinterpret_cast<Assign>(base+0x26ef30)(&resource,&empty);
  }
  resource=0;component=0;attempted=false;
 }
 bool start(int actor,const char* clip){
  if(attempted)return resource!=0;
  attempted=true;
  castset::Snapshot snap;const char* why=nullptr;
  uintptr_t base=reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr));
  if(!castset::snapshot(actor,snap,why)){reason=why;return false;}
  if(!profile(base)){reason="unsupported additive function fingerprints";return false;}
  component=snap.component;
  std::array<uintptr_t,6> slots{};uintptr_t context=0,linked=0,custom=0;uint32_t capacity=0;
  if(!rig::read(component+0xb40,slots)||!fishing::additiveSlotsFree(slots)){
   reason="existing additive layers; refusing to replace";return false;
  }
  if(!rig::read(component+0xaa8,context)||!context||!rig::read(context+0x50,linked)||!linked||
     !rig::read(component+0xa18,custom)||!custom||!rig::read(component+0x970,capacity)||capacity==0){
   reason="additive animation context/capacity unavailable";return false;
  }
  reinterpret_cast<Lookup>(base+0xce7af0)(component,&resource,key(clip),clip,false,0);
  if(!resource){reason="additive clip lookup returned no resource";return false;}
  bool accepted=fishing::requestAdditiveSpin(reinterpret_cast<Play>(base+0xcedf50),component,&resource);
  float phase=-1;
  if(!accepted||!matched(actor,phase)){
   reason="additive layer rejected or not attached";
   stop(actor);attempted=true;return false;
  }
  reason="additive layer attached";return true;
 }
};
}
