#pragma once
#include <array>
#include <cstdint>
#include <cstring>
namespace fishing {
inline constexpr const char* castSpinBase="nor_lso_stn_aup";
inline bool additiveSlotsFree(const std::array<uintptr_t,6>& slots){
 for(auto p:slots)if(p)return false;
 return true;
}
template<class Play> bool requestAdditiveSpin(Play play,uintptr_t component,uintptr_t* resource){
 return play(component,resource,false,true,.1f,.15f,1.f,0);
}
// Minimal local AnimationTrack leave context, matching the verified additive branch.
// Empty-handed/gesture mutations are bypassed; only the matching additive is faded.
struct alignas(16) AdditiveLeaveContext {
 std::array<unsigned char,0x60> data{};
 std::array<unsigned char,0x40> context{};
 std::array<unsigned char,0x50> state{};
 template<class T> static void put(unsigned char* dst,T value){std::memcpy(dst,&value,sizeof(value));}
 AdditiveLeaveContext(uintptr_t component,uintptr_t resource){
  put(data.data()+0x28,uint32_t(1)); // additive blend mode
  put(data.data()+0x24,uint32_t(1)); // loop
  data[0x10]=1;data[0x4f]=1; // interruptible; preserve empty-handed state
  put(context.data()+0x30,component);
  put(state.data()+0x28,resource);
  put(state.data()+0x40,reinterpret_cast<uintptr_t>(data.data()));
  put(state.data()+0x48,reinterpret_cast<uintptr_t>(context.data()));
 }
};
}
