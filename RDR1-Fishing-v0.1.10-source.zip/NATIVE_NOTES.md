# Native-call evidence (RDR.exe supplied by user)

Executable SHA256: 22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e.
Static analysis only; no claim of runtime validation for the new calls.

- `SET_OBJECT_POSITION`, hash C5D796F8: handler VA 0x14022F920 reads the object
  handle at argument slot 0, packed XY at slot 1, and Z at slot 2. The SDK signature
  and our existing packing agree; motion failure must be diagnosed through the
  boolean return and `GET_OBJECT_POSITION`, rather than assuming a packing defect.
- `SET_OBJECT_ORIENTATION`, hash C8A4EE74: handler VA 0x1402308D0 reads the same
  packed vector pattern and applies a degrees-to-radians conversion before dispatch.
- `FIND_WATER_INTERSECTION`, hash 4F193BE4: registration points to VA 0x1402965D0.
  It reads two packed vectors from argument slots 0/1 and 2/3, then vector output
  pointers from slots 4 and 5. It invokes the intersection routine at 0x140295DC0
  with the water collision mask 0x400000 and writes a boolean result. The adapter
  supplies two initialized, aligned vector outputs and two trailing zero arguments
  for the SDK's placeholder arity. Output position is validated before use.
- `WORLD_TO_SCREEN`, hash BAA72911: supplied by RedHook v0.8, not base game.
  Handler VA 0x180024780 in supplied RedHook.dll reads a position pointer and two
  float output pointers. It returns false for points outside the view; successful
  outputs are normalized screen coordinates. Used only for visual markers.
- `GET_OBJECT_NAMED_BONE_POSITION`, hash 30516389, and `GET_OBJECT_FROM_ACTOR`,
  hash 4A2063EC: typed signatures from the supplied SDK. Bone names are probed
  and validated by proximity; a body-relative fallback is used when unavailable.

No unknown animator or lasso task parameters were guessed in this release.
Player animation and WAS/WAT playback remain unfinished.
