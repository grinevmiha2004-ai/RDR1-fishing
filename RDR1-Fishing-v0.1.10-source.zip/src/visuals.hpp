#pragma once
#include <algorithm>
#include <cmath>
namespace fishing {
struct Point {float x=0,y=0,z=0;};
inline Point mix(Point a,Point b,float t){return {a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t};}
inline Point castPath(Point hand,Point surface,float phase){
 float t=std::clamp(phase,0.f,1.f);Point p=mix(hand,surface,t);
 p.y+=std::sin(t*3.14159265359f)*1.8f;return p;
}
inline bool finite(Point p){return std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z);}
inline bool waterHitValid(Point ray,Point hit,float top,float bottom){return finite(hit)&&std::abs(hit.x-ray.x)<.3f&&std::abs(hit.z-ray.z)<.3f&&hit.y<=top&&hit.y>=bottom;}
}
