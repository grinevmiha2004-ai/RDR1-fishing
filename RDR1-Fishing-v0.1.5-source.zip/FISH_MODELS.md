# Fish resources for v0.1.5

User-supplied files were decompressed as RSC5/Zstandard resources:

| File | Uploaded bytes | Decompressed bytes | SHA256 of uploaded file |
| --- | ---: | ---: | --- |
| p_gen_fish01x.wft | 36100 | 57344 | dcd1097c6d4174a37c6cd600ec3823e0302a6e51d6859cd40ce96b80a5a483b6 |
| p_gen_fish02x.wft | 34964 | 61440 | df2549eb64f229cd235dfe1632e9383e1fb2371c4d0d00fab3a107586697e679 |

Both contain internal paths `t:/rdr2/assets/level/territory/p_gen_fish0Nx`.
Both reference fish01 texture names (`p_gen_fish01.dds`, `_n.dds`, `_so.dds`).
Named joints found: joint1–joint4 for model01; joint1–joint6 for model02.
No explicit mouth bone name was found. Species and exact mouth alignment have
not been established from these strings; no mesh rendering validation is claimed.

The plugin requests `$/fragments/p_gen_fish01x` by default. Model02 can be selected
in INI. This follows the same resource lookup used successfully for the supplied
rod, float and hook models, but fish-specific loading/spawning still needs an
in-game check. Loose WFT files are not loaded directly by the plugin.

Lifecycle: request asset on enable; create one prop in Bite once loaded; follow
hook through Fight and Caught; remove in Lost/Ready/Off and on cleanup. Timeout
or create failure is logged without breaking the existing fishing minigame.
Model origin follows the hook; the mouth offset defaults to zero pending visual
alignment. Signed IDs remain valid, as with the confirmed float and hook assets.
