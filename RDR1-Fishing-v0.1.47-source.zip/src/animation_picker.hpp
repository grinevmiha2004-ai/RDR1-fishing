#pragma once
#include "fishing.hpp"
#include "cast_playback.hpp"
#include <algorithm>
#include <cmath>
namespace fishing {
struct AnimationCandidate {const char* clip;const char* set;};
inline constexpr AnimationCandidate animationCandidates[]={
 {"nor_lso_stn_mid_trw_pre","lso"},
 {"nor_lso_stn_aup_mid_trw_pre","lso"},
 {"nor_lso_run_mid_trw_pre","lso"},
 {"nor_lso_run_aup_mid_trw_pre","lso"},
 {"nor_lso_wlk_mid_trw","lso"},
 {"nor_lso_stn_mid_trw_mid","lso"},
 {"nor_lso_stn_aup","lso_base"},
 {"nor_lso_stn","lso_base"},
 {"nor_lso_stn_mid_trw_suc","lso"},
 {"nor_lso_stn_aup_swing","lso_base"}
};
template<class Native> void requestPickerClip(Native native,int actor,const AnimationCandidate& candidate){
 native(actor,candidate.clip,.65f,castBlendOut,1.f,0,true,false,castTaskTimer);
}
struct AnimationPicker {
 int selected=0;bool frozen=false;float frame=0;
 Button buttons[13];
 bool select(int index){
  if(index<0||index>=10)return false;
  selected=index;releaseFrame();return true;
 }
 void releaseFrame(){frozen=false;frame=0;}
 bool toggleFrame(float observed){
  if(frozen){frozen=false;return true;}
  if(!std::isfinite(observed)||observed<0)return false;
  frame=std::clamp(observed,0.f,.99f);frozen=true;return true;
 }
 bool step(float observed,int direction){
  if(!frozen&&!toggleFrame(observed))return false;
  frame=std::clamp(frame+.05f*direction,0.f,.99f);return true;
 }
 const AnimationCandidate& candidate()const{return animationCandidates[selected];}
};
}
