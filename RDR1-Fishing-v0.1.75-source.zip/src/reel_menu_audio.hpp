#pragma once
#include <algorithm>
#include <cmath>
namespace fishing {
// Native one-shot menu path, independent of persistent IDs/HAS_SOUND_FINISHED.
struct ReelMenuAudio {
 bool active=false;float elapsed=0;uint64_t playCount=0;
 void reset(){active=false;elapsed=0;}
 void prime(){active=true;elapsed=0;}
 template<class Audio> void update(bool wanted,float dt,const char* event,Audio& audio){
  if(!wanted||!std::isfinite(dt)||dt<=0){reset();return;}
  if(active){elapsed+=std::min(dt,.1f);if(elapsed<.16f)return;}
  audio.oneShot(event);++playCount;prime();
 }
};
}
