#pragma once
#include <algorithm>
#include <cstdlib>
namespace fishing {
// Rasterize a connected one-pixel line, combining horizontal/vertical pixel runs
// into rectangles accepted by RedHook. Coordinates are screen pixels.
template<class Draw> void solidLine(int x0,int y0,int x1,int y1,bool skipFirst,Draw draw){
 int dx=std::abs(x1-x0),sx=x0<x1?1:-1;
 int dy=-std::abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy;
 int ax=0,ay=0,bx=0,by=0,axis=0;bool active=false;
 auto flush=[&](){if(active)draw(std::min(ax,bx),std::min(ay,by),std::abs(bx-ax)+1,std::abs(by-ay)+1);};
 while(true){
  if(skipFirst)skipFirst=false;
  else if(!active){ax=bx=x0;ay=by=y0;axis=0;active=true;}
  else if(y0==by&&axis!=2){bx=x0;axis=1;}
  else if(x0==bx&&axis!=1){by=y0;axis=2;}
  else{flush();ax=bx=x0;ay=by=y0;axis=0;}
  if(x0==x1&&y0==y1)break;
  int twice=err*2;
  if(twice>=dy){err+=dy;x0+=sx;}
  if(twice<=dx){err+=dx;y0+=sy;}
 }
 flush();
}
}
