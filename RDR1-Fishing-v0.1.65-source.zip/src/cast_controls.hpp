#pragma once
namespace fishing {
struct CastControls {
 bool owned=false;
 template<class Read,class Write> bool acquire(Read read,Write write){
  bool before=read();
  if(!owned&&before){write(false);owned=true;}
  return before;
 }
 template<class Write> bool restore(Write write){
  if(!owned)return false;
  write(true);owned=false;return true;
 }
};
}
