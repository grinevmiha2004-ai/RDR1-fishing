#pragma once
#include "visuals.hpp"
namespace fishing {
struct alignas(16) FishMatrix {float m[4][4]{};};
inline bool scaledFishMatrix(const FishMatrix& in,float factor,Point mouth,FishMatrix& out){
 if(!std::isfinite(factor)||factor<.5f||factor>2.f||!finite(mouth))return false;
 for(const auto& row:in.m)for(float f:row)if(!std::isfinite(f))return false;
 out=in;
 for(int i=0;i<3;++i){
  float n=std::sqrt(in.m[i][0]*in.m[i][0]+in.m[i][1]*in.m[i][1]+in.m[i][2]*in.m[i][2]);
  if(n<.01f||n>4.f)return false;
  for(int j=0;j<3;++j)out.m[i][j]=in.m[i][j]*factor/n;
  out.m[i][3]=0;
 }
 // Existing INI mouth offset is a world-space displacement, not a bone offset.
 out.m[3][0]-=mouth.x*(factor-1);out.m[3][1]-=mouth.y*(factor-1);out.m[3][2]-=mouth.z*(factor-1);
 out.m[3][3]=1;return true;
}
}
