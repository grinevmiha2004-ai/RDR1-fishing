#pragma once
#include <string>
namespace fishing {
// Full bone names only: do not accidentally attach to a finger or left hand.
inline bool rightHandBoneName(const std::string& name){
 std::string key;
 for(unsigned char c:name){
  if(c>='A'&&c<='Z')c=static_cast<unsigned char>(c-'A'+'a');
  if((c>='a'&&c<='z')||(c>='0'&&c<='9'))key+=char(c);
 }
 return key=="wristr"||key=="rwrist"||key=="handright"||key=="righthand"||key=="rhand"||key=="handr"||
        key=="skelrhand"||key=="bip01rhand"||key=="bip01righthand"||
        key=="bonerhand"||key=="jointrhand";
}
}
