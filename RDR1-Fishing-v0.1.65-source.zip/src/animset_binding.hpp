#pragma once
#include <cstdint>
namespace fishing {
enum class AnimBinding {Rejected,Override,Base};
// An accepted native call without an override can mean "already the base set".
// Never treat that as ownership of an override or reset the base at cleanup.
inline AnimBinding classifyAnimBinding(bool accepted,bool attached,bool allowBase,
 uintptr_t overrideResource,bool locked,uintptr_t baseBefore,uintptr_t baseAfter){
 if(!accepted)return AnimBinding::Rejected;
 if(attached&&overrideResource&&locked)return AnimBinding::Override;
 if(allowBase&&!attached&&!overrideResource&&!locked&&baseBefore&&baseBefore==baseAfter)return AnimBinding::Base;
 return AnimBinding::Rejected;
}
inline bool matchesBaseSession(uintptr_t baseExpected,uintptr_t baseCurrent,uintptr_t overrideResource,bool locked){
 return baseExpected&&baseExpected==baseCurrent&&!overrideResource&&!locked;
}
}
