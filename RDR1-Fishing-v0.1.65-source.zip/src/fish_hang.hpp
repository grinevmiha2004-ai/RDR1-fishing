#pragma once
#include "visuals.hpp"
namespace fishing {
struct FishHang {float yaw=0,roll=0;Point mouth{};};
inline FishHang fishHang(float yaw,Point mouth,float elapsed){
 constexpr float rad=.01745329252f;
 float t=std::clamp(elapsed/.35f,0.f,1.f);t=t*t*(3-2*t);
 float hangingYaw=std::remainder(yaw,360.f)*(1-t),roll=-90.f*t;
 // Convert the existing horizontal world mouth offset into model space,
 // then into the hanging orientation (Rz * Ry, as in 0x14016FE80).
 float c=std::cos(yaw*rad),s=std::sin(yaw*rad);
 Point local={c*mouth.x-s*mouth.z,mouth.y,s*mouth.x+c*mouth.z};
 c=std::cos(hangingYaw*rad);s=std::sin(hangingYaw*rad);
 Point y={c*local.x+s*local.z,local.y,-s*local.x+c*local.z};
 c=std::cos(roll*rad);s=std::sin(roll*rad);
 return {hangingYaw,roll,{c*y.x-s*y.y,s*y.x+c*y.y,y.z}};
}
}
