#pragma once
namespace fishing {
inline bool reelSoundWanted(bool fight,bool reel,bool ease,bool focused,bool paused){
 return fight&&reel&&!ease&&focused&&!paused;
}
}
