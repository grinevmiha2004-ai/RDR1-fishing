#pragma once
#include <algorithm>
#include "cast_playback.hpp"
namespace fishing {
// Historical references for the read-only WAT checker; no preparation clip is requested.
inline constexpr const char* castWindupClip="nor_lso_stn_mid_trw_pre";
inline constexpr const char* castWindupNode="default_character_Main\\Gunplay\\THROWING\\Lasso\\LassoNor\\ThrowStand";
inline constexpr const char* castReleaseClip="nor_lso_stn_mid_trw_mid";
inline constexpr const char* castReleaseNode="default_character_Main\\Gunplay\\THROWING\\Lasso\\LassoNor\\ThrowStand\\ThrowMid";
inline float castGameStep(bool casting,bool flightReleased,float dt){return casting&&!flightReleased?0.f:dt;}
inline float castFlightSeconds(float distance,bool animate){
 return animate?std::clamp(distance/5.f,1.1f,4.f):1.1f;
}
enum class CastAnimCommand {None,Request,Retry,Launch,EndHold,Stop};
enum class CastEnd {None,Landed,Missing,Interrupted,Watchdog,Cancelled};
inline const char* castEndName(CastEnd reason){
 switch(reason){
 case CastEnd::Landed:return "landed";
 case CastEnd::Missing:return "not_started";
 case CastEnd::Interrupted:return "interrupted";
 case CastEnd::Watchdog:return "watchdog";
 case CastEnd::Cancelled:return "cancelled";
 default:return "none";
 }
}
struct CastAnimation {
 enum class Stage {Idle,AwaitStart,Holding,BlendOut,Finished};
 Stage stage=Stage::Idle;
 CastEnd end=CastEnd::None;
 float elapsed=0,maxTime=-1;
 bool retried=false;
 CastAnimCommand update(bool casting,bool allowed,float dt,bool playing,float time){
  if(!allowed){
   bool active=stage!=Stage::Idle&&stage!=Stage::Finished;
   reset();end=CastEnd::Cancelled;return active?CastAnimCommand::Stop:CastAnimCommand::None;
  }
  if(stage==Stage::Finished){if(!casting)reset();return CastAnimCommand::None;}
  if(stage==Stage::Idle){
   if(!casting)return CastAnimCommand::None;
   stage=Stage::AwaitStart;elapsed=0;retried=false;maxTime=-1;end=CastEnd::None;
   return CastAnimCommand::Request;
  }
  elapsed+=std::clamp(dt,0.f,.1f);
  if(stage==Stage::BlendOut){
   if(elapsed<castBlendOut)return CastAnimCommand::None;
   stage=Stage::Finished;return CastAnimCommand::Stop;
  }
  bool valid=playing&&std::isfinite(time)&&time>=0;
  if(valid)maxTime=std::max(maxTime,time);
  if(stage==Stage::AwaitStart){
   if(valid&&time>.001f){stage=Stage::Holding;elapsed=0;return CastAnimCommand::Launch;}
   if(elapsed>=1.f)end=CastEnd::Missing;
   else if(!playing&&!retried&&elapsed>=.25f){retried=true;return CastAnimCommand::Retry;}
  }else{
   if(!casting)end=CastEnd::Landed;
   else if(!playing)end=CastEnd::Interrupted;
   else if(elapsed>=6.f)end=CastEnd::Watchdog;
  }
  if(end==CastEnd::None)return CastAnimCommand::None;
  stage=Stage::BlendOut;elapsed=0;return CastAnimCommand::EndHold;
 }
 void reset(){stage=Stage::Idle;end=CastEnd::None;elapsed=0;maxTime=-1;retried=false;}
};
}
