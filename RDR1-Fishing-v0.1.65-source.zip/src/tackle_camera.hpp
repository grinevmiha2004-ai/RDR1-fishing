#pragma once
#include <array>
namespace fishing {
// Exclusions belong only to our three unique prop handles, never global camera state.
struct TackleCamera {
 int camera=0;
 std::array<int,3> objects{};
 template<class Remove> void clear(Remove remove){
  if(camera)for(int object:objects)if(object)remove(camera,object);
  camera=0;objects={};
 }
 template<class Add,class Remove> void sync(int current,std::array<int,3> props,Add add,Remove remove){
  if(camera!=current){clear(remove);camera=current;}
  for(unsigned i=0;i<objects.size();++i){
   if(!camera)props[i]=0;
   if(objects[i]==props[i])continue;
   if(objects[i])remove(camera,objects[i]);
   objects[i]=props[i];
   if(objects[i])add(camera,objects[i],0); // flags affect actors; prop exclusions need zero
  }
 }
};
}
