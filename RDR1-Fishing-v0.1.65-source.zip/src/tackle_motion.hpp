#pragma once
#include "visuals.hpp"
namespace fishing {
inline Point add(Point a,Point b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
inline Point subtract(Point a,Point b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
inline Point scale(Point p,float s){return {p.x*s,p.y*s,p.z*s};}
inline Point boundedVelocity(Point delta,float dt){
 if(dt<=0||!finite(delta))return {};
 Point v=scale(delta,1.f/dt);float n=std::sqrt(v.x*v.x+v.y*v.y+v.z*v.z);
 return n>12.f?scale(v,12.f/n):v;
}
inline Point launchedPath(Point start,Point velocity,Point end,float phase,float seconds){
 float t=std::clamp(phase,0.f,1.f),t2=t*t,t3=t2*t;
 Point p=add(add(scale(start,2*t3-3*t2+1),scale(velocity,(t3-2*t2+t)*seconds)),scale(end,-2*t3+3*t2));
 p.y+=(t3-t2)*seconds*-1.f+1.2f*std::sin(t*3.14159265359f)*std::sin(t*3.14159265359f);
 return p;
}
inline Point tackleLine(Point tip,Point bobber,Point hook,float t,float sag){
 if(t<=.75f){float u=std::clamp(t/.75f,0.f,1.f);Point p=mix(tip,bobber,u);p.y-=std::sin(u*3.14159265359f)*sag;return p;}
 return mix(bobber,hook,std::clamp((t-.75f)/.25f,0.f,1.f));
}
struct TackleMotion {
 bool valid=false,whirling=false,flight=false;
 Point bobber{},hook{},velocity{},hookVelocity{},launch{},launchHook{},launchVelocity{},launchHookVelocity{},seed{},hookSeed{};
 float angle=0,age=0,lastNative=-1,stale=0;
 void reset(){*this={};}
 void prepare(){flight=false;}
 void commit(Point b,Point h,float dt){
  if(valid){velocity=boundedVelocity(subtract(b,bobber),dt);hookVelocity=boundedVelocity(subtract(h,hook),dt);}
  bobber=b;hook=h;valid=true;
 }
 void stow(Point tip,float dt){
  whirling=false;flight=false;age=0;lastNative=-1;stale=0;
  commit(add(tip,{0,-.35f,0}),add(tip,{0,-.55f,0}),dt);
 }
 void whirl(Point tip,Point forward,float dt,float nativePhase=-1,Point rodAxis={0,1,0}){
  dt=std::isfinite(dt)?std::clamp(dt,0.f,.1f):0.f;
  if(whirling&&dt<=0)return;
  if(!valid)stow(tip,0);
  if(!whirling){whirling=true;age=0;seed=subtract(bobber,tip);hookSeed=subtract(hook,tip);lastNative=-1;stale=0;}
  age+=dt;float delta=dt*9.1f;
  if(std::isfinite(nativePhase)&&nativePhase>=0&&nativePhase<=1){
   if(lastNative>=0){float observed=std::remainder(nativePhase-lastNative,1.f)*6.28318530718f;
    if(std::abs(observed)>.00001f){delta=observed;stale=0;}else{stale+=dt;if(stale<.1f)delta=0;}
   }
   lastNative=nativePhase;
  }else lastNative=-1;
  angle=std::remainder(angle+delta,6.28318530718f);
  Point view;if(!horizontalDirection(forward,view))view={0,0,1};
  auto cross=[](Point a,Point b){return Point{a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};};
  auto unit=[](Point p){float n=std::sqrt(p.x*p.x+p.y*p.y+p.z*p.z);return n>.0001f?scale(p,1.f/n):Point{};};
  Point axis=finite(rodAxis)?unit(rodAxis):Point{};
  if(axis.x==0&&axis.y==0&&axis.z==0)axis={0,1,0};
  Point right=unit(cross(axis,view));
  if(right.x==0&&right.y==0&&right.z==0)right=unit(cross(axis,{0,1,0}));
  if(right.x==0&&right.y==0&&right.z==0)right=unit(cross(axis,{1,0,0}));
  Point front=unit(cross(right,axis));
  Point radial=add(scale(right,std::cos(angle)),scale(front,std::sin(angle)));
  float t=std::clamp(age/.55f,0.f,1.f),blend=t*t*(3-2*t);
  Point orbit=add(scale(radial,1.1f),{0,-.08f,0}),orbitHook=add(scale(radial,1.3f),{0,-.10f,0});
  commit(add(tip,mix(seed,orbit,blend)),add(tip,mix(hookSeed,orbitHook,blend)),dt);
 }
 void beginFlight(){
  if(!valid)return;
  flight=true;whirling=false;launch=bobber;launchHook=hook;launchVelocity=velocity;launchHookVelocity=hookVelocity;
 }
 void fly(Point tip,Point destination,float phase,float seconds,float dt){
  if(!valid)stow(tip,0);
  if(!flight)beginFlight();
  commit(launchedPath(launch,launchVelocity,destination,phase,seconds),
         launchedPath(launchHook,launchHookVelocity,add(destination,{0,-.3f,0}),phase,seconds),dt);
 }
};
}
