#pragma once
#include <algorithm>
namespace fishing {
inline float fishScaleForWeight(float kg){return kg<1.f?.5f:kg<=5.f?1.f:2.f;}
// Integer hundredths avoid displaying 1.00kg for a small fish or5.00 for large.
inline float rollFishWeight(float category,float within){
 int first=40,count=60; // preserve prior400g minimum: .40.. .99kg
 if(category>=.8f){first=501;count=500;}
 else if(category>=.5f){first=100;count=401;}
 int index=std::clamp(int(within*count),0,count-1);
 return (first+index)/100.f;
}
}
