#pragma once
#include "visuals.hpp"
namespace fishing {
// Calibration in actor-right / vertical coordinates, in metres.
// Separate photo estimates; do not change rod angles or the 12cm axial grip.
enum class GripPose {Neutral,Ready,Waiting,Fighting};
inline Point gripCorrection(GripPose pose){
 switch(pose){
 case GripPose::Ready:return {-.01f,-.03f,0};
 case GripPose::Waiting:return {.02f,-.01f,0};
 case GripPose::Fighting:return {-.05f,-.015f,0};
 default:return {};
 }
}
struct RodGripPose {
 bool initialized=false;
 GripPose pose=GripPose::Neutral;
 Point start{},current{};
 float age=0;
 void reset(){*this={};}
 Point update(GripPose wanted,float dt,Point facing){
  if(!initialized){initialized=true;pose=wanted;current=start=gripCorrection(wanted);age=.65f;}
  if(wanted!=pose){pose=wanted;start=current;age=0;}
  if(std::isfinite(dt)&&dt>0)age=std::min(.65f,age+std::min(dt,.1f));
  float t=age/.65f;t=t*t*(3-2*t);
  current=mix(start,gripCorrection(pose),t);
  return {facing.z*current.x,current.y,-facing.x*current.x};
 }
};
// World correction: shaft passes through the palm 12 cm above its butt.
inline Point gripWorld(Point shaft,Point facing){
 float n=std::sqrt(shaft.x*shaft.x+shaft.y*shaft.y+shaft.z*shaft.z);
 if(!finite(shaft)||n<.01f)return {};
 return {-.12f*shaft.x/n-.025f*facing.x-.02f*facing.z,-.12f*shaft.y/n,-.12f*shaft.z/n-.025f*facing.z+.02f*facing.x};
}
inline bool gripLocal(Point world,const Point (&axis)[3],Point& local){
 auto dot=[](Point a,Point b){return a.x*b.x+a.y*b.y+a.z*b.z;};
 for(int i=0;i<3;++i){
  if(!finite(axis[i])||std::abs(dot(axis[i],axis[i])-1.f)>.03f)return false;
  for(int j=0;j<i;++j)if(std::abs(dot(axis[i],axis[j]))>.03f)return false;
 }
 local={dot(world,axis[0]),dot(world,axis[1]),dot(world,axis[2])};
 return finite(world)&&finite(local);
}
}
