#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstring>
#include <type_traits>
namespace rh {
inline void (*init)(uint32_t);
inline void (*push)(uint64_t);
inline uint64_t* (*call)();
inline void (*wait)(uint64_t);
inline void (*reg)(HMODULE,void(*)());
inline void (*unreg)(HMODULE);
inline void (*print)(int,const char*,...);
inline void (*drawText)(const char*,float,float,int,float,int,int,int,int,int);
inline void (*drawRect)(float,float,float,float,int,int,int,int);
template<class T> bool symbol(HMODULE m,T& out,const char* name){out=reinterpret_cast<T>(GetProcAddress(m,name));return out!=nullptr;}
inline bool bind() {
 HMODULE m=GetModuleHandleA("RedHook.dll");if(!m)return false;
 return symbol(m,init,"?NativeInit@@YAXI@Z")&&symbol(m,push,"?NativePush64@@YAX_K@Z")&&symbol(m,call,"?NativeCall@@YAPEA_KXZ")&&symbol(m,wait,"?ScriptWait@@YAX_K@Z")&&symbol(m,reg,"?ScriptRegister@@YAXPEAUHINSTANCE__@@P6AXXZ@Z")&&symbol(m,unreg,"?ScriptUnregister@@YAXPEAUHINSTANCE__@@@Z")&&symbol(m,print,"?Print@@YAXW4LogType@@PEBDZZ")&&symbol(m,drawText,"?RH_DrawText@@YAXPEBDMMHMHHHHW4TextAlignment@@@Z")&&symbol(m,drawRect,"?RH_DrawRect@@YAXMMMMHHHH@Z");
}
template<class T> void arg(T value){static_assert(sizeof(T)<=8);uint64_t bits=0;std::memcpy(&bits,&value,sizeof(value));push(bits);}
template<uint32_t H,class R=void,class... A> R invoke(A... args){init(H);(arg(args),...);auto result=call();if constexpr(!std::is_void_v<R>){R value{};std::memcpy(&value,result,sizeof(R));return value;}}
struct XY {float x,y;};
struct Vec {float x=0,y=0,z=0;};
inline int player(){return invoke<0xE8CFDD53,int>(-1);}
inline bool validActor(int a){return invoke<0xBA6C3E92,bool>(a);}
inline bool validObject(int o){return o&&invoke<0xD7E7187B,bool>(o);}
inline Vec position(int a){Vec p;invoke<0x99BD9D6F>(a,&p);return p;}
inline void help(const char* text){invoke<0xE42A8278>(text,.6f,true,1,0,0,0,0);}
// RedHook key codes are scan codes (SDK Enums.h), not Win32 VK constants.
inline bool pressed(int key){return invoke<0x6AFB8EB9,bool>(key);}
inline bool down(int key){return invoke<0xAC93D58A,bool>(key);}
inline void move(int o,Vec p){if(validObject(o))invoke<0xC5D796F8,bool>(o,XY{p.x,p.y},p.z);}
}
