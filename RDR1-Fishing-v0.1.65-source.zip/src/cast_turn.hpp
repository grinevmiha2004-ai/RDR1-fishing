#pragma once
#include "visuals.hpp"
namespace fishing {
// Native heading describes the actor transform basis, not John's visible front.
// The v0.1.28 game report establishes that the visual front requires a 180-degree offset.
struct CastTurn {
 enum class Result {Ready,Turning,Failed};
 bool pending=false;
 float target=0,elapsed=0;
 bool begin(Point direction){
  Point flat;
  reset();if(!horizontalDirection(direction,flat))return false;
  target=std::remainder(std::atan2(flat.x,flat.z)*57.295779513f+180.f,360.f);pending=true;return true;
 }
 Result update(float current,float dt,float& next){
  next=current;
  if(!pending)return Result::Ready;
  if(!std::isfinite(current)||!std::isfinite(dt)){reset();return Result::Failed;}
  float delta=std::remainder(target-current,360.f);
  // Read back alignment on a following frame before starting the animation.
  if(std::abs(delta)<=.5f){pending=false;return Result::Ready;}
  float step=std::clamp(dt,0.f,.1f);elapsed+=step;
  if(elapsed>1.25f){reset();return Result::Failed;}
  next=std::remainder(current+std::clamp(delta,-360.f*step,360.f*step),360.f);
  return Result::Turning;
 }
 void reset(){pending=false;target=0;elapsed=0;}
};
}
