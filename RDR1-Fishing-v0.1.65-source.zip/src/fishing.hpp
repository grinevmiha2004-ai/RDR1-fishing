#pragma once
#include <algorithm>
#include <cstdint>
#include "fish_weight.hpp"
namespace fishing {
// Asset IDs are signed representations of hashes; negative IDs are valid.
inline bool validAsset(int32_t id) {return id!=0 && id!=-1;}
struct Button {
 bool held=false;
 bool sample(bool down) {bool edge=down&&!held;held=down;return edge;}
};
enum class Phase { Off, Ready, Cast, Wait, Bite, Fight, Caught, Lost };
struct Input { bool action=false, reel=false, ease=false; };
struct Game {
 Phase phase=Phase::Off;
 float biteWindow=6;
 float castSeconds=1.1f;
 float elapsed=0, wait=0, tension=.3f, progress=0, weight=0;
 unsigned catches=0; uint32_t seed=1234567;
 float random() { seed=1664525u*seed+1013904223u; return float(seed>>8)/16777216.f; }
 void enter(Phase next) {phase=next;elapsed=0;}
 void toggle() {enter(phase==Phase::Off?Phase::Ready:Phase::Off);}
 void update(float dt, Input in) {
  dt=std::clamp(dt,0.f,.1f);elapsed+=dt;
  switch(phase) {
  case Phase::Ready: if(in.action){float category=random(),within=random();weight=rollFishWeight(category,within);wait=4+random()*6;enter(Phase::Cast);}break;
  case Phase::Cast: if(elapsed>=castSeconds)enter(Phase::Wait);break;
  case Phase::Wait: if(elapsed>=wait)enter(Phase::Bite);break;
  case Phase::Bite: if(in.action){tension=.35f;progress=0;enter(Phase::Fight);}else if(elapsed>=biteWindow)enter(Phase::Lost);break;
  case Phase::Fight: {
   // Fish pulls in predictable alternating bursts; holding reel throughout breaks the line.
   bool pulling=(int(elapsed/1.6f)%3)!=2;
   float pull=pulling?.13f:-.12f;
   tension=std::max(0.f,tension+dt*(pull+(in.reel?.25f:-.10f)-(in.ease?.38f:0)));
   progress=std::clamp(progress+dt*(in.reel&&!in.ease?.105f:-.025f),0.f,1.f);
   if(tension>=1 || tension<=0)enter(Phase::Lost);
   else if(progress>=1){++catches;enter(Phase::Caught);}
   break;
  }
  case Phase::Caught:case Phase::Lost:if(in.action||elapsed>4)enter(Phase::Ready);break;
  default:break;
  }
 }
};
}
