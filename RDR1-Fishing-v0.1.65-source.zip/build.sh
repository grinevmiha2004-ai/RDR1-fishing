#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build dist
if [[ -z "${CXX:-}" ]] && [[ -x /workspace/toolchains/mingw/usr/bin/x86_64-w64-mingw32-g++-posix ]]; then
 export PATH="/workspace/toolchains/mingw/usr/bin:$PATH"
 export CXX=/workspace/toolchains/mingw/usr/bin/x86_64-w64-mingw32-g++-posix
fi
${HOST_CXX:-g++} -std=c++17 -Wall -Wextra -Werror tests/game_test.cpp -o build/game_test
build/game_test
${CXX:-x86_64-w64-mingw32-g++} -std=c++17 -O2 -Wall -Wextra -Wno-cast-function-type -Werror -shared -static src/plugin.cpp -o dist/Fishing.red -Wl,--no-insert-timestamp
