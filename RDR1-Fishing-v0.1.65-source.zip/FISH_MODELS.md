# Fish resources for v0.1.5

User-supplied files were decompressed as RSC5/Zstandard resources:

| File | Uploaded bytes | Decompressed bytes | SHA256 of uploaded file |
| --- | ---: | ---: | --- |
| p_gen_fish01x.wft | 36100 | 57344 | dcd1097c6d4174a37c6cd600ec3823e0302a6e51d6859cd40ce96b80a5a483b6 |
| p_gen_fish02x.wft | 34964 | 61440 | df2549eb64f229cd235dfe1632e9383e1fb2371c4d0d00fab3a107586697e679 |

Both contain internal paths `t:/rdr2/assets/level/territory/p_gen_fish0Nx`.
Both reference fish01 texture names (`p_gen_fish01.dds`, `_n.dds`, `_so.dds`).
Named joints found: joint1–joint4 for model01; joint1–joint6 for model02.
No explicit mouth bone name was found. Species and exact mouth alignment have
not been established from these strings; no mesh rendering validation is claimed.

In v0.1.5 the plugin requested `$/fragments/p_gen_fish01x` by default (superseded
by the geometry-based correction below). Model02 could be selected
in INI. This follows the same resource lookup used successfully for the supplied
rod, float and hook models, but fish-specific loading/spawning still needs an
in-game check. Loose WFT files are not loaded directly by the plugin.

Lifecycle: request asset on enable; create one prop in Bite once loaded; follow
hook through Fight and Caught; remove in Lost/Ready/Off and on cleanup. Timeout
or create failure is logged without breaking the existing fishing minigame.
Model origin follows the hook; the mouth offset defaults to zero pending visual
alignment. Signed IDs remain valid, as with the confirmed float and hook assets.

## Mesh verification and correction in v0.1.6

A subsequent user report identified model01 as sliced fish. Geometry was then
parsed independently of names, using MagicRDR's documented-in-source fragment
layout (https://github.com/Foxxyyy/Magic-RDR, commit bc2b939b5f53de81450391fe834d2e35f97a982a).

- model01: 239 vertices / 186 triangles, separated fish pieces.
- model02: 177 vertices / 212 triangles, intact head/body/tail silhouette.
- Vertex-buffer stride: 36 bytes; positions: first three little-endian floats.
- Position buffer: 0x5750 in both decompressed resources.
- Index buffer: 0x78EC for model01; 0x7590 for model02; 16-bit little-endian indices.
- Index ranges and position extents match drawable bounds in both files.

Orthographic mesh previews confirm the distinction; matching texture names did
not imply matching geometry. Model02 is now the default; old explicit model01
settings are substituted with model02 at runtime. Model placement/orientation and
mouth alignment still require an in-game check. Existing fish follow logic is unchanged.
