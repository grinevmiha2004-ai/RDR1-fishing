"""Check provided EXE's experimental prop matrix ABI (no game execution).
Usage: python3 tools/verify_fish_scale.py RDR.exe
"""
from pathlib import Path
import hashlib,struct,sys
b=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(b).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
nt=struct.unpack_from('<I',b,0x3c)[0];n=struct.unpack_from('<H',b,nt+6)[0];opt=struct.unpack_from('<H',b,nt+20)[0]
def at(rva,size):
 for i in range(n):
  _,start,length,raw=struct.unpack_from('<4I',b,nt+24+opt+i*40+8)
  if start<=rva and rva+size<=start+length:return b[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
assert at(0x1c738e0+0xc0,8)==struct.pack('<Q',0x14021a6b0)
assert at(0x1c738e0+0xb8,8)==struct.pack('<Q',0x14021a6a0)
assert at(0x21a6a0,8)==bytes.fromhex('4881c190000000e9')
assert 0x21a6ac+struct.unpack('<i',at(0x21a6a8,4))[0]==0x234bb0
# Parse byte arrays embedded in runtime header; all must match actual code.
import re
header=(Path(__file__).resolve().parents[1]/'src/fish_scale_runtime.hpp').read_text()
checks=re.findall(r'matches\(base\+0x([0-9a-f]+),std::array<unsigned char,(\d+)>\{([^}]+)\}',header)
assert len(checks)==4
for offset,length,values in checks:
 expected=bytes(int(x,16) for x in values.split(','))
 assert len(expected)==int(length) and at(int(offset,16),len(expected))==expected
print('PASS: prop matrix getter/setter slots and runtime code fingerprints match supplied EXE')
