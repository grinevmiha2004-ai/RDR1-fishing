"""Verify exact EXE fingerprints and authored additive mode; never executes the game.
Usage: python3 tools/verify_additive_abi.py RDR.exe default_character.wat
"""
from pathlib import Path
import re,hashlib,struct,sys
exe,wat=[Path(s).read_bytes() for s in sys.argv[1:3]]
assert hashlib.sha256(exe).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
assert hashlib.sha256(wat).hexdigest()=='1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1'
nt=struct.unpack_from('<I',exe,0x3c)[0];n=struct.unpack_from('<H',exe,nt+6)[0];opt=struct.unpack_from('<H',exe,nt+20)[0]
def at(rva,size):
 for i in range(n):
  _,start,rawsize,raw=struct.unpack_from('<4I',exe,nt+24+opt+i*40+8)
  if start<=rva and rva+size<=start+rawsize:return exe[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
header=(Path(__file__).resolve().parent.parent/'src/spin_additive.hpp').read_text()
checks=re.findall(r'fingerprint\(base\+(0x[0-9a-f]+),\{([^}]+)\}',header)
assert len(checks)==5
for addr,values in checks:
 expected=bytes(int(s,16) for s in values.split(','));assert at(int(addr,16),len(expected))==expected
assert struct.unpack_from('<I',wat,0x9404c+0x1c)[0]==1
assert struct.unpack_from('<I',wat,0x92b48+0x1c)[0]==0
# Additive dispatch arguments and call: loop in r9b, r8=0, blends in stack, dedicated function.
assert at(0xd4277b,21)==bytes.fromhex('f30f117424304533c0f30f11442428f30f114c2420')
assert at(0xd42790,1)==b'\xe8'
assert 0xd42795+struct.unpack('<i',at(0xd42791,4))[0]==0xcedf50

print('PASS: exact EXE, all runtime function fingerprints, authored additive/normal modes and additive dispatch ABI')
