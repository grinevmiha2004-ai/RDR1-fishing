"""Check provided EXE's public camera exclusion ABI (no game execution).
Usage: python3 tools/verify_tackle_camera.py RDR.exe
"""
from pathlib import Path
import hashlib,struct,sys
b=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(b).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
nt=struct.unpack_from('<I',b,0x3c)[0];n=struct.unpack_from('<H',b,nt+6)[0];opt=struct.unpack_from('<H',b,nt+20)[0]
def at(rva,size):
 for i in range(n):
  _,start,length,raw=struct.unpack_from('<4I',b,nt+24+opt+i*40+8)
  if start<=rva and rva+size<=start+length:return b[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
assert at(0x3abbee,4)==bytes.fromhex('448b4210') # third argument flags
assert at(0x3abbf2,7)==bytes.fromhex('4881c130010000') # camera collision state
assert at(0x3abbf9,3)==bytes.fromhex('8b5208') # second argument object handle
assert at(0x3abc1b,3)==bytes.fromhex('8b4808') # remove second argument
assert at(0x355f0e,13)==bytes.fromhex('488b40208b5018488b018910c3') # game camera -> handle
print('PASS: GET_GAME_CAMERA returns handle; exclusion add/remove use camera, object and integer flags')
