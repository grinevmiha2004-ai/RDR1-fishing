"""Verify sample->event mapping in user-extracted, raw-Deflate-decoded sounds.dat20.
Usage: python3 tools/verify_reel_event.py sounds.dat20 RDR.exe
No game execution or audio-playback success is claimed.
"""
from pathlib import Path
import struct,sys,hashlib
b=Path(sys.argv[1]).read_bytes()
u=lambda off:struct.unpack_from('<I',b,off)[0]
assert u(0)==20
end=8+u(4);size=u(end);count=u(end+4)
start=end+8+count*4
names=[b[start+u(end+8+i*4):].split(b'\0',1)[0] for i in range(count)]
assert names[0]==b'STATIC\\SFX'
index=end+4+size;records=u(index);declared=u(index+4);pos=index+8
found=[]
for _ in range(records):
 n=b[pos];pos+=1;name=b[pos:pos+n].decode('ascii');pos+=n
 off,length=struct.unpack_from('<II',b,pos);pos+=8
 if name=='HUD_MENU_MENU_060308_DPAD_03':found.append((off,b[8+off:8+off+length]))
assert pos-(index+8)==declared+records*8
assert found==[(402465,bytes.fromhex('0c2f9505aa02000000000000010000000000004deb37826cb4b401'))]
exe=Path(sys.argv[2]).read_bytes()
assert hashlib.sha256(exe).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
nt=struct.unpack_from('<I',exe,0x3c)[0];num=struct.unpack_from('<H',exe,nt+6)[0];opt=struct.unpack_from('<H',exe,nt+20)[0]
def at(rva,n):
 for i in range(num):
  _,va,length,raw=struct.unpack_from('<4I',exe,nt+24+opt+i*40+8)
  if va<=rva and rva+n<=va+length:return exe[raw+rva-va:raw+rva-va+n]
 raise AssertionError(hex(rva))
assert at(0xe33a49,4)==bytes.fromhex('4c8b4008') # event string in second slot
assert at(0xe33a55,2)==bytes.fromhex('8b00') # integer sound ID in first slot
print('PASS: exact STATIC\\SFX sample0x01B4B46C mapping and persistent frontend sound ID/string ABI')
# All selected variants map to the exact user-approved AWC entry IDs.
expected={
 'HUD_MENU_MENU_060308_DPAD_01':0x062C7D5B,
 'HUD_MENU_MENU_060308_DPAD_02':0x0FEF10E1,
 'HUD_MENU_MENU_060308_DPAD_04':0x0D414B88,
 'HUD_MENU_MENU_060308_NAV_01':0x0B2CA65B,
 'HUD_MENU_MENU_060308_NAV_03':0x04E7D9D6,
 'HUD_MENU_MENU_060308_NAV_04':0x0F88EF19,
}
pos=index+8;matched=set()
for _ in range(records):
 n=b[pos];pos+=1;name=b[pos:pos+n].decode('ascii');pos+=n
 off,length=struct.unpack_from('<II',b,pos);pos+=8
 if name in expected:
  record=b[8+off:8+off+length]
  assert record[0]==12 and struct.unpack_from('<I',record,len(record)-4)[0]&0x1fffffff==expected[name]
  matched.add(name)
assert matched==set(expected)
print('PASS: all six selected game event/sample mappings match user audio tables')
