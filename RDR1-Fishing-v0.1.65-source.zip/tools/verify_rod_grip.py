"""Check provided EXE's public attachment-offset ABI (no game execution).
Usage: python3 tools/verify_rod_grip.py RDR.exe
"""
from pathlib import Path
import hashlib,struct,sys
b=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(b).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
nt=struct.unpack_from('<I',b,0x3c)[0];n=struct.unpack_from('<H',b,nt+6)[0];opt=struct.unpack_from('<H',b,nt+20)[0]
def at(rva,size):
 for i in range(n):
  _,start,length,raw=struct.unpack_from('<4I',b,nt+24+opt+i*40+8)
  if start<=rva and rva+size<=start+length:return b[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
assert at(0x231664,4)==bytes.fromhex('488b4110') # argument array
assert at(0x23166f,2)==bytes.fromhex('8b10') # attachment handle
assert at(0x231671,5)==bytes.fromhex('f20f104008') # packed X/Y
assert at(0x231676,3)==bytes.fromhex('8b4010') # Z in third slot
assert at(0x230b76,4)==bytes.fromhex('488b4d28') # pose world matrix array
assert at(0x230b7c,4)==bytes.fromhex('48c1e206') # 64-byte matrix stride
assert at(0x2316dd,5)==bytes.fromhex('f30f114070') # local X stored on attachment parent data
print('PASS: packed attachment offset ABI and pose world matrix stride match supplied EXE')
