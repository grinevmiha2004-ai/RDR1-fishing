"""List throw clips in decompressed lso.was and their authored WAT track uses.
Usage: python3 tools/audit_lasso_clips.py /path/to/lso.was /path/to/default_character.wat
Names and WAT assignments do not establish the visible pose of a clip.
"""
from pathlib import Path
import hashlib,re,struct,sys
was,wat=[Path(n).read_bytes() for n in sys.argv[1:3]]
assert hashlib.sha256(was).hexdigest()=='7975b6f7294d192f2ecdea03b78d5293ac25566717b06fd762cbdb57da84075f'
assert hashlib.sha256(wat).hexdigest()=='1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1'
clips=sorted(set(m.decode() for m in re.findall(rb'nor_lso_(?:stn|wlk|run)_[a-z0-9_]*trw[a-z0-9_]*',was)))
def u(o):return struct.unpack_from('<I',wat,o)[0]
def ptr(o):
 p=u(o);assert p>>28==5,hex(o)
 p&=0xfffffff;assert p<len(wat);return p
def array(o,n):return [ptr(o+i*4) for i in range(n)]
def text(o):
 end=wat.index(b'\0',o);return wat[o:end].decode('ascii')
uses={c:[] for c in clips};seen=set();queue=[ptr(8)]
while queue:
 node=queue.pop()
 if node in seen:continue
 seen.add(node);assert len(seen)<50000
 count=u(node+12)&65535
 if count:queue.extend(array(ptr(node+8),count))
 count=u(node+48)&65535
 if not count:continue
 for track in array(ptr(node+44),count):
  if u(track) not in (28,35):continue
  clip=text(ptr(track+16))
  if clip in uses:uses[clip].append((node,track,u(track)))
for clip,refs in uses.items():
 print(clip)
 for node,track,kind in refs:print(f'  node=0x{node:X} track=0x{track:X} taskType={kind}')
assert any(n==0xa9540 for n,_,_ in uses['nor_lso_stn_mid_trw_mid'])
assert any(n==0xa9340 for n,_,_ in uses['nor_lso_stn_mid_trw_pre'])
print('PASS: authored standing ThrowStand/ThrowMid assignments verified; alternative movement/outcome clips listed')
