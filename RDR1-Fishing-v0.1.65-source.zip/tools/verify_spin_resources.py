"""Static spin alias/source and authored standing swing assignment.
Usage: python3 tools/verify_spin_resources.py /path/lso_base.was /path/default_character.wat
Does not establish that a subtractive clip plays correctly through TASK_PLAY_ANIM.
"""
from pathlib import Path
import hashlib,struct,sys
was,wat=[Path(p).read_bytes() for p in sys.argv[1:3]]
assert hashlib.sha256(was).hexdigest()=='8421b46d94cb22cfca7e3bac3fd0737dbd4a68551029881fa73399de53d48185'
assert hashlib.sha256(wat).hexdigest()=='1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1'
clip='nor_lso_stn_aup_swing';h=0
for c in clip.encode():h=(h+c)&0xffffffff;h=(h+(h<<10))&0xffffffff;h^=h>>6
h=(h+(h<<3))&0xffffffff;h^=h>>11;h=(h+(h<<15))&0xffffffff
at=was.index(struct.pack('<I',h));assert at==0x102204
p=struct.unpack_from('<I',was,at+4)[0]&0xfffffff
st=struct.unpack_from('<I',was,p+8)[0]&0xfffffff
assert was[st:was.index(b'\0',st)]==b'Human\\Gent\\gent_nor_lso_stn_aup_swing__SUBTRACT'
u=lambda o:struct.unpack_from('<I',wat,o)[0]
ptr=lambda o:u(o)&0xfffffff
for t in [0x9404c,0x94428]:
 assert u(t)==35
 st=ptr(t+16);assert wat[st:wat.index(b'\0',st)].decode()==clip
print('PASS: real standing swing key/source (SUBTRACT) and both authored standing swing tracks')
