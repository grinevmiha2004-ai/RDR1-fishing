"""Validate cast paths against a decompressed default_character.wat resource."""
from pathlib import Path
import struct,sys,re,ast
b=Path(sys.argv[1]).read_bytes()
def u(o):return struct.unpack_from('<I',b,o)[0]
def pointer(o):
 p=u(o);assert p>>28==5,hex(p)
 return p&0xfffffff
def hash_name(s):
 h=0
 for c in s.lower().encode():
  h=(h+c)&0xffffffff;h=(h+(h<<10))&0xffffffff;h^=h>>6
 h=(h+(h<<3))&0xffffffff;h^=h>>11
 return (h+(h<<15))&0xffffffff
header=(Path(__file__).resolve().parent.parent/'src/cast_animation.hpp').read_text()
paths={}
for key in ['castWindupNode','castReleaseNode']:
 literal=re.search(key+r'=("[^"\n]+")',header).group(1)
 paths[key]=ast.literal_eval(literal).split('\\')
parts=paths['castReleaseNode']
assert paths['castWindupNode']==parts[:-1]
node=pointer(8)
assert u(node+0x20)==hash_name(parts[0])
for part in parts[1:]:
 start=pointer(node+8);count=u(node+12)&0xffff
 children=[pointer(start+i*4) for i in range(count)]
 matches=[x for x in children if u(x+0x20)==hash_name(part)]
 assert len(matches)==1,part
 parent=node;node=matches[0];assert pointer(node+4)==parent
 print(f'PASS: {part}: node 0x{node:X}, hash {hash_name(part):08X}')
for clip in ['nor_lso_stn_mid_trw_pre','nor_lso_stn_mid_trw_mid']:
 assert clip.encode()+b'\0' in b,clip
print('PASS: complete standing-lasso cast hierarchy and both clip references')
