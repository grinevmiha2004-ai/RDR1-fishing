"""Read-only verification of user-supplied, decompressed lso.was and RDR.exe.
No game assets are distributed by this tool; passing is static evidence only.
Usage: python3 tools/verify_cast_resources.py /path/to/lso.was /path/to/RDR.exe
"""
from pathlib import Path
import hashlib,re,struct,sys
was,exe=map(lambda p:Path(p).read_bytes(),sys.argv[1:3])
assert hashlib.sha256(was).hexdigest()=='7975b6f7294d192f2ecdea03b78d5293ac25566717b06fd762cbdb57da84075f'
assert hashlib.sha256(exe).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
assert was[0x38:0x40]==b'lso.ast\0'
header=(Path(__file__).resolve().parent.parent/'src/cast_animation.hpp').read_text()
def joaat(s):
 h=0
 for c in s.lower().encode():
  h=(h+c)&0xffffffff;h=(h+(h<<10))&0xffffffff;h^=h>>6
 h=(h+(h<<3))&0xffffffff;h^=h>>11
 return (h+(h<<15))&0xffffffff
for field in ['castWindupClip','castReleaseClip']:
 clip=re.search(field+r'="([^"]+)"',header).group(1)
 assert clip.encode()+b'\0' in was,clip
 assert struct.pack('<I',joaat(clip)) in was,clip
# Map PE RVAs without an extra pefile dependency.
nt=struct.unpack_from('<I',exe,0x3c)[0]
count=struct.unpack_from('<H',exe,nt+6)[0]
optional=struct.unpack_from('<H',exe,nt+20)[0]
sections=nt+24+optional
def at(rva,n):
 for i in range(count):
  off=sections+i*40
  virtual_size,start,raw_size,raw=struct.unpack_from('<4I',exe,off+8)
  if start<=rva and rva+n<=start+raw_size:
   return exe[raw+rva-start:raw+rva-start+n]
 raise AssertionError(hex(rva))
assert at(0xce01c9,16)==bytes.fromhex('488b4038488b88a80900004885c97428')
# Both table RIP references and the wrapper->actor handle read used by cast_animset.hpp.
assert 0xce0173+7+struct.unpack('<i',at(0xce0176,4))[0]==0x2c36778
assert at(0xce0199,6)==bytes.fromhex('8b88b0000000')
assert 0xce019f+7+struct.unpack('<i',at(0xce01a2,4))[0]==0x2c36768
assert at(0xce08a1,7)==bytes.fromhex('488b8ba8090000')
print('PASS: real lso animation set, both cast names/hashes, exact RDR.exe and read-only ownership lookup ABI')

# Slot 4 -> queued task +0x54 -> callee speed -> playback state +0x48.
assert at(0xc1abf5,5)==bytes.fromhex('f30f107a20')
assert at(0xc1ac58,5)==bytes.fromhex('f30f117854')
assert at(0xb3b493,6)==bytes.fromhex('f3410f104154')
assert at(0xb3b4ae,6)==bytes.fromhex('f30f11442428')
assert at(0xcdeaa9,17)==bytes.fromhex('f30f10b42408010000f30f59b7100a0000')
assert at(0xcdebb3,5)==bytes.fromhex('f30f117548')
# Slot 8's separate actor timer is decremented by frame time, not a speed parameter.
assert at(0xcefb95,12)==bytes.fromhex('f30f1083940a0000410f2fc0')
assert at(0xcefbb1,9)==bytes.fromhex('f3410f5c8050010000')
print('PASS: slot 4 reaches the playback-rate field; slot 8 controls the separate countdown')

# Native boolean slot 6 forces the playback loop flag instead of the clip default.
assert at(0xcdec8a,15)==bytes.fromhex('0fb6842418010000884559c6455801')
assert at(0xcef6b2,20)==bytes.fromhex('807b580074060fb64359eb040fb6413084c00f85')
print('PASS: native slot 6 sets forced-loop override used by completion logic')

# SET_ACTOR_HEADING: float degrees in slot 1, integer/bool flag in slot 2.
assert at(0xad69b4,6)==bytes.fromhex('f3410f104908')
assert at(0xad69ba,4)==bytes.fromhex('41395110')
assert at(0xad69be,8)==bytes.fromhex('f30f590d72b62801')
assert abs(struct.unpack('<f',at(0x1d62038,4))[0]-.01745329252)<1e-7
print('PASS: SET_ACTOR_HEADING uses float degrees and a separate boolean flag')

# SET_ANIM_SET_FOR_ACTOR already-base shortcut: returns true without writing override.
assert at(0xce8d70,9)==bytes.fromhex('483b99180b000074ea')
assert at(0xce8d63,13)==bytes.fromhex('b001488b5c24404883c4305fc3')
assert at(0xce8dc5,7)==bytes.fromhex('48899fa8090000')
print('PASS: base animset +0xB18 shortcut returns success before override +0x9A8 write')
