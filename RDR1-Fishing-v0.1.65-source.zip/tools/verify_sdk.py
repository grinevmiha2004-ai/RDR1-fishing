"""Static compatibility check against user-supplied SDK and loader; does not run the game."""
from pathlib import Path
import re, subprocess, sys
sdk, loader = map(Path, sys.argv[1:3])
root = Path(__file__).resolve().parent.parent
native_text = (sdk / 'Headers/Natives.h').read_text(errors='replace')
known = {int(x, 16) for x in re.findall(r'Invoke<(0x[0-9A-Fa-f]+)', native_text)}
source = '\n'.join(p.read_text() for p in (root / 'src').glob('*') if p.suffix in ('.hpp', '.cpp'))
used = {int(x, 16) for x in re.findall(r'invoke<(0x[0-9A-Fa-f]+)', source)}
assert used <= known, f'Unknown native hashes: {used - known}'
exports = subprocess.check_output(['objdump', '-p', str(loader)], text=True)
imports = re.findall(r'symbol\(m,\w+,"([^"]+)"\)', source)
for name in imports:
    assert name in exports, f'Missing RedHook export: {name}'
pe = subprocess.check_output(['objdump', '-p', str(root / 'dist/Fishing.red')], text=True)
deps = set(re.findall(r'DLL Name: (\S+)', pe))
assert deps <= {'KERNEL32.dll', 'USER32.dll', 'msvcrt.dll'}, deps
assert 'pei-x86-64' in pe
print(f'PASS: {len(used)} native hashes in SDK, {len(imports)} exact RedHook exports, x64 PE, system DLLs only')
