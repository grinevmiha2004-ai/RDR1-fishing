"""Static tug-war standing/backward clip audit. Usage: gent.was default_character.wat"""
from pathlib import Path
import hashlib,struct,sys
was,wat=[Path(p).read_bytes() for p in sys.argv[1:3]]
assert hashlib.sha256(was).hexdigest()=='93df0fc0d395980051606b5e496abd0ddae1ae97c300e2910d3d156123b772b7'
assert hashlib.sha256(wat).hexdigest()=='1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1'
header=(Path(__file__).resolve().parent.parent/'src/fight_pose.hpp').read_text()
assert 'fightAnimSet="gent"' in header and 'fightHoldClip="nor_lso_bck_tug_wlk"' in header
for key,at,source in [(0x8f863232,0x6dc09c,b'Human\\Gent\\gent_nor_lso_tug_stn'),(0x790d38e9,0x6e1c48,b'Human\\Gent\\gent_nor_lso_bck_tug_wlk')]:
 assert struct.unpack_from('<I',was,at)[0]==key
 resource=struct.unpack_from('<I',was,at+4)[0]&0xfffffff
 name=struct.unpack_from('<I',was,resource+8)[0]&0xfffffff
 assert was[name:was.index(b'\0',name)]==source
u=lambda o:struct.unpack_from('<I',wat,o)[0]
p=lambda o:u(o)&0xfffffff
for node,track,name,state in [(0xae180,0x76b48,'nor_lso_tug_stn',6),(0xae780,0x77000,'nor_lso_bck_tug_wlk',7)]:
 assert p(node+4)==0xae100
 assert u(track)==35
 st=p(track+16);assert wat[st:wat.index(b'\0',st)].decode()==name
 transitions=[]
 for i in range(u(node+48)&65535):
  t=p(p(node+44)+4*i)
  if u(t)==1:
   transitions.extend(p(p(t+32)+4*j) for j in range(u(t+36)&65535))
 assert any(u(c)==137 and u(c+4)==state for c in transitions)
print('PASS: gent source mappings; standing and backward tug siblings; distinct LassoState 6/7 conditions')
print('Static branch evidence does not prove the desired visible hand pose or exact grounded-target runtime state.')
