#pragma once
namespace fishing {
// User-selected effects from the numbered v0.1.77 preview, fixed scale 1.
inline const char* splashForWeight(float kg){
 return kg<1.f?"bullet_water":kg<=5.f?"ped_water_thrash":"amb_water_rocksplash_2";
}
struct StruggleSplash {
 bool wasPulling=false;
 bool update(bool fighting,bool pulling,float dt){
  if(dt<=0)return false;
  bool current=fighting&&pulling;
  bool launch=current&&!wasPulling;
  wasPulling=current;
  return launch;
 }
 void reset(){wasPulling=false;}
};
}
