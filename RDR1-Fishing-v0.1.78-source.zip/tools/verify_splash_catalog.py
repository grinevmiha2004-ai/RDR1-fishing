"""Check test effect names against the extracted RDR1 rdr2_core.fxlist."""
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parent.parent
source = (root / 'src/splash.hpp').read_text()
block = source.split('inline const char* splashForWeight', 1)[1].split('struct StruggleSplash', 1)[0]
names = re.findall(r'"([a-z0-9_]+)"', block)
catalog = set(Path(sys.argv[1]).read_text().split())
assert len(names) == 3 and len(set(names)) == 3
assert set(names) <= catalog, set(names) - catalog
assert not any(name.startswith('exp_') for name in names)
print('PASS: all 3 selected effects exist in the supplied RDR1 FX catalog')
