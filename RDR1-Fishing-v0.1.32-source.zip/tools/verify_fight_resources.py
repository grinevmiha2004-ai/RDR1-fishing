"""Verify the stationary lasso-hold candidate in real gent.was and action tree.
Usage: python3 tools/verify_fight_resources.py /path/gent.was /path/default_character.wat
Passing proves authored assignment, not the visible pose with a fishing rod.
"""
from pathlib import Path
import hashlib,re,struct,sys
was,wat=[Path(p).read_bytes() for p in sys.argv[1:3]]
assert hashlib.sha256(was).hexdigest()=='93df0fc0d395980051606b5e496abd0ddae1ae97c300e2910d3d156123b772b7'
assert hashlib.sha256(wat).hexdigest()=='1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1'
root=Path(__file__).resolve().parent.parent
header=(root/'src/fight_pose.hpp').read_text()
clip=re.search(r'fightHoldClip="([^"]+)"',header).group(1)
assert clip=='nor_lso_pul_stn'
assert 'fightAnimSet="gent"' in header
assert was[0x38:0x41]==b'gent.ast\0'
assert clip.encode()+b'\0' in was
h=0
for c in clip.encode():
 h=(h+c)&0xffffffff;h=(h+(h<<10))&0xffffffff;h^=h>>6
h=(h+(h<<3))&0xffffffff;h^=h>>11;h=(h+(h<<15))&0xffffffff
assert struct.pack('<I',h) in was
u=lambda o:struct.unpack_from('<I',wat,o)[0]
p=lambda o:u(o)&0xfffffff
def text(o):
 st=p(o);return wat[st:wat.index(b'\0',st)].decode()
node=0xad440
assert p(node+4)==0xad380
tracks=[p(p(node+44)+4*i) for i in range(u(node+48)&65535)]
locomotion=[t for t in tracks if u(t)==77]
assert len(locomotion)==8
for t in locomotion:
 assert text(t+0xa4)==clip
 assert text(t+0xa8).startswith('nor_lso_pul_wlk_')
 assert text(t+0xac).startswith('nor_lso_pul_run_')
# The rejected v0.1.30 success/pull-back clip belongs to the parent track,
# not the stationary slot of the hold state's eight directional blends.
assert text(0x9904c+16)=='nor_lso_stn_mid_trw_suc'
print('PASS: gent set/clip key/hash; stationary slot in all 8 hold locomotion tracks; distinct walk/run/pull-back clips')
print('Visible two-hand stance with a fishing rod still requires a game test.')
