#pragma once
#include <algorithm>
#include <cmath>
namespace fishing {
inline float castPower(float seconds){return std::isfinite(seconds)?std::clamp(seconds/3.f,0.f,1.f):0.f;}
inline float chargedCastDistance(float seconds,float maximum){
 maximum=std::isfinite(maximum)?std::clamp(maximum,3.f,20.f):9.f;
 return 3.f+(maximum-3.f)*castPower(seconds);
}
}
