#pragma once
#include "cast_power.hpp"
namespace fishing {
inline constexpr const char* castSpinClip="nor_lso_stn_aup_swing";
inline constexpr const char* castSpinSet="lso_base";
struct CastCharge {
 bool active=false,released=false;
 float heldSeconds=0;
 void begin(){active=true;released=false;heldSeconds=0;}
 bool observe(bool down){bool edge=active&&!released&&!down;if(edge)released=true;return edge;}
 void advance(float dt){if(active&&!released&&std::isfinite(dt)&&dt>0)heldSeconds=std::min(3.f,heldSeconds+dt);}
 void reset(){active=false;released=false;heldSeconds=0;}
};
}
