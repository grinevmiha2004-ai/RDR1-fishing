#pragma once
#include "visuals.hpp"
namespace fishing {
inline constexpr const char* releaseAnimSet="dyn";
inline constexpr const char* releaseClip="nor_dyn_stn_for_mid_und_trw";
struct FishRelease {
 enum class Stage {Idle,Loading,Hand,Flight,Landed};
 Stage stage=Stage::Idle;
 Point start{},target{},caught{};
 float age=0,flight=0,duration=1,phase=.48f;
 bool seen=false;
 bool active()const{return stage!=Stage::Idle;}
 void reset(){*this={};}
 void begin(Point from,Point to){reset();stage=Stage::Loading;caught=from;target=to;}
 bool launch(float observed,Point hand){
  if(stage!=Stage::Hand||!std::isfinite(observed)||observed<phase)return false;
  start=hand;flight=0;duration=std::clamp(std::hypot(target.x-start.x,target.z-start.z)/7.f,.65f,1.5f);
  stage=Stage::Flight;return true;
 }
 bool fly(float dt){
  if(stage!=Stage::Flight||dt<=0)return false;
  flight=std::min(duration,flight+dt);
  if(flight>=duration){stage=Stage::Landed;return true;}
  return false;
 }
 Point position()const{
  float t=std::clamp(flight/duration,0.f,1.f);auto p=mix(start,target,t);
  p.y+=4.f*1.2f*t*(1.f-t);return p;
 }
};
}
