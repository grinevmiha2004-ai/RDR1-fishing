#pragma once
#include <algorithm>
#include <cstdint>
#include <cmath>
#include "fish_weight.hpp"
#include "fish_struggle.hpp"
namespace fishing {
// Asset IDs are signed representations of hashes; negative IDs are valid.
inline bool validAsset(int32_t id) {return id!=0 && id!=-1;}
struct Button {
 bool held=false;
 bool sample(bool down) {bool edge=down&&!held;held=down;return edge;}
};
enum class Phase { Off, Ready, Cast, Wait, Bite, Fight, Caught, Lost };
struct Input { bool action=false, reel=false, ease=false; };
struct Game {
 Phase phase=Phase::Off;
 FishStruggle struggle;
 bool pulling()const{return struggle.pulling;}
 float biteWindow=6;
 float castSeconds=1.1f;
 float elapsed=0, wait=0, tension=.3f, progress=0, weight=0;
 float castRange=9,emptyReeled=0;
 unsigned catches=0; uint32_t seed=1234567;
 float random() { seed=1664525u*seed+1013904223u; return float(seed>>8)/16777216.f; }
 void enter(Phase next) {phase=next;elapsed=0;if(next==Phase::Fight)struggle.reset();}
 void toggle() {enter(phase==Phase::Off?Phase::Ready:Phase::Off);}
 void update(float dt, Input in) {
  dt=std::clamp(dt,0.f,.1f);elapsed+=dt;
  switch(phase) {
  case Phase::Ready: if(in.action){emptyReeled=0;float category=random(),within=random();weight=rollFishWeight(category,within);wait=7+random()*8;enter(Phase::Cast);}break;
  case Phase::Cast: if(elapsed>=castSeconds)enter(Phase::Wait);break;
  case Phase::Wait:
   if(in.reel&&!in.ease)emptyReeled=std::min(std::max(0.f,castRange-2.f),emptyReeled+dt*.10f);
   if(emptyReeled>=std::max(0.f,castRange-2.f)){enter(Phase::Ready);}
   else if(elapsed>=wait)enter(Phase::Bite);
   break;
  case Phase::Bite: if(in.action){tension=.35f;progress=0;enter(Phase::Fight);}else if(elapsed>=biteWindow)enter(Phase::Lost);break;
  case Phase::Fight: {
   struggle.update(dt,[&](){return random();});
   bool pulling=struggle.pulling;
   if(in.ease){
    tension=std::max(0.f,tension-dt*.30f);
    progress=std::max(0.f,progress-dt*.04f);
   }else if(in.reel){
    if(pulling)tension=std::min(1.f,tension+dt*tensionRateForWeight(weight));
    progress=std::clamp(progress+dt*.105f*reelSpeedForWeight(weight),0.f,1.f);
   }
   // Letting go holds both values. Only the ease input pays line out / reduces tension.
   if(tension>=1)enter(Phase::Lost);
   else if(progress>=1){++catches;enter(Phase::Caught);}
   break;
  }
  case Phase::Caught:if(in.action)enter(Phase::Ready);break;
  case Phase::Lost:if(in.action||elapsed>4)enter(Phase::Ready);break;
  default:break;
  }
 }
};
}
