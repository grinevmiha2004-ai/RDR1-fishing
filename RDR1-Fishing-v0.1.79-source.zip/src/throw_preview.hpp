#pragma once
namespace fishing {
struct ThrowPreviewClip {const char* clip;const char* description;};
// Verified runtime keys from dyn.was and default_character.wat.
// Both underhand tracks share the molotov/dynamite throwing animation set.
inline constexpr ThrowPreviewClip throwPreviewClips[]={
 {"nor_dyn_stn_for_mid_und_trw","Standing underhand"},
 {"nor_dyn_run_for_mid_und_trw_180","Underhand move: source000"},
 {"nor_dyn_run_for_mid_und_trw_135","Underhand move: source045"},
 {"nor_dyn_run_for_mid_und_trw_225","Underhand move: source315"},
 {"nor_dyn_run_for_mid_und_trw_090","Underhand move: source090"},
 {"nor_dyn_run_for_mid_und_trw_270","Underhand move: source270"},
 {"nor_dyn_run_for_mid_und_trw_045","Underhand move: source135"},
 {"nor_dyn_run_for_mid_und_trw_315","Underhand move: source225"},
 {"nor_dyn_run_for_mid_und_trw_000","Underhand move: source180"},
 {"nor_dyn_stn_for_mid_trw","Standing normal (compare)"}
};
inline constexpr const char* throwPreviewSet="dyn";
// Force one natural pass: positive rate, no loop, no native duration/seek.
template<class Native> void requestThrowPreview(Native native,int actor,const char* clip){
 native(actor,clip,.15f,.25f,1.f,0,false,false,-1.f);
}
}
