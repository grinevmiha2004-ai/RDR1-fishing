"""Verify preview runtime hash -> authored source mapping in supplied RDR1 dyn.was."""
from pathlib import Path
import re,struct,sys,hashlib
b=Path(sys.argv[1]).read_bytes()
r=Path(__file__).resolve().parent.parent
s=(r/'src/throw_preview.hpp').read_text()
clips=re.findall(r'\{"([a-z0-9_]+)",',s)
assert b[0x38:0x40]==b'dyn.ast\0'
assert b'MOLOTOV_THROW_DYNAMIC\0' in b

def h(s):
 v=0
 for c in s.encode():
  v=(v+c)&0xffffffff;v=(v+(v<<10))&0xffffffff;v^=v>>6
 v=(v+(v<<3))&0xffffffff;v^=v>>11
 return (v+(v<<15))&0xffffffff
sources=['Gent_nor_dyn_stn_for_mid_und_trw']+[
 'Gent_nor_dyn_'+d+'_run_mid_und_trw' for d in ['000','045','315','090','270','135','225','180']]+['Gent_nor_dyn_stn_for_mid_trw']
assert len(clips)==len(sources)==10
for c,source in zip(clips,sources):
 found=False;start=0
 while True:
  at=b.find(struct.pack('<I',h(c)),start)
  if at<0:break
  start=at+4
  p=struct.unpack_from('<I',b,at+4)[0]&0xfffffff
  if p+12>=len(b):continue
  n=struct.unpack_from('<I',b,p+8)[0]&0xfffffff
  if n>=len(b):continue
  name=b[n:b.find(b'\0',n)]
  if name==('Human\\Gent\\'+source).encode():found=True;break
 assert found,(c,source)
 print(c,'->',source)
print('PASS: 10 real runtime keys, correct underhand source directions; dyn.was SHA256',hashlib.sha256(b).hexdigest())
