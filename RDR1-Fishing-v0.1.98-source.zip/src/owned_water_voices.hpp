#pragma once
#include <array>
#include <cstdint>
#include <cstddef>
namespace fishing {
// The engine retains each output address and clears it on completion.
// Never move this object, nor recycle a slot before stopping its live voice.
struct OwnedWaterVoices {
 std::array<uintptr_t,4> voice{};std::array<bool,4> reserved{};
 OwnedWaterVoices()=default;
 OwnedWaterVoices(const OwnedWaterVoices&)=delete;
 OwnedWaterVoices& operator=(const OwnedWaterVoices&)=delete;
 bool owns(int id)const{return id>=0&&id<int(voice.size())&&reserved[std::size_t(id)];}
 int allocate(){for(std::size_t i=0;i<voice.size();++i)if(!reserved[i]){reserved[i]=true;voice[i]=0;return int(i);}return -1;}
 uintptr_t* pointer(int id){return owns(id)?&voice[std::size_t(id)]:nullptr;}
 void recycle(int id){if(owns(id)){voice[std::size_t(id)]=0;reserved[std::size_t(id)]=false;}}
};
}
