"""Read-only validation of context-independent owned voice ABI in supplied EXE.
Usage: python3 tools/verify_owned_water_audio.py RDR.exe
No in-game execution or claim that a voice was audible.
"""
from pathlib import Path
import hashlib,struct,re,sys
b=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(b).hexdigest()=='22dec23132de9308b516f36cb68121687665ac79e3b7d7f790da8a993cdd804e'
nt=struct.unpack_from('<I',b,0x3c)[0];n=struct.unpack_from('<H',b,nt+6)[0];opt=struct.unpack_from('<H',b,nt+20)[0]
def at(rva,size):
 for i in range(n):
  _,start,length,raw=struct.unpack_from('<4I',b,nt+24+opt+i*40+8)
  if start<=rva and rva+size<=start+length:return b[raw+rva-start:raw+rva-start+size]
 raise AssertionError(hex(rva))
header=(Path(__file__).resolve().parents[1]/'src/water_audio_runtime.hpp').read_text()
checks=re.findall(r'matches\(base\+0x([0-9a-f]+),std::array<unsigned char,(\d+)>\{([^}]+)\}',header)
assert len(checks)==5
for address,length,values in checks:
 expected=bytes(int(x,16) for x in values.split(','));assert len(expected)==int(length) and at(int(address,16),len(expected))==expected
assert at(0x80d650,1)==b'\xe8'
assert 0x80d655+struct.unpack('<i',at(0x80d651,4))[0]==0x80ce40
assert at(0x83549,7)==bytes.fromhex('4c89a8c0000000') # retained pointer-to-voice owner
assert at(0x8ef88,7)==bytes.fromhex('49c70000000000') # stop clears caller's voice pointer
# Old wrapper inherited script context; new backend bypasses it entirely.
assert at(0xdeb4f1,8)==bytes.fromhex('488b84cf98480000')
assert 'base+0xdeb2b0' not in header and 'GameReelAudio {' not in header
print('PASS:5 exact voice signatures, typed creator/retained-owner/stop ABI, no persistent script-context wrapper')
