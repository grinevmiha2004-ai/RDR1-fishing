#pragma once
#include <algorithm>
#include <cmath>
#include "cast_playback.hpp"
namespace fishing {
inline constexpr const char* fightAnimSet="lso_base";
inline constexpr const char* fightHoldClip="nor_lso_pul_wlk_225";
// Intentionally hold the first frame of the backward-left walking clip.
// Rate zero applies to this task only; casting keeps its verified rate 1.
template<class Native> void requestFightClip(Native native,int actor){
 native(actor,fightHoldClip,.1f,castBlendOut,0.f,0,true,false,castTaskTimer);
}
// One owned animation session per Fight. Never restart a running/finished hold.
struct FightPose {
 enum class Stage {Idle,Loading,Bound,Starting,Holding,Failed};
 enum class Command {None,Request,Retry,Release};
 Stage stage=Stage::Idle;
 bool owned=false,retried=false,matched=false;
 float elapsed=0,last=-1;
 template<class Bind> Command update(bool fighting,bool loaded,float dt,bool playing,float time,Bind bind,bool staticPose=false){
  if(!fighting){bool release=owned;reset();return release?Command::Release:Command::None;}
  dt=std::isfinite(dt)?std::clamp(dt,0.f,.1f):0.f;
  if(stage==Stage::Failed)return Command::None;
  if(stage==Stage::Idle){stage=Stage::Loading;elapsed=0;}
  if(stage==Stage::Loading){
   if(loaded){if(!bind()){stage=Stage::Failed;return Command::None;}owned=true;stage=Stage::Bound;elapsed=0;}
   else {elapsed+=dt;if(elapsed>=2.f)stage=Stage::Failed;}
   return Command::None;
  }
  if(stage==Stage::Bound){stage=Stage::Starting;elapsed=0;return Command::Request;}
  elapsed+=dt;
  if(stage==Stage::Starting){
   matched=matched||playing;
   if(playing&&std::isfinite(time)&&time>=0){
    bool advanced=last>=0&&(staticPose||std::abs(time-last)>.0001f);last=time;
    if(advanced){stage=Stage::Holding;elapsed=0;return Command::None;}
   }
   if(elapsed>=1.f){stage=Stage::Failed;owned=false;return Command::Release;}
   if(!matched&&!playing&&!retried&&elapsed>=.25f){retried=true;return Command::Retry;}
  }else if(stage==Stage::Holding){
   // Allow a brief query gap. A real interruption ends this session; do not fight other tasks.
   if(playing)elapsed=0;
   else if(elapsed>=.25f){stage=Stage::Failed;owned=false;return Command::Release;}
  }
  return Command::None;
 }
 void reset(){stage=Stage::Idle;owned=false;retried=false;matched=false;elapsed=0;last=-1;}
};
}
