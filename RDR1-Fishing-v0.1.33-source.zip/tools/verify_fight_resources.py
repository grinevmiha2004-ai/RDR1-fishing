"""Verify backward-left lasso walking pose source, key and authored direction.
Usage: python3 tools/verify_fight_resources.py /path/lso_base.was /path/default_character.wat
This does not establish visible hand/rod alignment in the game.
"""
from pathlib import Path
import hashlib,struct,sys
was,wat=[Path(p).read_bytes() for p in sys.argv[1:3]]
assert hashlib.sha256(was).hexdigest()=='8421b46d94cb22cfca7e3bac3fd0737dbd4a68551029881fa73399de53d48185'
assert hashlib.sha256(wat).hexdigest()=='1ed66a66d2cd5574ca5dfe6f7501ba8326130c47031da8182d98ca9f787156f1'
root=Path(__file__).resolve().parent.parent
header=(root/'src/fight_pose.hpp').read_text()
clip='nor_lso_pul_wlk_225'
assert 'fightHoldClip="'+clip+'"' in header
assert 'fightAnimSet="lso_base"' in header
assert was[0x38:0x45]==b'lso_base.ast\0'
def joaat(s):
 h=0
 for c in s.encode():h=(h+c)&0xffffffff;h=(h+(h<<10))&0xffffffff;h^=h>>6
 h=(h+(h<<3))&0xffffffff;h^=h>>11;return (h+(h<<15))&0xffffffff
key=joaat(clip);assert key==0xe8323b4f
at=was.index(struct.pack('<I',key));assert at==0x100e58
resource=struct.unpack_from('<I',was,at+4)[0]&0xfffffff
name=struct.unpack_from('<I',was,resource+8)[0]&0xfffffff
assert was[name:was.index(b'\0',name)]==b'Human\\Gent\\gent_nor_lso_225_pul_wlk'
u=lambda o:struct.unpack_from('<I',wat,o)[0]
p=lambda o:u(o)&0xfffffff
t=0x4c188
assert u(t)==77
st=p(t+0xa8);assert wat[st:wat.index(b'\0',st)].decode()==clip
st=p(t+0xa4);assert wat[st:wat.index(b'\0',st)].decode()=='nor_lso_pul_stn'
print('PASS: lso_base asset hash; runtime key resolves to actual 225-degree walk source; authored hold directional track')
